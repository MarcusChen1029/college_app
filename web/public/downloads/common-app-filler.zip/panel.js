"use strict";
(() => {
  // src/commonapp/pages.ts
  var COMMONAPP_ORIGIN = "https://apply.commonapp.org";
  var CG_GRADE_PATH = {
    "9": "/common/13/55",
    "10": "/common/13/56",
    "11": "/common/13/57",
    "12": "/common/13/58",
    other: "/common/13/59"
  };
  var CURRENT_YEAR_PATH = "/common/4/24";
  var GRADE_LABEL = { "9": "9th grade", "10": "10th grade", "11": "11th grade", "12": "12th grade", other: "Other Courses" };
  function targetUrl(target) {
    return COMMONAPP_ORIGIN + (target === "current" ? CURRENT_YEAR_PATH : CG_GRADE_PATH[target]);
  }

  // src/chrome-driver.ts
  var DRIVER_TIMING = { loadMs: 3e4, noNavigationMs: 3e3, readyMs: 2e4, readyPollMs: 300 };
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function navigate(tabs, tabId, url) {
    let sawLoading = false;
    let finish = () => {
    };
    const done = new Promise((resolve) => finish = resolve);
    const listener = (id, change) => {
      if (id !== tabId) return;
      if (change.status === "loading") sawLoading = true;
      else if (change.status === "complete" && sawLoading) finish();
    };
    tabs.onUpdated.addListener(listener);
    try {
      await tabs.update(tabId, { url });
      const timers = [];
      const grace = new Promise((resolve) => timers.push(setTimeout(() => sawLoading ? void 0 : resolve(), DRIVER_TIMING.noNavigationMs)));
      const timeout = new Promise((_, reject) => timers.push(setTimeout(() => reject(new Error("Common App did not finish loading")), DRIVER_TIMING.loadMs)));
      try {
        await Promise.race([done, grace, timeout]);
      } finally {
        timers.forEach(clearTimeout);
      }
    } finally {
      tabs.onUpdated.removeListener(listener);
    }
  }
  async function waitForReady(tabs, tabId) {
    const start = Date.now();
    for (; ; ) {
      try {
        const r = await tabs.sendMessage(tabId, { type: "ready" });
        if (r?.type === "ready") return;
      } catch {
      }
      if (Date.now() - start >= DRIVER_TIMING.readyMs) throw new Error("The Common App page did not respond. Reload it and try again");
      await sleep(DRIVER_TIMING.readyPollMs);
    }
  }
  async function send(tabs, tabId, message) {
    let r;
    try {
      r = await tabs.sendMessage(tabId, message);
    } catch {
      throw new Error("The Common App page stopped responding");
    }
    if (!r) throw new Error("The Common App page did not answer");
    return r;
  }
  function createDriver(tabs, tabId, plans) {
    return {
      async open(target) {
        await navigate(tabs, tabId, targetUrl(target));
        await waitForReady(tabs, tabId);
      },
      async inspect(target) {
        const r = await send(tabs, tabId, { type: "inspect", target });
        if (r.type !== "inspect") throw new Error("Unexpected answer from the Common App page");
        if (!r.ok) throw new Error(r.error);
        return { existing: r.existing };
      },
      async fill(target, mode) {
        let message;
        if (target === "current") {
          if (!plans.current) throw new Error("No current year courses to fill");
          message = { type: "fill", target: "current", plan: plans.current, mode };
        } else {
          const plan = plans.cg.get(target);
          if (!plan || !(target in CG_GRADE_PATH)) throw new Error("No courses to fill for this grade");
          message = { type: "fill", target, plan, mode };
        }
        const r = await send(tabs, tabId, message);
        if (r.type !== "fill") throw new Error("Unexpected answer from the Common App page");
        if (!r.ok) throw new Error(r.error);
        return r.result;
      }
    };
  }

  // ../web/lib/transcript.ts
  var PERIOD_TYPES = ["full_year", "semester", "trimester", "quarter"];
  var LEVELS = [
    "regular",
    "accelerated",
    "advanced",
    "honors",
    "high_honors",
    "ap",
    "ib_hl",
    "ib_sl",
    "ib",
    "pre_ib",
    "a_level",
    "gcse_igcse",
    "college_prep",
    "dual_enrollment",
    "enriched",
    "gifted",
    "intensive",
    "regents",
    "other",
    "none"
  ];
  var SUBJECTS = ["english", "mathematics", "science", "history_social", "world_language", "arts", "computer_science", "business", "pe_health", "career_technical", "other"];
  var TERMS_FOR_PERIOD = {
    full_year: ["FY"],
    semester: ["S1", "S2", "FY"],
    trimester: ["T1", "T2", "T3", "FY"],
    quarter: ["Q1", "Q2", "Q3", "Q4", "FY"]
  };
  var addCredits = (xs) => Number(xs.reduce((a, b) => a + b, 0).toFixed(4));
  function termCreditSum(ts) {
    if (!ts.some((t) => t.status !== "none" && t.credit != null)) return null;
    return addCredits(ts.map((t) => t.status === "none" ? 0 : t.credit ?? 0));
  }
  function courseStatus(c) {
    if (c.terms.some((t) => t.status === "in_progress")) return "in_progress";
    if (c.terms.length > 0 && c.terms.every((t) => t.status === "planned")) return "planned";
    return "graded";
  }

  // ../web/lib/transcript-maps/types.ts
  var verified = (value, source, note) => ({ value, status: "verified", ...source ? { source } : {}, ...note ? { note } : {} });
  var unverified = (value, note, source) => ({ value, status: "unverified", ...note ? { note } : {}, ...source ? { source } : {} });
  var none = (note) => ({ value: null, status: "none", ...note ? { note } : {} });
  function table(keys, entries, fallback) {
    const out = {};
    for (const k of keys) out[k] = entries[k] ?? fallback;
    return out;
  }
  var isNonUs = (school) => {
    const c = school.country.trim().toLowerCase().replace(/\./g, "");
    return c !== "" && !["us", "usa", "united states", "united states of america", "america"].includes(c);
  };

  // ../web/lib/transcript-maps/common-app.ts
  var DECK = "https://www.commonapp.org/files/webinar_decks/Academic-Record-Reporting.pdf";
  var CATALOG = "https://appsupport.commonapp.org/applicantsupport/s/article/Data-catalogs";
  var IB = verified("International Baccalaureate (IB)", CATALOG, "Common App does not distinguish HL and SL");
  var NA = verified("N/A", CATALOG);
  var COMMON_APP_SUBJECTS = [
    "Pre-Algebra",
    "Algebra",
    "Geometry",
    "Trigonometry",
    "Pre-Calculus",
    "Calculus",
    "Math (Other)",
    "Biology",
    "Chemistry",
    "Physics",
    "Earth/Environmental Science",
    "Science (Other)",
    "English",
    "History/Social Science",
    "Foreign/World Language",
    "Physical Education/Health",
    "Art (Visual or Performing)",
    "Computer Science",
    "Religion",
    "Other/Elective"
  ];
  var S = (value, note) => verified(value, CATALOG, note);
  var MATH = { pre_algebra: "Pre-Algebra", algebra_1: "Algebra", algebra_2: "Algebra", geometry: "Geometry", trigonometry: "Trigonometry", precalculus: "Pre-Calculus", calculus: "Calculus" };
  var SCIENCE = { biology: "Biology", chemistry: "Chemistry", physics: "Physics", earth_space: "Earth/Environmental Science" };
  var COMMON_APP_MAP = {
    id: "common_app",
    label: "Common App",
    level: table(
      LEVELS,
      {
        regular: verified("Regular/Standard", CATALOG),
        accelerated: verified("Accelerated", CATALOG),
        advanced: verified("Advanced", CATALOG),
        honors: verified("Honors", CATALOG),
        high_honors: verified("High Honors", CATALOG),
        ap: verified("Advanced Placement (AP)", CATALOG),
        ib_hl: IB,
        ib_sl: IB,
        ib: IB,
        pre_ib: verified("Pre-IB", CATALOG),
        a_level: verified("AS/A-level/International A-level, Cambridge AICE", CATALOG, "One option"),
        gcse_igcse: verified("GCSE, IGCSE", CATALOG, "One option"),
        college_prep: verified("College Prep", CATALOG),
        dual_enrollment: verified("Dual Enrollment", CATALOG),
        enriched: verified("Enriched", CATALOG),
        gifted: verified("Gifted", CATALOG),
        intensive: verified("Intensive", CATALOG),
        regents: verified("Regents", CATALOG),
        other: NA,
        none: NA
      },
      unverified(null)
    ),
    subject: table(
      SUBJECTS,
      {
        english: S("English"),
        mathematics: S("Math (Other)", "Common App splits math by course; pick the sub-subject to get Algebra, Geometry, Calculus ..."),
        science: S("Science (Other)", "Common App splits science by course; pick the sub-subject to get Biology, Chemistry, Physics ..."),
        history_social: S("History/Social Science"),
        world_language: S("Foreign/World Language"),
        arts: S("Art (Visual or Performing)", "One option for visual art, music, dance and theater"),
        computer_science: S("Computer Science"),
        pe_health: S("Physical Education/Health"),
        business: S("Other/Elective"),
        career_technical: S("Other/Elective"),
        other: S("Other/Elective")
      },
      S("Other/Elective")
    ),
    subjectFor: (subject, sub) => {
      if (subject === "mathematics") return S(sub ? MATH[sub] ?? "Math (Other)" : "Math (Other)");
      if (subject === "science") return S(sub ? SCIENCE[sub] ?? "Science (Other)" : "Science (Other)");
      return null;
    },
    subjectList: {
      options: COMMON_APP_SUBJECTS,
      verified: true,
      note: 'One flat list with no sub-categories: music, dance, theater and visual art are all "Art (Visual or Performing)". Math and science are split by course, each with an "(Other)" option. Business, career-technical and anything else that is not listed go in "Other/Elective"; religion has its own option.'
    },
    subSubject: () => none("Common App's Subject list has no sub-category"),
    period: table(
      PERIOD_TYPES,
      {
        semester: verified("Semester", DECK),
        trimester: verified("Trimester", DECK),
        quarter: verified("Quarterly", DECK),
        full_year: verified("Yearly", DECK)
      },
      unverified(null)
    ),
    rules: (_school, course) => {
      const out = [];
      const graded = course.terms.some((t) => t.status === "graded" && t.grade);
      if (!graded && !course.finalGrade) out.push("Common App needs at least one grade for each course; leave a term blank only if the transcript shows none.");
      if (course.credit == null && course.creditUnit !== "not_listed") out.push("Common App needs at least one credit for each course; tick N/A if the transcript lists no credit.");
      if (!course.terms.length && course.finalGrade) out.push("Enter the term grades if the transcript shows them; Common App wants one grade per term.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/csu.ts
  var HELP = "https://help.liaisonedu.com/Cal_State_Apply_Applicant_Help_Center/Filling_Out_Your_Cal_State_Apply_Application/Cal_State_Apply_Academic_History";
  var COURSEWORK = `${HELP}/03_High_School_Coursework`;
  var AG = `${HELP}/07_A-G_Matching`;
  var GUIDE = "https://www.calstate.edu/apply/freshman/Documents/cal-state-apply-freshman-application-guide.pdf";
  var IB2 = verified("International Baccalaureate", COURSEWORK);
  var CSU_MAP = {
    id: "csu",
    label: "Cal State Apply",
    level: table(
      LEVELS,
      {
        ap: verified("Advanced Placement", COURSEWORK, "+1 GPA point"),
        ib_hl: IB2,
        ib_sl: IB2,
        ib: IB2,
        honors: verified("Honors", COURSEWORK, "Only CSU-approved honors courses get the +1 point"),
        high_honors: unverified("Honors", "Only CSU-approved honors courses get the +1 point", COURSEWORK)
      },
      verified("None", COURSEWORK, "Course Type None (standard)")
    ),
    subject: table(
      SUBJECTS,
      {
        history_social: verified("A \u2013 History/Social Science", GUIDE),
        english: verified("B \u2013 English", GUIDE),
        mathematics: verified("C \u2013 Mathematics", GUIDE),
        science: unverified(null, "Choose D1 (biological) or D2 (physical) science", GUIDE),
        world_language: verified("E \u2013 Language Other than English", GUIDE),
        arts: verified("F \u2013 Visual & Performing Arts", GUIDE),
        computer_science: unverified("G \u2013 College-Prep Elective", "Computer science may count under another area", AG),
        business: unverified("G \u2013 College-Prep Elective", "Only A-G approved courses count", AG),
        pe_health: unverified("G \u2013 College-Prep Elective", "Only A-G approved courses count", AG),
        career_technical: unverified("G \u2013 College-Prep Elective", "Only A-G approved courses count", AG),
        other: verified("G \u2013 College-Prep Elective", GUIDE)
      },
      unverified(null)
    ),
    subjectFor: (subject, sub) => {
      if (subject !== "science") return null;
      if (sub === "biology") return verified("D1 \u2013 Biological Science", GUIDE);
      if (sub === "chemistry" || sub === "physics") return verified("D2 \u2013 Physical Science", GUIDE);
      if (sub === "earth_space") return unverified("D2 \u2013 Physical Science", "Earth and space science may be matched differently", GUIDE);
      return unverified(null, "Choose D1 (biological) or D2 (physical) science", GUIDE);
    },
    subjectList: {
      options: [
        "A \u2013 History/Social Science",
        "B \u2013 English",
        "C \u2013 Mathematics",
        "D1 \u2013 Biological Science",
        "D2 \u2013 Physical Science",
        "E \u2013 Language Other than English",
        "F \u2013 Visual & Performing Arts",
        "G \u2013 College-Prep Elective"
      ],
      verified: true,
      note: "Biology and life science are D1; chemistry, physics and earth science are D2. Music, art, dance and theater are all F. Anything else that counts is G."
    },
    subSubject: () => none("Cal State Apply has no sub-category under an A-G area"),
    period: table(
      PERIOD_TYPES,
      { full_year: unverified("Year"), semester: unverified("Semester"), trimester: unverified("Trimester"), quarter: unverified("Quarter") },
      unverified(null)
    ),
    rules: (school, course) => {
      const out = [];
      if (isNonUs(school)) out.push("Applicants who attended only foreign high schools skip course entry on Cal State Apply; type grades as printed if you do enter them.");
      if (school.kind === "college" || course.isCollege) out.push("College courses go in the College Coursework section, not High School Coursework.");
      if (course.terms.some((t) => t.gradeWeighted)) out.push("Enter the grade shown on the transcript; Cal State Apply computes its own GPA.");
      if (course.terms.some((t) => t.status === "in_progress" || t.status === "planned")) out.push("Mark in-progress terms In Progress and later terms Planned.");
      if (course.isRepeat) out.push("Report only the highest grade for a repeated course.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/stars.ts
  var HELP2 = "https://starsrecord.zendesk.com/hc/en-us/articles";
  var SUBJECT_SRC = `${HELP2}/37027194180251`;
  var LEVEL_SRC = `${HELP2}/37036006202523`;
  var LENGTH_SRC = `${HELP2}/37036235354779`;
  var IB3 = verified("International Baccalaureate (IB)", LEVEL_SRC);
  var OTHER_LEVEL = unverified(null, "STARS's full Course Level dropdown could not be retrieved", LEVEL_SRC);
  var STARS_MAP = {
    id: "stars",
    label: "STARS",
    level: table(
      LEVELS,
      {
        regular: verified("Standard", LEVEL_SRC, "The default when no other level applies"),
        honors: verified("Honors", LEVEL_SRC),
        ap: verified("Advanced Placement (AP)", LEVEL_SRC),
        ib_hl: IB3,
        ib_sl: IB3,
        ib: IB3,
        dual_enrollment: verified("Dual Enrollment", LEVEL_SRC, "Needs the college name"),
        college_prep: verified("College Prep", LEVEL_SRC),
        regents: verified("Regents", LEVEL_SRC),
        gifted: verified("Gifted and Talented", LEVEL_SRC),
        other: unverified("Standard", "Assumed; STARS's full list could not be retrieved", LEVEL_SRC),
        none: unverified("Standard", "Assumed; STARS's full list could not be retrieved", LEVEL_SRC)
      },
      OTHER_LEVEL
    ),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", SUBJECT_SRC),
        mathematics: verified("Mathematics", SUBJECT_SRC),
        science: verified("Science", SUBJECT_SRC),
        history_social: verified("History / Social Studies", SUBJECT_SRC),
        world_language: verified("World Language", SUBJECT_SRC),
        arts: verified("Fine Arts / Music", SUBJECT_SRC),
        computer_science: verified("Computer Science", SUBJECT_SRC),
        business: verified("Business", SUBJECT_SRC),
        pe_health: verified("Physical Education / Health / Gym", SUBJECT_SRC),
        career_technical: unverified("Other Subject Area", "No career-technical area exists in STARS's list", SUBJECT_SRC),
        other: unverified("Other Subject Area", void 0, SUBJECT_SRC)
      },
      unverified(null)
    ),
    subjectList: {
      options: [
        "English",
        "Mathematics",
        "Science",
        "History / Social Studies",
        "World Language",
        "Business",
        "Computer Science",
        "Fine Arts / Music",
        "Physical Education / Health / Gym",
        "Other Subject Area"
      ],
      verified: true,
      note: 'Psychology and economics go under History / Social Studies. Music, band, choir, art, dance and theater are all "Fine Arts / Music". STARS also asks for a Generic Course Title under each subject; those lists are not published.'
    },
    subSubject: () => unverified(null, "STARS's Generic Course Title lists could not be retrieved", SUBJECT_SRC),
    period: table(
      PERIOD_TYPES,
      {
        full_year: verified("Full Year", LENGTH_SRC),
        semester: verified("Semester", LENGTH_SRC),
        trimester: verified("Trimester", LENGTH_SRC),
        quarter: verified("Quarterly", LENGTH_SRC)
      },
      unverified(null)
    ),
    rules: (_school, course) => {
      const out = [];
      if (course.terms.some((t) => t.gradeWeighted)) out.push("STARS wants the unweighted grade when both are printed.");
      if (course.terms.some((t) => t.status === "in_progress")) out.push("Enter IP (In Progress) for courses without a final grade.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/uc.ts
  var QRG = "https://admission.universityofcalifornia.edu/counselors/_files/documents/quick-reference-guide-to-uc-admissions.pdf";
  var DAVIS = "https://www.ucdavis.edu/admissions/undergraduate/first-year/application-tips";
  var IB4 = verified("IB", QRG);
  var NH_NOTE = "Flag UC-approved honors courses only";
  var NOT_AG = "Not an A-G subject; it may go under Other coursework in Activities & awards";
  var WORDING = "UC's A-G area names are official, but the exact dropdown wording is not published";
  var area = (value, note) => unverified(value, note ? `${WORDING}. ${note}` : WORDING, QRG);
  var LETTER_SIGN = /^([A-F])[+-]$/i;
  var PASS_FAIL = /^(p|np|cr|nc|pass|fail|credit|no credit)$/i;
  var allGrades = (c) => [...c.terms.map((t) => t.grade), c.finalGrade ?? ""].filter(Boolean);
  var UC_MAP = {
    id: "uc",
    label: "UC",
    level: table(
      LEVELS,
      {
        ap: verified("AP", QRG),
        ib_hl: IB4,
        ib_sl: IB4,
        ib: IB4,
        honors: unverified("HL", "Only if the course is on the school's UC-approved honors list", QRG),
        dual_enrollment: verified("CL", DAVIS, "College course: enter it under Colleges attended"),
        high_honors: unverified("NH", NH_NOTE, QRG),
        advanced: unverified("NH", NH_NOTE, QRG),
        accelerated: unverified("NH", NH_NOTE, QRG),
        a_level: unverified("NH", "UC gives honors weight only to AP and IB for non-California students", QRG)
      },
      verified("NH", QRG, "Not honors")
    ),
    subject: table(
      SUBJECTS,
      {
        history_social: area("A \u2013 History / social science"),
        english: area("B \u2013 English"),
        mathematics: area("C \u2013 Mathematics"),
        science: area("D \u2013 Science"),
        world_language: area("E \u2013 Language other than English"),
        arts: area("F \u2013 Visual and performing arts"),
        computer_science: area("G \u2013 College-preparatory elective", "Computer science may count under C or D when the school lists it there"),
        other: area("G \u2013 College-preparatory elective"),
        business: none(NOT_AG),
        pe_health: none(NOT_AG),
        career_technical: none(NOT_AG)
      },
      unverified(null)
    ),
    subjectList: {
      options: [
        "A \u2013 History / social science",
        "B \u2013 English",
        "C \u2013 Mathematics",
        "D \u2013 Science",
        "E \u2013 Language other than English",
        "F \u2013 Visual and performing arts",
        "G \u2013 College-preparatory elective"
      ],
      verified: false,
      note: "These are UC's A-G area names; the exact dropdown wording is not published. For visual and performing arts UC's disciplines are Dance, Music, Theater, Visual Arts and Interdisciplinary Arts; for science: Biology/Life Sciences, Chemistry, Physics, Earth & Space Sciences, Integrated Science. PE, business and career-technical courses are not A-G subjects."
    },
    subSubject: (subject, sub) => {
      const POLICY = "A discipline in UC's policy; the application may not ask for it";
      if (subject === "arts") {
        const d = { visual: "Visual Arts", music: "Music", theater: "Theater", dance: "Dance", interdisciplinary: "Interdisciplinary Arts" };
        return sub && d[sub] ? verified(d[sub], QRG, POLICY) : none();
      }
      if (subject === "mathematics") {
        const d = { algebra_1: "Algebra I or Math I", geometry: "Geometry or Math II", algebra_2: "Algebra II or Math III", precalculus: "Precalculus", calculus: "Calculus" };
        return sub && d[sub] ? verified(d[sub], QRG, POLICY) : unverified("Other Advanced Math", POLICY, QRG);
      }
      if (subject === "science") {
        const d = { biology: "Biology/Life Sciences", chemistry: "Chemistry", physics: "Physics", earth_space: "Earth & Space Sciences", integrated: "Integrated Science" };
        return sub && d[sub] ? verified(d[sub], QRG, POLICY) : unverified(null, POLICY, QRG);
      }
      return none();
    },
    period: table(
      PERIOD_TYPES,
      { full_year: unverified("Full year"), semester: unverified("Semester"), trimester: unverified("Trimester"), quarter: unverified("Quarter") },
      unverified(null)
    ),
    termGrade: (t) => t.status === "in_progress" ? "IP" : t.status === "planned" ? "PL" : t.status === "none" ? "NO" : t.grade.replace(LETTER_SIGN, "$1"),
    noCredit: "UC has no per-course credit field",
    rules: (_school, course) => {
      const out = [];
      const grades = allGrades(course);
      if (grades.some((g) => LETTER_SIGN.test(g))) out.push("UC ignores + and -: a B+ is entered as B.");
      if (course.scale === "pass_fail" || grades.some((g) => PASS_FAIL.test(g))) out.push("UC does not accept Pass/Fail grades for A-G courses.");
      if (course.isCollege) out.push("Enter this under Colleges attended, not in the high school section.");
      if (course.isSummer) out.push("Tick the summer box for this grade level.");
      if (course.subject === "pe_health" || course.subject === "career_technical" || course.subject === "business") out.push("Not reportable as A-G; it may go under Other coursework in Activities & awards.");
      if (course.isRepeat) out.push("Report both the original course and the repeat.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/uiuc.ts
  var HELP3 = "https://www.admissions.illinois.edu/international-baccalaureate-application-help/";
  var SRC = HELP3;
  var OTHER_NOTE = "UIUC has no Fine Arts, Computer Science or PE subject; they go under Other";
  var UIUC_SUBJECTS = ["English", "Mathematics", "Science", "Social Science", "Language Other Than English", "Other"];
  var UIUC_MAP = {
    id: "uiuc",
    label: "UIUC SRAR",
    level: table(
      LEVELS,
      {
        regular: verified("Regular", SRC),
        advanced: verified("Advanced", SRC),
        enriched: verified("Enriched", SRC),
        ap: unverified("AP", 'Shown as "AP" / "AP Course" on a low-resolution screenshot', SRC),
        ib_hl: verified("IB HL", SRC),
        ib_sl: verified("IB SL", SRC),
        honors: unverified("Honors", "UIUC's tutorial mentions honors; not seen on an official screenshot", SRC),
        none: none("Leave Type empty unless the transcript lists one")
      },
      unverified(null, "UIUC's full Type list is not published; choose a Type only if the transcript lists it", SRC)
    ),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", SRC),
        mathematics: verified("Mathematics", SRC),
        science: verified("Science", SRC),
        history_social: verified("Social Science", SRC),
        world_language: verified("Language Other Than English", SRC),
        arts: verified("Other", SRC, OTHER_NOTE),
        computer_science: verified("Other", SRC, OTHER_NOTE),
        pe_health: verified("Other", SRC, OTHER_NOTE),
        career_technical: verified("Other", SRC, OTHER_NOTE),
        business: unverified("Other", "Business may be Social Science or Other", SRC),
        other: verified("Other", SRC)
      },
      unverified(null)
    ),
    subjectList: { options: UIUC_SUBJECTS, verified: true, note: 'Arts, computer science, PE and everything that is not one of the five core subjects are "Other".' },
    subSubject: () => none("UIUC has no sub-category"),
    period: table(
      PERIOD_TYPES,
      {
        full_year: verified("All Year", SRC),
        semester: verified("1st Semester / 2nd Semester", SRC, "Enter one row per semester"),
        trimester: unverified(null, "Trimester labels are not published; enter one row per trimester", SRC),
        quarter: unverified(null, "Quarter labels are not published; enter one row per quarter", SRC)
      },
      unverified(null)
    ),
    noCredit: "UIUC's SRAR has no credit field",
    rules: (_school, course) => {
      const out = [];
      if (course.terms.length > 0 && course.finalGrade) out.push("UIUC wants every semester, trimester or quarter grade listed separately; do not list a final grade.");
      if (course.terms.some((t) => t.status === "in_progress")) out.push("Enter IP (In Progress) for senior-year courses without a grade.");
      if (course.isRepeat) out.push("Tick Repeated Course.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/ut.ts
  var FAQ = "https://admissions.utexas.edu/apply/frequently-asked-questions/";
  var UT_SUBJECTS = ["English", "Mathematics", "Science", "Social Studies", "Language Other Than English", "Other"];
  var UT_MAP = {
    id: "ut",
    label: "UT Austin",
    level: table(LEVELS, {}, unverified(null, "UT's form levels are behind a login", FAQ)),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", FAQ),
        mathematics: verified("Mathematics", FAQ),
        science: verified("Science", FAQ),
        history_social: verified("Social Studies", FAQ),
        world_language: verified("Language Other Than English", FAQ)
      },
      verified("Other", FAQ, "Other coursework is optional")
    ),
    subjectList: { options: UT_SUBJECTS, verified: true, note: 'Five principal areas; "Other" coursework is optional.' },
    subSubject: () => none("UT's form has no documented sub-category"),
    period: table(PERIOD_TYPES, {}, unverified(null, "UT's term options are behind a login", FAQ)),
    rules: (_school, course) => {
      const out = [];
      if (course.terms.some((t) => t.status === "in_progress" || t.status === "planned")) out.push("UT's form takes completed courses only; leave in-progress and planned courses out.");
      if (course.isSummer) out.push("Enter summer courses under the grade level before or after.");
      if (course.credit == null) out.push("If the transcript shows no credit, UT counts a year-long course as 1 credit and a semester course as 0.5.");
      return out;
    }
  };

  // ../web/lib/transcript-maps.ts
  var SYSTEMS = {
    common_app: COMMON_APP_MAP,
    stars: STARS_MAP,
    csu: CSU_MAP,
    uc: UC_MAP,
    uiuc: UIUC_MAP,
    ut: UT_MAP
  };
  var SYSTEM_IDS = Object.keys(SYSTEMS);
  var OVERRIDE_NOTE = "Set on this course";
  var yearLabel = (y) => `${y}-${String((y + 1) % 100).padStart(2, "0")}`;
  var defaultTermGrade = (t) => t.status === "none" ? null : t.grade || (t.status === "in_progress" ? "In progress" : t.status === "planned" ? "Planned" : "");
  function gradesValue(course, termGrade) {
    const parts = course.terms.flatMap((t) => {
      const g = termGrade(t);
      return g == null ? [] : [`${t.term}: ${g}`.trimEnd()];
    });
    if (course.finalGrade) parts.push(course.terms.length ? `Final: ${course.finalGrade}` : course.finalGrade);
    return parts.length ? parts.join(", ") : null;
  }
  function mapCourse(system, school, course) {
    const map = SYSTEMS[system];
    const ov = course.overrides[system] ?? {};
    const pick = (entry, override) => override ? { value: override, status: "verified", note: OVERRIDE_NOTE, overridden: true } : { value: entry.value, status: entry.status, note: entry.note, source: entry.source };
    const credit = course.credit == null ? course.creditUnit === "not_listed" ? "N/A" : null : String(course.credit);
    const fields = [
      { key: "name", label: "Course name", value: course.name, status: "verified" },
      { key: "year", label: "School year", value: yearLabel(course.academicYear), status: "verified" },
      { key: "gradeLevel", label: "Grade level", value: course.gradeLevel == null ? null : String(course.gradeLevel), status: "verified" },
      { key: "subject", label: "Subject", ...pick(map.subjectFor?.(course.subject, course.subSubject) ?? map.subject[course.subject], ov.subject) },
      { key: "subSubject", label: "Sub-subject", ...pick(map.subSubject(course.subject, course.subSubject), ov.subSubject) },
      { key: "level", label: "Course level", ...pick(map.level[course.level], ov.level) },
      { key: "period", label: "Term system", ...pick(map.period[course.period], ov.period) },
      { key: "grades", label: "Grades", value: gradesValue(course, map.termGrade ?? defaultTermGrade), status: "verified" },
      {
        key: "credit",
        label: "Credit",
        ...ov.credit ? pick({ value: null, status: "none" }, ov.credit) : map.noCredit ? { value: null, status: "none", note: map.noCredit } : { value: credit, status: "verified" }
      }
    ];
    return { system, fields, warnings: map.rules(school, course) };
  }

  // ../web/lib/commonapp-fill.ts
  var GRADE_ORDER = ["9", "10", "11", "12", "other"];
  var STEM = { full_year: "year", semester: "semester", trimester: "trimester", quarter: "quarter" };
  var COLUMN = { S1: "1", T1: "1", Q1: "1", S2: "2", T2: "2", Q2: "2", T3: "3", Q3: "3", Q4: "4", FY: "final" };
  var SCHEDULE_COLUMNS = { semester: ["1", "2"], trimester: ["1", "2", "3"], quarter: ["1", "2", "3", "4"], year: [] };
  var INTEGER_SCALES = ["1-100", "1-7", "1-10", "1-11", "1-20"];
  var NO_GRADE = "No Grade";
  var NUMERIC = /^\d+(\.\d+)?$/;
  var creditText = (n) => String(addCredits([n]));
  function schoolYearLabel(year) {
    return yearLabel(year);
  }
  function gradingScaleFor(scale, max) {
    if (scale === "percent_100") return "1-100";
    if (scale === "letter" || scale === "letter_plus_minus") return "A-F";
    if (scale === "ib_7") return "1-7";
    if (scale === "gpa_decimal") return max === 4 ? "0.0-4.0" : max === 5 ? "0.0-5.0" : "Other";
    if (scale === "other") return max === 10 ? "1-10" : max === 11 ? "1-11" : max === 20 ? "1-20" : "Other";
    return "Other";
  }
  var gradeKey = (c) => c.gradeLevel != null && c.gradeLevel >= 9 && c.gradeLevel <= 12 ? String(c.gradeLevel) : "other";
  function mostCommon(items) {
    const counts = /* @__PURE__ */ new Map();
    for (const i of items) counts.set(i, (counts.get(i) ?? 0) + 1);
    let best = items[0];
    for (const [v, n] of counts) if (n > counts.get(best)) best = v;
    return best;
  }
  function gradesFor(c) {
    const out = {};
    for (const t of c.terms) {
      const g = t.grade.trim();
      if (t.status === "graded" && g) out[COLUMN[t.term]] = g;
    }
    const final = c.finalGrade?.trim();
    if (final) out.final = final;
    return out;
  }
  function subjectAndLevel(school, c, where, skipped) {
    const mapped = mapCourse("common_app", school, c);
    const pick = (key) => {
      const f = mapped.fields.find((x) => x.key === key);
      if (f.value == null || f.status === "none") {
        skipped.push({ where, course: c.name, field: key, reason: f.note ?? `no Common App ${key} for this course` });
        return null;
      }
      return f.value;
    };
    const subject = pick("subject");
    const dual = c.isCollege && !c.overrides.common_app?.level ? COMMON_APP_MAP.level.dual_enrollment.value : null;
    return { subject, level: dual ?? pick("level"), warnings: mapped.warnings };
  }
  function totalCredit(c) {
    return termCreditSum(c.terms) ?? c.credit;
  }
  function cellsInDialog(c, scale, stem, where, skipped, warnings) {
    const printed = gradesFor(c);
    const total = totalCredit(c);
    const finalCreditOnly = total != null ? { final: creditText(total) } : {};
    const own = gradingScaleFor(c.scale, c.scaleMax);
    if (own !== scale) {
      skipped.push({ where, course: c.name, field: "grades", reason: `grades are on scale ${own}; this grade uses ${scale} on Common App: enter them by hand` });
      return { grades: {}, credits: finalCreditOnly };
    }
    if (STEM[c.period] !== stem) {
      for (const t of c.terms) {
        if (t.status !== "graded" || !t.grade.trim() || COLUMN[t.term] === "final") continue;
        skipped.push({ where, course: c.name, field: `${t.term} grade`, reason: `the course is on a ${STEM[c.period]} schedule; this grade uses the ${stem} schedule on Common App, which has no ${t.term} column: enter it by hand` });
      }
      return { grades: printed.final ? { final: printed.final } : {}, credits: finalCreditOnly };
    }
    const grades = {};
    const credits = {};
    const cols = SCHEDULE_COLUMNS[stem];
    const termOf = (col) => c.terms.find((t) => COLUMN[t.term] === col);
    const hasTerms = cols.some((col) => termOf(col));
    const graded = [];
    const termCredits = [];
    let unfinished = false;
    for (const col of cols) {
      const t = termOf(col);
      if (!t || t.status === "none") {
        if (hasTerms) {
          grades[col] = NO_GRADE;
          credits[col] = "0";
        }
        continue;
      }
      const g = t.grade.trim();
      if (t.status !== "graded" || !g) {
        unfinished = true;
        continue;
      }
      grades[col] = g;
      graded.push(g);
      if (t.credit != null) {
        credits[col] = creditText(t.credit);
        termCredits.push(t.credit);
      }
    }
    if (printed.final) grades.final = printed.final;
    else if (graded.length) {
      if (!unfinished && INTEGER_SCALES.includes(scale) && graded.every((g) => NUMERIC.test(g))) {
        const avg = graded.reduce((sum, g) => sum + Number(g), 0) / graded.length;
        grades.final = String(Math.round(Number(avg.toFixed(6))));
        warnings.push(`${c.name}: Final grade ${grades.final} is the rounded average of the term grades`);
      } else {
        skipped.push({
          where,
          course: c.name,
          field: "final grade",
          reason: unfinished ? "a term is not graded yet, so there is no final grade; type it yourself" : "no final grade on the transcript; type it yourself"
        });
      }
    }
    if (termCredits.length) credits.final = creditText(addCredits(termCredits));
    else if (c.credit != null) credits.final = creditText(c.credit);
    return { grades, credits };
  }
  function buildCgPlan(schools, courses) {
    const byId = new Map(schools.map((s) => [s.id, s]));
    const byGrade = /* @__PURE__ */ new Map();
    for (const c of [...courses].sort((a, b) => a.sortOrder - b.sortOrder)) {
      if (byId.get(c.schoolId)?.kind !== "high_school") continue;
      const k = gradeKey(c);
      byGrade.set(k, [...byGrade.get(k) ?? [], c]);
    }
    const plans = [];
    for (const grade of GRADE_ORDER) {
      const all = byGrade.get(grade);
      if (!all) continue;
      const skipped = [];
      const warnings = [];
      const fillable = [];
      for (const c of all) {
        if (Object.keys(gradesFor(c)).length) fillable.push(c);
        else {
          const status = courseStatus(c);
          skipped.push({ where: grade, course: c.name, field: "course", reason: status === "graded" ? "no grades in tracker" : `${status.replace("_", " ")}: goes to Current Year Courses` });
        }
      }
      const pool = fillable.length ? fillable : all;
      const mainSchool = byId.get(mostCommon(pool.map((c) => c.schoolId)));
      const ofSchool = pool.filter((c) => c.schoolId === mainSchool.id);
      const mainYear = mostCommon(ofSchool.map((c) => c.academicYear));
      const rowsOf = [];
      for (const c of fillable) {
        if (c.schoolId !== mainSchool.id) skipped.push({ where: grade, course: c.name, field: "course", reason: `another school (${byId.get(c.schoolId).name}): not filled, one school per grade` });
        else if (c.academicYear !== mainYear) skipped.push({ where: grade, course: c.name, field: "course", reason: `another school year (${schoolYearLabel(c.academicYear)}): not filled, one year per grade` });
        else rowsOf.push(c);
      }
      const scales = ofSchool.filter((c) => c.academicYear === mainYear).map((c) => gradingScaleFor(c.scale, c.scaleMax));
      const scale = mostCommon(scales);
      const stem = mostCommon(ofSchool.filter((c) => c.academicYear === mainYear).map((c) => STEM[c.period]));
      const rows = rowsOf.map((c) => {
        const { subject, level, warnings: ruleWarnings } = subjectAndLevel(mainSchool, c, grade, skipped);
        for (const w of ruleWarnings) warnings.push(`${c.name}: ${w}`);
        const cells = cellsInDialog(c, scale, stem, grade, skipped, warnings);
        const hasCredit = cells.credits.final != null;
        const creditNA = !hasCredit && c.creditUnit === "not_listed";
        if (!hasCredit && !creditNA) skipped.push({ where: grade, course: c.name, field: "credit", reason: "no credit in tracker" });
        return { trackerId: c.id, name: c.name, subject, level, grades: cells.grades, credits: creditNA ? {} : cells.credits, creditNA };
      });
      plans.push({ grade, schoolName: mainSchool.name, schoolYear: schoolYearLabel(mainYear), scale, scheduleStem: stem, rows, skipped, warnings });
    }
    return plans;
  }
  function currentSchedule(c) {
    const codes = new Set(c.terms.map((t) => t.term));
    if (c.period === "full_year" || codes.has("FY")) return "Full Year";
    if (c.period === "semester") {
      if (codes.has("S1") && codes.has("S2")) return "Full Year";
      if (codes.has("S1")) return "First Semester";
      if (codes.has("S2")) return "Second Semester";
      return null;
    }
    const terms = TERMS_FOR_PERIOD[c.period].filter((t) => t !== "FY");
    if (terms.every((t) => codes.has(t))) return "Full Year";
    const have = terms.filter((t) => codes.has(t));
    return have.length === 1 ? SINGLE_TERM[have[0]] ?? null : null;
  }
  var SINGLE_TERM = {
    T1: "First Trimester",
    T2: "Second Trimester",
    T3: "Third Trimester",
    Q1: "First Quarter",
    Q2: "Second Quarter",
    Q3: "Third Quarter",
    Q4: "Fourth Quarter"
  };
  function buildCurrentYearPlan(schools, courses) {
    const byId = new Map(schools.map((s) => [s.id, s]));
    const hs = [...courses].sort((a, b) => a.sortOrder - b.sortOrder).filter((c) => byId.get(c.schoolId)?.kind === "high_school");
    if (!hs.length) return null;
    const latest = Math.max(...hs.map((c) => c.academicYear));
    const skipped = [];
    const rows = [];
    const periods = [];
    for (const c of hs.filter((x) => x.academicYear === latest)) {
      const { subject, level } = subjectAndLevel(byId.get(c.schoolId), c, "current", skipped);
      const schedule = currentSchedule(c);
      if (schedule == null) skipped.push({ where: "current", course: c.name, field: "schedule", reason: c.terms.length ? "terms are not the whole year or a single term: pick the schedule options by hand" : "no terms in tracker" });
      rows.push({ trackerId: c.id, name: c.name, subject, level, schedule });
      periods.push(c.period);
    }
    return { scheduleStem: STEM[mostCommon(periods)], rows, skipped };
  }

  // src/runner.ts
  var OPEN_RELOADS_NOTE = "Opening reloads the page: anything not yet saved in an open popup is discarded.";
  function needsSaveGuidance(item) {
    return item.stoppedOnPage === true && item.target !== "current";
  }
  var GRADE_ORDER2 = ["9", "10", "11", "12", "other"];
  var CURRENT_LABEL = "Current year courses";
  var TICK_REMINDER = "On each grade, tick 'I have reported all of my courses for this grade' yourself.";
  var STOP_GUIDANCE = "Nothing was saved for this grade yet. Press X on Common App to keep what was filled, or reload the page to discard it.";
  var STATUS = {
    signedOut: "Sign in again",
    studentsOnly: "This extension is for student accounts. Sign in with a student account.",
    network: "Could not load your transcript. Check your connection and try again.",
    nothing: "Nothing to fill: tick at least one item.",
    done: "Done",
    stopped: "Stopped"
  };
  function targetLabel(target) {
    return target === "current" ? CURRENT_LABEL : GRADE_LABEL[target];
  }
  var plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
  async function runFill(targets, driver, ask, shouldStop) {
    const items = [];
    for (const target of targets) {
      if (shouldStop()) return { items, stopped: true };
      try {
        await driver.open(target);
        if (shouldStop()) return { items, stopped: true };
        const { existing } = await driver.inspect(target);
        if (shouldStop()) return { items, stopped: true };
        const mode = existing.length > 0 ? await ask(target, existing.length) : "keep";
        if (shouldStop()) return { items, stopped: true };
        const result = await driver.fill(target, mode);
        const changes = result.notes?.length ? { changes: result.notes } : {};
        if (result.stoppedReason) {
          items.push({ target, filled: result.filled, blanks: result.blanks, ...changes, note: result.stoppedReason, stoppedOnPage: true });
          return { items, stopped: true };
        }
        items.push({ target, filled: result.filled, blanks: result.blanks, ...changes });
      } catch (e) {
        const reason = e instanceof Error ? e.message : String(e);
        items.push({ target, filled: 0, blanks: [], note: `Stopped: ${reason}` });
        return { items, stopped: true };
      }
    }
    return { items, stopped: false };
  }
  function buildPlans(schools, courses) {
    const cg = /* @__PURE__ */ new Map();
    for (const plan of buildCgPlan(schools, courses)) cg.set(plan.grade, plan);
    return { cg, current: buildCurrentYearPlan(schools, courses) };
  }
  function offersFor(plans) {
    const offers = [];
    for (const grade of GRADE_ORDER2) {
      const plan = plans.cg.get(grade);
      if (plan && plan.rows.length > 0) offers.push({ target: grade, label: GRADE_LABEL[grade], count: plan.rows.length });
    }
    if (plans.current && plans.current.rows.length > 0) offers.push({ target: "current", label: CURRENT_LABEL, count: plans.current.rows.length });
    return offers;
  }
  function offerText(offer) {
    return `${offer.label} (${plural(offer.count, "course", "courses")})`;
  }
  async function startFill(load, run2, opts) {
    let loaded;
    try {
      loaded = await load();
    } catch {
      loaded = { ok: false, reason: "network" };
    }
    if (!loaded.ok) {
      const status = loaded.reason === "signed_out" ? STATUS.signedOut : loaded.reason === "students_only" ? STATUS.studentsOnly : STATUS.network;
      return { ok: false, status, reason: loaded.reason };
    }
    const plans = buildPlans(loaded.schools, loaded.courses);
    const offered = new Set(offersFor(plans).map((o) => o.target));
    const targets = [...GRADE_ORDER2, "current"].filter((t) => opts.targets.includes(t) && offered.has(t));
    if (targets.length === 0) return { ok: false, status: STATUS.nothing, reason: "nothing" };
    const warnings = [];
    for (const t of targets) if (t !== "current") for (const w of plans.cg.get(t)?.warnings ?? []) warnings.push(`${GRADE_LABEL[t]}: ${w}`);
    const { items, stopped } = await run2(targets, opts.makeDriver(plans), opts.ask, opts.shouldStop);
    return { ok: true, status: stopped ? STATUS.stopped : STATUS.done, items, stopped, warnings };
  }
  function filledText(item) {
    return `Filled ${plural(item.filled, "course", "courses")}`;
  }
  function blankText(b) {
    const what = [b.course, b.field].filter(Boolean).join(": ");
    return what ? `${what} left blank: ${b.reason}` : b.reason;
  }
  function askText(target, existingCount) {
    return `${targetLabel(target)} already ${existingCount === 1 ? "has 1 course" : `has ${existingCount} courses`} on Common App.`;
  }

  // src/panel.ts
  var app = document.getElementById("app");
  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    for (const c of children) if (c) el.append(c);
    return el;
  }
  function button(label, onClick, cls = "btn", disabled = false) {
    const b = h("button", { type: "button", class: cls }, label);
    b.disabled = disabled;
    b.addEventListener("click", onClick);
    return b;
  }
  function show(...nodes) {
    app.replaceChildren(h("h1", {}, "Common App filler"), ...nodes.filter((n) => !!n));
  }
  async function loadTranscript() {
    try {
      const r = await chrome.runtime.sendMessage({ type: "loadTranscript" });
      return r?.type === "loadTranscript" ? r.result : { ok: false, reason: "network" };
    } catch {
      return { ok: false, reason: "network" };
    }
  }
  async function signIn() {
    try {
      const r = await chrome.runtime.sendMessage({ type: "signIn" });
      return r?.type === "signIn" && r.ok;
    } catch {
      return false;
    }
  }
  async function signOut() {
    try {
      await chrome.runtime.sendMessage({ type: "signOut" });
    } catch {
    }
  }
  async function commonAppTabId() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      return tab?.id !== void 0 && tab.url?.startsWith(COMMONAPP_ORIGIN + "/") ? tab.id : null;
    } catch {
      return null;
    }
  }
  var ticked = /* @__PURE__ */ new Set();
  var view = "other";
  var currentOffers = [];
  var stopRequested = false;
  function signedOutView(message) {
    view = "other";
    const note = h("p", { class: "note" }, message ?? "");
    show(
      h("p", {}, "Sign in with your College Tracker account so the extension can read your transcript. It cannot see anything else in your account."),
      message ? note : null,
      button("Sign in", async () => {
        note.textContent = "Waiting for the sign-in window...";
        if (await signIn()) await refresh();
        else signedOutView("Sign in did not finish. Try again.");
      }, "btn primary")
    );
  }
  function messageView(text, ...actions) {
    view = "other";
    show(h("p", { class: "note" }, text), h("div", { class: "row" }, ...actions));
  }
  async function refresh() {
    view = "other";
    show(h("p", { class: "muted" }, "Loading your transcript..."));
    const result = await loadTranscript();
    if (!result.ok) {
      if (result.reason === "signed_out") return signedOutView();
      if (result.reason === "students_only") return messageView(STATUS.studentsOnly, button("Sign out", async () => {
        await signOut();
        signedOutView();
      }));
      return messageView(STATUS.network, button("Try again", () => void refresh(), "btn primary"));
    }
    currentOffers = offersFor(buildPlans(result.schools, result.courses));
    ticked = new Set(currentOffers.map((o) => o.target));
    await readyView();
  }
  async function readyView() {
    view = "ready";
    const tabId = await commonAppTabId();
    if (view !== "ready") return;
    const boxes = currentOffers.map((o) => {
      const box = h("input", { type: "checkbox" });
      box.checked = ticked.has(o.target);
      box.addEventListener("change", () => {
        if (box.checked) ticked.add(o.target);
        else ticked.delete(o.target);
        fill.disabled = tabId === null || ticked.size === 0;
      });
      return h("label", { class: "check" }, box, h("span", {}, offerText(o)));
    });
    const fill = button("Fill selected", () => void run(tabId), "btn primary", tabId === null || ticked.size === 0);
    show(
      currentOffers.length ? h("div", { class: "list" }, ...boxes) : h("p", { class: "note" }, "No courses with grades or current-year courses were found in your transcript."),
      tabId === null && h("p", { class: "note" }, "Open your Common App in this window first."),
      h("div", { class: "row" }, fill, button("Sign out", async () => {
        await signOut();
        signedOutView();
      }))
    );
  }
  async function run(tabId) {
    view = "other";
    stopRequested = false;
    const status = h("p", { class: "status" }, "Starting...");
    const prompt = h("div", {});
    let dismissPrompt = null;
    const stop = button("Stop", () => {
      stopRequested = true;
      dismissPrompt?.();
      status.textContent = "Stopping after the current field...";
      stop.disabled = true;
      chrome.tabs.sendMessage(tabId, { type: "stop" }).catch(() => {
      });
    }, "btn danger");
    show(status, prompt, h("div", { class: "row" }, stop));
    const ask = (target, count) => new Promise((resolve) => {
      const choose = (mode) => {
        dismissPrompt = null;
        prompt.replaceChildren();
        resolve(mode);
      };
      dismissPrompt = () => choose("keep");
      prompt.replaceChildren(
        h("div", { class: "ask" }, h("p", {}, askText(target, count)), h("div", { class: "row" }, button("Replace them", () => choose("replace"), "btn"), button("Keep them, add the rest", () => choose("keep"), "btn primary")))
      );
    });
    const targets = currentOffers.map((o) => o.target).filter((t) => ticked.has(t));
    const outcome = await startFill(loadTranscript, runFill, {
      targets,
      ask,
      shouldStop: () => stopRequested,
      makeDriver: (plans) => {
        const real = createDriver(chrome.tabs, tabId, plans);
        return {
          ...real,
          async open(t) {
            status.textContent = `Filling ${targetLabel(t)}...`;
            return real.open(t);
          }
        };
      }
    });
    reportView(outcome, targets, tabId);
  }
  function reportView(outcome, targets, tabId) {
    view = "other";
    if (!outcome.ok) {
      if (outcome.reason === "signed_out") return signedOutView(outcome.status);
      return messageView(outcome.status, button("Back", () => void refresh(), "btn primary"));
    }
    const sections = outcome.items.map((item) => {
      return h(
        "section",
        { class: "item" },
        h("h2", {}, targetLabel(item.target)),
        h("p", { class: "done" }, filledText(item)),
        item.note ? h("p", { class: "warn" }, item.note) : false,
        needsSaveGuidance(item) ? h("p", { class: "warn" }, STOP_GUIDANCE) : false,
        ...(item.changes ?? []).map((c) => h("p", { class: "note" }, c)),
        item.blanks.length ? h("ul", {}, ...item.blanks.map((b) => h("li", {}, blankText(b)))) : false,
        button(`Open ${targetLabel(item.target)} on Common App`, () => void chrome.tabs.update(tabId, { url: targetUrl(item.target) }), "link"),
        // After a stop the tab may hold an open dialog with unsaved rows; any of these links navigates that tab away.
        outcome.stopped ? h("p", { class: "note" }, OPEN_RELOADS_NOTE) : false
      );
    });
    const done = new Set(outcome.items.map((i) => i.target));
    const left = targets.filter((t) => !done.has(t));
    show(
      h("p", { class: outcome.stopped ? "status warn" : "status" }, outcome.status),
      ...sections,
      left.length ? h("p", { class: "note" }, `Not filled: ${left.map(targetLabel).join(", ")}.`) : false,
      outcome.warnings.length ? h("ul", { class: "warnings" }, ...outcome.warnings.map((w) => h("li", {}, w))) : false,
      h("p", { class: "note" }, TICK_REMINDER),
      h("div", { class: "row" }, button("Back", () => void refresh(), "btn primary"))
    );
  }
  var retab = () => {
    if (view === "ready") void readyView();
  };
  chrome.tabs.onActivated.addListener(retab);
  chrome.tabs.onUpdated.addListener((_id, change) => {
    if (change.url || change.status === "complete") retab();
  });
  void refresh();
})();
