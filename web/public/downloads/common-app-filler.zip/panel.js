"use strict";
(() => {
  // ../web/lib/transcript.ts
  var PERIOD_TYPES = ["full_year", "semester", "trimester", "quarter"];
  var LEVELS = [
    "regular",
    "accelerated",
    "advanced",
    "honors",
    "high_honors",
    "ap",
    "ib_hl",
    "ib_sl",
    "ib",
    "pre_ib",
    "a_level",
    "gcse_igcse",
    "college_prep",
    "dual_enrollment",
    "enriched",
    "gifted",
    "intensive",
    "regents",
    "other",
    "none"
  ];
  var SUBJECTS = ["english", "mathematics", "science", "history_social", "world_language", "arts", "computer_science", "business", "pe_health", "career_technical", "other"];
  var TERMS_FOR_PERIOD = {
    full_year: ["FY"],
    semester: ["S1", "S2", "FY"],
    trimester: ["T1", "T2", "T3", "FY"],
    quarter: ["Q1", "Q2", "Q3", "Q4", "FY"]
  };
  var TERM_LABEL = { FY: "Final / year", S1: "Semester 1", S2: "Semester 2", T1: "Trimester 1", T2: "Trimester 2", T3: "Trimester 3", Q1: "Quarter 1", Q2: "Quarter 2", Q3: "Quarter 3", Q4: "Quarter 4" };
  var addCredits = (xs) => Number(xs.reduce((a, b) => a + b, 0).toFixed(4));
  function termCreditSum(ts) {
    if (!ts.some((t) => t.status !== "none" && t.credit != null)) return null;
    return addCredits(ts.map((t) => t.status === "none" ? 0 : t.credit ?? 0));
  }
  function courseStatus(c) {
    if (c.terms.some((t) => t.status === "in_progress")) return "in_progress";
    if (c.terms.length > 0 && c.terms.every((t) => t.status === "planned")) return "planned";
    return "graded";
  }
  var normalizeName = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();

  // ../web/lib/transcript-maps/types.ts
  var verified = (value, source, note) => ({ value, status: "verified", ...source ? { source } : {}, ...note ? { note } : {} });
  var unverified = (value, note, source) => ({ value, status: "unverified", ...note ? { note } : {}, ...source ? { source } : {} });
  var none = (note) => ({ value: null, status: "none", ...note ? { note } : {} });
  function table(keys, entries, fallback) {
    const out = {};
    for (const k of keys) out[k] = entries[k] ?? fallback;
    return out;
  }
  var isNonUs = (school) => {
    const c = school.country.trim().toLowerCase().replace(/\./g, "");
    return c !== "" && !["us", "usa", "united states", "united states of america", "america"].includes(c);
  };

  // ../web/lib/transcript-maps/common-app.ts
  var DECK = "https://www.commonapp.org/files/webinar_decks/Academic-Record-Reporting.pdf";
  var CATALOG = "https://appsupport.commonapp.org/applicantsupport/s/article/Data-catalogs";
  var IB = verified("International Baccalaureate (IB)", CATALOG, "Common App does not distinguish HL and SL");
  var NA = verified("N/A", CATALOG);
  var COMMON_APP_SUBJECTS = [
    "Pre-Algebra",
    "Algebra",
    "Geometry",
    "Trigonometry",
    "Pre-Calculus",
    "Calculus",
    "Math (Other)",
    "Biology",
    "Chemistry",
    "Physics",
    "Earth/Environmental Science",
    "Science (Other)",
    "English",
    "History/Social Science",
    "Foreign/World Language",
    "Physical Education/Health",
    "Art (Visual or Performing)",
    "Computer Science",
    "Religion",
    "Other/Elective"
  ];
  var S = (value, note) => verified(value, CATALOG, note);
  var MATH = { pre_algebra: "Pre-Algebra", algebra_1: "Algebra", algebra_2: "Algebra", geometry: "Geometry", trigonometry: "Trigonometry", precalculus: "Pre-Calculus", calculus: "Calculus" };
  var SCIENCE = { biology: "Biology", chemistry: "Chemistry", physics: "Physics", earth_space: "Earth/Environmental Science" };
  var COMMON_APP_MAP = {
    id: "common_app",
    label: "Common App",
    level: table(
      LEVELS,
      {
        regular: verified("Regular/Standard", CATALOG),
        accelerated: verified("Accelerated", CATALOG),
        advanced: verified("Advanced", CATALOG),
        honors: verified("Honors", CATALOG),
        high_honors: verified("High Honors", CATALOG),
        ap: verified("Advanced Placement (AP)", CATALOG),
        ib_hl: IB,
        ib_sl: IB,
        ib: IB,
        pre_ib: verified("Pre-IB", CATALOG),
        a_level: verified("AS/A-level/International A-level, Cambridge AICE", CATALOG, "One option"),
        gcse_igcse: verified("GCSE, IGCSE", CATALOG, "One option"),
        college_prep: verified("College Prep", CATALOG),
        dual_enrollment: verified("Dual Enrollment", CATALOG),
        enriched: verified("Enriched", CATALOG),
        gifted: verified("Gifted", CATALOG),
        intensive: verified("Intensive", CATALOG),
        regents: verified("Regents", CATALOG),
        other: NA,
        none: NA
      },
      unverified(null)
    ),
    subject: table(
      SUBJECTS,
      {
        english: S("English"),
        mathematics: S("Math (Other)", "Common App splits math by course; pick the sub-subject to get Algebra, Geometry, Calculus ..."),
        science: S("Science (Other)", "Common App splits science by course; pick the sub-subject to get Biology, Chemistry, Physics ..."),
        history_social: S("History/Social Science"),
        world_language: S("Foreign/World Language"),
        arts: S("Art (Visual or Performing)", "One option for visual art, music, dance and theater"),
        computer_science: S("Computer Science"),
        pe_health: S("Physical Education/Health"),
        business: S("Other/Elective"),
        career_technical: S("Other/Elective"),
        other: S("Other/Elective")
      },
      S("Other/Elective")
    ),
    subjectFor: (subject, sub) => {
      if (subject === "mathematics") return S(sub ? MATH[sub] ?? "Math (Other)" : "Math (Other)");
      if (subject === "science") return S(sub ? SCIENCE[sub] ?? "Science (Other)" : "Science (Other)");
      return null;
    },
    subjectList: {
      options: COMMON_APP_SUBJECTS,
      verified: true,
      note: 'One flat list with no sub-categories: music, dance, theater and visual art are all "Art (Visual or Performing)". Math and science are split by course, each with an "(Other)" option. Business, career-technical and anything else that is not listed go in "Other/Elective"; religion has its own option.'
    },
    subSubject: () => none("Common App's Subject list has no sub-category"),
    period: table(
      PERIOD_TYPES,
      {
        semester: verified("Semester", DECK),
        trimester: verified("Trimester", DECK),
        quarter: verified("Quarterly", DECK),
        full_year: verified("Yearly", DECK)
      },
      unverified(null)
    ),
    rules: (_school, course) => {
      const out = [];
      const graded = course.terms.some((t) => t.status === "graded" && t.grade);
      if (!graded && !course.finalGrade) out.push("Common App needs at least one grade for each course; leave a term blank only if the transcript shows none.");
      if (course.credit == null && course.creditUnit !== "not_listed") out.push("Common App needs at least one credit for each course; tick N/A if the transcript lists no credit.");
      if (!course.terms.length && course.finalGrade) out.push("Enter the term grades if the transcript shows them; Common App wants one grade per term.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/csu.ts
  var HELP = "https://help.liaisonedu.com/Cal_State_Apply_Applicant_Help_Center/Filling_Out_Your_Cal_State_Apply_Application/Cal_State_Apply_Academic_History";
  var COURSEWORK = `${HELP}/03_High_School_Coursework`;
  var AG = `${HELP}/07_A-G_Matching`;
  var GUIDE = "https://www.calstate.edu/apply/freshman/Documents/cal-state-apply-freshman-application-guide.pdf";
  var LIVE = "https://calstate.cas.myliaison.com/applicant/my-application";
  var IB2 = verified("International Baccalaureate", COURSEWORK);
  var CSU_MAP = {
    id: "csu",
    label: "Cal State Apply",
    level: table(
      LEVELS,
      {
        ap: verified("Advanced Placement", COURSEWORK, "+1 GPA point"),
        ib_hl: IB2,
        ib_sl: IB2,
        ib: IB2,
        honors: verified("Honors", COURSEWORK, "Only CSU-approved honors courses get the +1 point"),
        high_honors: unverified("Honors", "Only CSU-approved honors courses get the +1 point", COURSEWORK)
      },
      verified("None", COURSEWORK, "Course Type None (standard)")
    ),
    subject: table(
      SUBJECTS,
      {
        history_social: verified("A \u2013 History / Social Science", LIVE),
        english: verified("B \u2013 English", LIVE),
        mathematics: verified("C \u2013 Mathematics", LIVE),
        science: unverified(null, "Choose D1 (biological) or D2 (physical) science", GUIDE),
        world_language: verified("E \u2013 Language Other than English", LIVE),
        arts: verified("F \u2013 Visual & Performing Arts", LIVE),
        computer_science: unverified("G \u2013 College-Preparatory Elective", "Computer science may count under another area", AG),
        business: unverified("G \u2013 College-Preparatory Elective", "Only A-G approved courses count", AG),
        pe_health: unverified("G \u2013 College-Preparatory Elective", "Only A-G approved courses count", AG),
        career_technical: unverified("G \u2013 College-Preparatory Elective", "Only A-G approved courses count", AG),
        other: verified("G \u2013 College-Preparatory Elective", LIVE)
      },
      unverified(null)
    ),
    subjectFor: (subject, sub) => {
      if (subject !== "science") return null;
      if (sub === "biology") return verified("D1 \u2013 Biological Science", LIVE);
      if (sub === "chemistry" || sub === "physics") return verified("D2 \u2013 Physical Science", LIVE);
      if (sub === "earth_space") return unverified("D2 \u2013 Physical Science", "Earth and space science may be matched differently", GUIDE);
      return unverified(null, "Choose D1 (biological) or D2 (physical) science", GUIDE);
    },
    subjectList: {
      options: [
        "A \u2013 History / Social Science",
        "B \u2013 English",
        "C \u2013 Mathematics",
        "D1 \u2013 Biological Science",
        "D2 \u2013 Physical Science",
        "E \u2013 Language Other than English",
        "F \u2013 Visual & Performing Arts",
        "G \u2013 College-Preparatory Elective"
      ],
      verified: true,
      note: "Biology and life science are D1; chemistry, physics and earth science are D2. Music, art, dance and theater are all F. Anything else that counts is G."
    },
    subSubject: () => none("Cal State Apply has no sub-category under an A-G area"),
    period: table(
      PERIOD_TYPES,
      { full_year: verified("Full Year", LIVE), semester: verified("Semester", LIVE), trimester: verified("Trimester", LIVE), quarter: verified("Quarter", LIVE) },
      unverified(null)
    ),
    rules: (school, course) => {
      const out = [];
      if (isNonUs(school)) out.push("Applicants who attended only foreign high schools skip course entry on Cal State Apply; type grades as printed if you do enter them.");
      if (school.kind === "college" || course.isCollege) out.push("College courses go in the College Coursework section, not High School Coursework.");
      if (course.terms.some((t) => t.gradeWeighted)) out.push("Enter the grade shown on the transcript; Cal State Apply computes its own GPA.");
      if (course.terms.some((t) => t.status === "in_progress" || t.status === "planned")) out.push("Mark in-progress terms In Progress and later terms Planned.");
      if (course.isRepeat) out.push("Report only the highest grade for a repeated course.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/stars-lists.ts
  var STARS_INTL_ACADEMIC_LEVELS = [
    "Equivalent to U.S. High School 9th Grade",
    "Equivalent to U.S. High School 10th Grade",
    "Equivalent to U.S. High School 11th Grade",
    "Equivalent to U.S. High School 12th Grade",
    "Equivalent to U.S. High School 13th Grade"
  ];
  var STARS_INTL_SUBJECTS = [
    "Mathematics",
    "Science",
    "History / Social Studies",
    "Languages",
    "Computer Science / Info Tech",
    "Business",
    "Fine Arts / Music",
    "Phys. Ed / Health / Gym",
    "Other Subject Area"
  ];
  var STARS_INTL_LEVELS = [
    "AP (Advanced Placement)",
    "Advanced",
    "Basic",
    "Dual Enrollment",
    "GCE Advanced Level",
    "GCE Advanced Subsidiary Level",
    "General",
    "Honors",
    "IB (Higher/HL)",
    "IB (Standard/SL)",
    "IGCSE/GCSE Ordinary Level",
    "In-Class/Internal Grade",
    "Middle Years IB",
    "Not Applicable",
    "Predicted Score",
    "Standard"
  ];
  var STARS_INTL_SCALES = [
    "IGCSE Ordinary (O-Level, 9,A*=A+, 7-8=A,6=B...Pass=4,C)",
    "IB--Int'l Bac 7-point (7=A  6=A-  5=B...)",
    "GCE & Int'l Advanced Subsidiary (AS-Level)",
    "GCE & Int'l Advanced (A-Level)",
    "French Baccalaur\xE9at (20-16=A...Pass=8)",
    "100-Point (100-90=A, 80-89=B...Pass=70)",
    "100-Point (100-90=A, 80-89=B...Pass=60)",
    "10-Point (10=A+, 9=A, 8=B...Pass=6)",
    "5-Point (5=A, 4=B,...Pass=3)",
    "5-Point (5=A, 4=B,...Pass=2)",
    "5-Point (1=A, 2=B,...Pass=4)"
  ];
  var STARS_INTL_GRADE_WORDS = ["In Progress", "Withdrawn", "Medical Excuse", "No Credit", "Pass/Fail - Pass", "Pass/Fail - Fail", "Incomplete", "No Grade - Not In Progress"];
  var STARS_INTL_TITLES = {
    Mathematics: [
      "ALGEBRA 1",
      "GEOMETRY",
      "ALGEBRA 2",
      "TRIGONOMETRY",
      "PRECALCULUS",
      "CALCULUS",
      "STATISTICS",
      "ADVANCED MATH",
      "APPLIED MATH",
      "BUSINESS MATH",
      "CONSUMER MATH",
      "DIFFERENTIAL EQUATIONS",
      "DISCRETE MATH",
      "ELEMENTARY FUNCTIONS",
      "FINITE MATHEMATICS",
      "LINEAR ALGEBRA",
      "LINEAR PROGRAMMING",
      "MATH ANALYSIS",
      "PRE-ALGEBRA",
      "INTEGRATED ALGEBRA/GEOMETRY",
      "INTEGRATED ALGEBRA/GEOMETRY/TRIGONOMETRY",
      "IB MATH ANALYSIS AND APPROACHES HL",
      "IB MATH ANALYSIS AND APPROACHES SL",
      "IB MATH APPLICATIONS AND INTERPRETATIONS HL",
      "IB MATH APPLICATIONS AND INTERPRETATIONS SL",
      "IB MATH MYP",
      "IB MATH STUDIES",
      "IB MATHEMATICS",
      "OTHER MATH",
      "ALGEBRA 2/TRIGONOMETRY",
      "ALGEBRA 3/TRIGONOMETRY",
      "COLLEGE ALGEBRA",
      "COLLEGE ALGEBRA/TRIGONOMETRY",
      "COLLEGE MATH",
      "TRIGONOMETRY/PRE-CALCULUS"
    ],
    Science: [
      "BIOLOGY",
      "CHEMISTRY",
      "PHYSICS",
      "ENVIRONMENTAL SCIENCE",
      "EARTH SCIENCE",
      "ANATOMY & PHYSIOLOGY",
      "PHYSICAL SCIENCE",
      "AEROSPACE",
      "ANATOMY",
      "ASTRONOMY",
      "BOTANY",
      "ECOLOGY",
      "ELECTRICITY AND MAGNETISM",
      "FORENSIC SCIENCE",
      "GENETICS",
      "GEOLOGY",
      "INTEGRATED SCIENCE",
      "INTRO TO ENGINEERING",
      "INTRO TO SCIENCE",
      "LIFE SCIENCE",
      "MARINE SCIENCE/BIOLOGY",
      "METEOROLOGY",
      "MICROBIOLOGY",
      "NUTRITION/FOOD SCIENCE",
      "OCEANOGRAPHY",
      "ORGANIC CHEMISTRY",
      "PHYSIOLOGY",
      "PRINCIPLES OF ENGINEERING",
      "SCIENCE, TECH, & SOCIETY",
      "ZOOLOGY",
      "OTHER SCIENCE"
    ],
    "History / Social Studies": [
      "AMERICAN/US HISTORY",
      "CIVICS",
      "ECONOMICS",
      "GEOGRAPHY",
      "GOVERNMENT AND POLITICS",
      "PSYCHOLOGY",
      "SOCIOLOGY",
      "US GOVERNMENT",
      "WORLD HISTORY",
      "AFRICAN AMERICAN STUDIES/HISTORY",
      "ANCIENT & MEDIEVAL HISTORY",
      "ANCIENT CIVILIZATIONS",
      "ANTHROPOLOGY",
      "COMPARATIVE GOVT/POLITICS",
      "CONTEMPORARY WORLD ISSUES",
      "ETHNIC STUDIES",
      "EUROPEAN HISTORY",
      "GENDER STUDIES",
      "GLOBAL STUDIES",
      "HUMANITIES",
      "INTERNATIONAL RELATIONS",
      "LAW STUDIES",
      "MACROECONOMICS",
      "MICROECONOMICS",
      "PHILOSOPHY",
      "POLITICAL SCIENCE",
      "SOCIAL STUDIES",
      "SOCIOLOGY 2",
      "US & WORLD AFFAIRS",
      "WESTERN CIVILIZATION",
      "WORLD CIVILIZATIONS",
      "WORLD CULTURES",
      "WORLD RELIGIONS",
      "OTHER HISTORY/SOCIAL STUDIES"
    ],
    Languages: [
      "ENGLISH 9 (FIRST YEAR)",
      "SPANISH 1 (FIRST YEAR)",
      "SPANISH 2 (SECOND YEAR)",
      "SPANISH 3 (THIRD YEAR)",
      "SPANISH 4 (FOURTH YEAR)",
      "SPANISH 5 (FIFTH YEAR)",
      "SPANISH 6 (SIXTH YEAR)",
      "SPANISH FOR NATIVE SPEAKERS",
      "SPANISH LANGUAGE & CULTURE",
      "SPANISH LANGUAGE & LITERATURE",
      "SPANISH LITERATURE",
      "SPANISH LITERATURE & CULTURE",
      "ENGLISH 10 (SECOND YEAR)",
      "ENGLISH 11 (THIRD YEAR)",
      "ENGLISH 12 (FOURTH YEAR)",
      "FRENCH 1 (FIRST YEAR)",
      "FRENCH 2 (SECOND YEAR)",
      "FRENCH 3 (THIRD YEAR)",
      "FRENCH 4 (FOURTH YEAR)",
      "FRENCH 5 (FIFTH YEAR)",
      "FRENCH 6 (SIXTH YEAR)",
      "FRENCH LANGUAGE & CULTURE",
      "FRENCH LANGUAGE & LITERATURE",
      "FRENCH LITERATURE",
      "ENGLISH LANGUAGE AND COMPOSITION",
      "ENGLISH LANGUAGE AND LITERATURE",
      "ENGLISH LITERATURE AND COMPOSITION",
      "LATIN 1 (FIRST YEAR)",
      "LATIN 2 (SECOND YEAR)",
      "LATIN 3 (THIRD YEAR)",
      "LATIN 4 (FOURTH YEAR)",
      "LATIN 5 (FIFTH YEAR)",
      "LATIN 6 (SIXTH YEAR)",
      "ENGLISH LITERATURE",
      "AMERICAN LITERATURE",
      "BRITISH LITERATURE",
      "CLASSIC LITERATURE",
      "COMMUNICATIONS",
      "CREATIVE WRITING",
      "ENGLISH COMPOSITION 1",
      "ENGLISH COMPOSITION 2",
      "ESL 1 (ENGL AS A SECOND LANG 1)",
      "ESL 2 (ENGL AS A SECOND LANG 2)",
      "FORENSIC SPEECH-DEBATE",
      "JOURNALISM",
      "MYTHOLOGY",
      "PUBLIC SPEAKING",
      "RESEARCH (ENGLISH)",
      "SEMINAR",
      "WORLD LITERATURE",
      "AMERICAN INDIAN 1 (FIRST YEAR)",
      "AMERICAN INDIAN 2 (SECOND YEAR)",
      "AMERICAN INDIAN 3 (THIRD YEAR)",
      "AMERICAN INDIAN 4 (FOURTH YEAR)",
      "AMERICAN INDIAN 5 (FIFTH YEAR)",
      "AMERICAN INDIAN 6 (SIXTH YEAR)",
      "AMERICAN INDIAN IMMERSION",
      "AMERICAN INDIAN LANGUAGE & LITERATURE",
      "AMERICAN INDIAN LITERATURE",
      "AMERICAN SIGN LANGUAGE 1 (FIRST YEAR)",
      "AMERICAN SIGN LANGUAGE 2 (SECOND YEAR)",
      "AMERICAN SIGN LANGUAGE 3 (THIRD YEAR)",
      "AMERICAN SIGN LANGUAGE 4 (FOURTH YEAR)",
      "AMERICAN SIGN LANGUAGE 5 (FIFTH YEAR)",
      "AMERICAN SIGN LANGUAGE 6 (SIXTH YEAR)",
      "ARABIC 1 (FIRST YEAR)",
      "ARABIC 2 (SECOND YEAR)",
      "ARABIC 3 (THIRD YEAR)",
      "ARABIC 4 (FOURTH YEAR)",
      "ARABIC 5 (FIFTH YEAR)",
      "ARABIC 6 (SIXTH YEAR)",
      "ARABIC LANGUAGE & LITERATURE",
      "ARABIC LITERATURE",
      "BRAILLE",
      "CHINESE 1 (FIRST YEAR)",
      "CHINESE 2 (SECOND YEAR)",
      "CHINESE 3 (THIRD YEAR)",
      "CHINESE 4 (FOURTH YEAR)",
      "CHINESE 5 (FIFTH YEAR)",
      "CHINESE 6 (SIXTH YEAR)",
      "CHINESE LANGUAGE & CULTURE",
      "CHINESE LANGUAGE & LITERATURE",
      "CHINESE LITERATURE",
      "CLASSICAL GREEK 1 (FIRST YEAR)",
      "CLASSICAL GREEK 2 (SECOND YEAR)",
      "CLASSICAL GREEK 3 (THIRD YEAR)",
      "CLASSICAL GREEK 4 (FOURTH YEAR)",
      "CLASSICAL GREEK 5 (FIFTH YEAR)",
      "CLASSICAL GREEK 6 (SIXTH YEAR)",
      "CLASSICAL HEBREW 1 (FIRST YEAR)",
      "CLASSICAL HEBREW 2 (SECOND YEAR)",
      "CLASSICAL HEBREW 3 (THIRD YEAR)",
      "CLASSICAL HEBREW 4 (FOURTH YEAR)",
      "CLASSICAL HEBREW 5 (FIFTH YEAR)",
      "CLASSICAL HEBREW 6 (SIXTH YEAR)",
      "FILIPINO 1 (FIRST YEAR)",
      "FILIPINO 2 (SECOND YEAR)",
      "FILIPINO 3 (THIRD YEAR)",
      "FILIPINO 4 (FOURTH YEAR)",
      "FILIPINO 5 (FIFTH YEAR)",
      "FILIPINO 6 (SIXTH YEAR)",
      "FILIPINO LANGUAGE & LITERATURE",
      "FILIPINO LITERATURE",
      "GERMAN 1 (FIRST YEAR)",
      "GERMAN 2 (SECOND YEAR)",
      "GERMAN 3 (THIRD YEAR)",
      "GERMAN 4 (FOURTH YEAR)",
      "GERMAN 5 (FIFTH YEAR)",
      "GERMAN 6 (SIXTH YEAR)",
      "GERMAN LANGUAGE & CULTURE",
      "GERMAN LANGUAGE & LITERATURE",
      "GERMAN LITERATURE",
      "GREEK 1 (FIRST YEAR)",
      "GREEK 2 (SECOND YEAR)",
      "GREEK 3 (THIRD YEAR)",
      "GREEK 4 (FOURTH YEAR)",
      "GREEK 5 (FIFTH YEAR)",
      "GREEK 6 (SIXTH YEAR)",
      "GREEK LANGUAGE & LITERATURE",
      "GREEK LITERATURE",
      "HEBREW 1 (FIRST YEAR)",
      "HEBREW 2 (SECOND YEAR)",
      "HEBREW 3 (THIRD YEAR)",
      "HEBREW 4 (FOURTH YEAR)",
      "HEBREW 5 (FIFTH YEAR)",
      "HEBREW 6 (SIXTH YEAR)",
      "HEBREW LANGUAGE & LITERATURE",
      "HEBREW LITERATURE",
      "HINDI 1 (FIRST YEAR)",
      "HINDI 2 (SECOND YEAR)",
      "HINDI 3 (THIRD YEAR)",
      "HINDI 4 (FOURTH YEAR)",
      "HINDI 5 (FIFTH YEAR)",
      "HINDI 6 (SIXTH YEAR)",
      "ITALIAN 1 (FIRST YEAR)",
      "ITALIAN 2 (SECOND YEAR)",
      "ITALIAN 3 (THIRD YEAR)",
      "ITALIAN 4 (FOURTH YEAR)",
      "ITALIAN 5 (FIFTH YEAR)",
      "ITALIAN 6 (SIXTH YEAR)",
      "ITALIAN LANGUAGE & CULTURE",
      "ITALIAN LANGUAGE & LITERATURE",
      "ITALIAN LITERATURE",
      "JAPANESE 1 (FIRST YEAR)",
      "JAPANESE 2 (SECOND YEAR)",
      "JAPANESE 3 (THIRD YEAR)",
      "JAPANESE 4 (FOURTH YEAR)",
      "JAPANESE 5 (FIFTH YEAR)",
      "JAPANESE 6 (SIXTH YEAR)",
      "JAPANESE LANGUAGE & CULTURE",
      "JAPANESE LANGUAGE & LITERATURE",
      "JAPANESE LITERATURE",
      "KOREAN 1 (FIRST YEAR)",
      "KOREAN 2 (SECOND YEAR)",
      "KOREAN 3 (THIRD YEAR)",
      "KOREAN 4 (FOURTH YEAR)",
      "KOREAN 5 (FIFTH YEAR)",
      "KOREAN 6 (SIXTH YEAR)",
      "KOREAN LANGUAGE & LITERATURE",
      "KOREAN LITERATURE",
      "PORTUGUESE 1 (FIRST YEAR)",
      "PORTUGUESE 2 (SECOND YEAR)",
      "PORTUGUESE 3 (THIRD YEAR)",
      "PORTUGUESE 4 (FOURTH YEAR)",
      "PORTUGUESE 5 (FIFTH YEAR)",
      "PORTUGUESE 6 (SIXTH YEAR)",
      "PORTUGUESE LANGUAGE & LITERATURE",
      "PORTUGUESE LITERATURE",
      "RUSSIAN 1 (FIRST YEAR)",
      "RUSSIAN 2 (SECOND YEAR)",
      "RUSSIAN 3 (THIRD YEAR)",
      "RUSSIAN 4 (FOURTH YEAR)",
      "RUSSIAN 5 (FIFTH YEAR)",
      "RUSSIAN 6 (SIXTH YEAR)",
      "RUSSIAN LANGUAGE & LITERATURE",
      "RUSSIAN LITERATURE",
      "SWAHILI 1 (FIRST YEAR)",
      "SWAHILI 2 (SECOND YEAR)",
      "SWAHILI 3 (THIRD YEAR)",
      "SWAHILI 4 (FOURTH YEAR)",
      "SWAHILI 5 (FIFTH YEAR)",
      "SWAHILI 6 (SIXTH YEAR)",
      "SWAHILI LANGUAGE & LITERATURE",
      "SWAHILI LITERATURE",
      "URDU 1 (FIRST YEAR)",
      "URDU 2 (SECOND YEAR)",
      "URDU 3 (THIRD YEAR)",
      "URDU 4 (FOURTH YEAR)",
      "URDU 5 (FIFTH YEAR)",
      "URDU 6 (SIXTH YEAR)",
      "VIETNAMESE 1 (FIRST YEAR)",
      "VIETNAMESE 2 (SECOND YEAR)",
      "VIETNAMESE 3 (THIRD YEAR)",
      "VIETNAMESE 4 (FOURTH YEAR)",
      "VIETNAMESE 5 (FIFTH YEAR)",
      "VIETNAMESE 6 (SIXTH YEAR)",
      "VIETNAMESE LANGUAGE & LITERATURE",
      "VIETNAMESE LITERATURE",
      "OTHER ENGLISH",
      "OTHER LANGUAGE"
    ],
    "Computer Science / Info Tech": [
      "COMPUTER APPLICATIONS",
      "COMPUTER GRAPHICS DESIGN",
      "COMPUTER KEYBOARDING",
      "COMPUTER PROGRAMMING",
      "COMPUTER SCIENCE 1",
      "COMPUTER SCIENCE 2",
      "INFORMATION TECHNOLOGY",
      "WEB DESIGN AND DEVELOPMENT",
      "OTHER COMPUTER SCIENCE"
    ],
    Business: [
      "ACCOUNTING 1",
      "BUSINESS LAW",
      "BUSINESS MANAGEMENT",
      "ENTREPRENEURSHIP",
      "FINANCE",
      "INTRO TO BUSINESS",
      "MARKETING",
      "ACCOUNTING 2",
      "ADVERTISING",
      "BANKING",
      "BANKING AND FINANCE",
      "COMPUTER BUSINESS APPLICATIONS",
      "CONSUMER LAW",
      "HUMAN RESOURCES",
      "INTERNATIONAL BUSINESS",
      "INVESTING",
      "LEGAL SYSTEM",
      "MANAGEMENT",
      "OTHER BUSINESS",
      "FINANCIAL LITERACY/PERSONAL FINANCE"
    ],
    "Fine Arts / Music": [
      "ART",
      "BAND",
      "CERAMICS",
      "CHORUS",
      "MUSIC",
      "ORCHESTRA",
      "PHOTOGRAPHY",
      "THEATRE ARTS",
      "ACTING/DRAMA",
      "ART HISTORY",
      "CERAMICS 2",
      "CREATIVE ART--DRAW-PAINT-ETC",
      "DANCE",
      "DRAMA",
      "GRAPHIC DESIGN",
      "INSTRUMENTAL MUSIC",
      "MUSIC APPRECIATION",
      "MUSIC HISTORY 1",
      "MUSIC HISTORY 2",
      "MUSIC THEORY 1",
      "MUSIC THEORY 2",
      "PHOTOGRAPHY 2",
      "STUDIO ART",
      "VIDEO PRODUCTION",
      "OTHER FINE ART",
      "OTHER MUSIC"
    ],
    "Phys. Ed / Health / Gym": ["HEALTH EDUCATION", "PHYSICAL EDUCATION", "PHYSICAL EDUCATION AND HEALTH", "VARSITY SPORT", "OTHER PHYSICAL EDUCATION"],
    "Other Subject Area": [
      "ACT/SAT PREPARATION",
      "CULINARY ARTS",
      "DRIVERS EDUCATION",
      "RELIGION",
      "SEMINAR",
      "AGRICULTURE",
      "ARCHITECTURE",
      "CRIMINAL JUSTICE",
      "DIGITAL ELECTRONICS",
      "ETHICS/MORALITY",
      "FAMILY CONSUMER SCIENCE",
      "FRESHMAN SEMINAR",
      "INTERNSHIP",
      "JUNIOR ROTC / ROTC",
      "RESEARCH",
      "ROBOTICS",
      "YEARBOOK",
      "OTHER",
      "CONSTRUCTION / MANUFACTURING",
      "HOSPITALITY / TOURISM",
      "MILITARY SCIENCE",
      "NATURAL RESOURCES /FORESTRY",
      "TRANSPORTATION / LOGISTICS"
    ]
  };
  var STARS_INTL_SUBJECT = {
    english: "Languages",
    mathematics: "Mathematics",
    science: "Science",
    history_social: "History / Social Studies",
    world_language: "Languages",
    arts: "Fine Arts / Music",
    computer_science: "Computer Science / Info Tech",
    business: "Business",
    pe_health: "Phys. Ed / Health / Gym",
    career_technical: "Other Subject Area",
    other: "Other Subject Area"
  };
  var STARS_INTL_LEVEL = {
    regular: "Standard",
    accelerated: "Advanced",
    advanced: "Advanced",
    honors: "Honors",
    high_honors: "Honors",
    ap: "AP (Advanced Placement)",
    ib_hl: "IB (Higher/HL)",
    ib_sl: "IB (Standard/SL)",
    ib: null,
    pre_ib: "Middle Years IB",
    a_level: null,
    gcse_igcse: "IGCSE/GCSE Ordinary Level",
    college_prep: "Standard",
    dual_enrollment: "Dual Enrollment",
    enriched: "Advanced",
    gifted: "Advanced",
    intensive: "Advanced",
    regents: "Standard",
    other: null,
    none: "Not Applicable"
  };
  function starsIntlScalesFor(scale, max) {
    const s = STARS_INTL_SCALES;
    if (scale === "percent_100") return [s[5], s[6]];
    if (scale === "ib_7") return [s[1]];
    if (scale === "gcse_9_1") return [s[0]];
    if (scale === "a_level") return [s[3], s[2]];
    if (scale === "other" && max === 10) return [s[7]];
    if (scale === "other" && max === 20) return [s[4]];
    if ((scale === "other" || scale === "gpa_decimal") && max === 5) return [s[8], s[9], s[10]];
    return [];
  }
  var STARS_US_SUBJECTS = [
    "English",
    "Mathematics",
    "Science",
    "History / Social Studies",
    "World Language",
    "Computer Science / Info Tech",
    "Business",
    "Fine Arts / Music",
    "Phys. Ed / Health / Gym",
    "Other Subject Area"
  ];
  var STARS_US_LEVELS = [
    "Standard",
    "Honors",
    "AP (Advanced Placement)",
    "College Prep",
    "Dual Enrollment",
    "Accelerated",
    "Advanced",
    "AICE",
    "College Credit Plus (CCP)",
    "College in HS",
    "Dual Credit (SDC)",
    "Early College Experience(ECE)",
    "Enriched",
    "Gifted and Talented",
    "High Honors",
    "IB (Higher/HL)",
    "IB (Intl. Baccalaureate)",
    "IB (Predicted)",
    "IB (Standard/SL)",
    "Level 1",
    "Level 2",
    "Level 3",
    "Level 4",
    "Level 5",
    "Pre-AICE",
    "Pre-AP",
    "Pre-Honors",
    "Pre-IB",
    "Regents"
  ];
  var STARS_US_SUBJECT = {
    english: "English",
    mathematics: "Mathematics",
    science: "Science",
    history_social: "History / Social Studies",
    world_language: "World Language",
    arts: "Fine Arts / Music",
    computer_science: "Computer Science / Info Tech",
    business: "Business",
    pe_health: "Phys. Ed / Health / Gym",
    career_technical: "Other Subject Area",
    other: "Other Subject Area"
  };
  var STARS_US_LEVEL = {
    regular: "Standard",
    accelerated: "Accelerated",
    advanced: "Advanced",
    honors: "Honors",
    high_honors: "High Honors",
    ap: "AP (Advanced Placement)",
    ib_hl: "IB (Higher/HL)",
    ib_sl: "IB (Standard/SL)",
    ib: "IB (Intl. Baccalaureate)",
    pre_ib: "Pre-IB",
    a_level: "AICE",
    gcse_igcse: null,
    college_prep: "College Prep",
    dual_enrollment: "Dual Enrollment",
    enriched: "Enriched",
    gifted: "Gifted and Talented",
    intensive: null,
    regents: "Regents",
    other: null,
    none: "Standard"
  };
  var STARS_US_TITLES = {
    English: [
      "ENGLISH 1",
      "ENGLISH 2",
      "ENGLISH 3",
      "ENGLISH 4",
      "ENGLISH LANGUAGE AND COMPOSITION",
      "ENGLISH LANGUAGE AND LITERATURE",
      "ENGLISH LITERATURE AND COMPOSITION",
      "ENGLISH LITERATURE",
      "AMERICAN LITERATURE",
      "BRITISH LITERATURE",
      "CLASSIC LITERATURE",
      "COMMUNICATIONS",
      "CREATIVE WRITING",
      "ENGLISH COMPOSITION 1",
      "ENGLISH COMPOSITION 2",
      "ESL 1 (ENGL AS A SECOND LANG 1)",
      "ESL 2 (ENGL AS A SECOND LANG 2)",
      "FORENSIC SPEECH-DEBATE",
      "JOURNALISM",
      "MYTHOLOGY",
      "PUBLIC SPEAKING",
      "RESEARCH (ENGLISH)",
      "SEMINAR",
      "WORLD LITERATURE",
      "OTHER ENGLISH"
    ],
    Mathematics: [
      "ALGEBRA 1",
      "GEOMETRY",
      "ALGEBRA 2",
      "TRIGONOMETRY",
      "PRECALCULUS",
      "STATISTICS 1",
      "CALCULUS",
      "CALCULUS 1 (AB)",
      "CALCULUS 2 (BC)",
      "CALCULUS 3 (MULTIVARIATE)",
      "STATISTICS 2",
      "ADVANCED MATH",
      "ALGEBRA - ABSTRACT",
      "ALGEBRA 1 PART 1",
      "ALGEBRA 1 PART 2",
      "ALGEBRA 2 PART 1",
      "ALGEBRA 2 PART 2",
      "ALGEBRA 3",
      "APPLIED MATH",
      "BUSINESS MATH",
      "CONSUMER MATH",
      "DIFFERENTIAL EQUATIONS",
      "DISCRETE MATH",
      "ELEMENTARY FUNCTIONS",
      "FINITE MATHEMATICS",
      "GENERAL MATH",
      "INTEGRATED MATH 1",
      "INTEGRATED MATH 2",
      "INTEGRATED MATH 3",
      "INTEGRATED MATH 4",
      "LINEAR ALGEBRA",
      "LINEAR PROGRAMMING",
      "MATH ANALYSIS",
      "PRE-ALGEBRA",
      "SEQUENTIAL MATH 1",
      "SEQUENTIAL MATH 2",
      "SEQUENTIAL MATH 3",
      "TRIGONOMETRY/GEOMETRY",
      "IB MATH ANALYSIS AND APPROACHES HL",
      "IB MATH ANALYSIS AND APPROACHES SL",
      "IB MATH APPLICATIONS AND INTERPRETATIONS HL",
      "IB MATH APPLICATIONS AND INTERPRETATIONS SL",
      "OTHER MATH",
      "ALGEBRA 2/TRIGONOMETRY",
      "ALGEBRA 3/TRIGONOMETRY",
      "COLLEGE ALGEBRA",
      "COLLEGE ALGEBRA/TRIGONOMETRY",
      "COLLEGE MATH",
      "TRIGONOMETRY/PRE-CALCULUS"
    ],
    Science: [
      "BIOLOGY",
      "CHEMISTRY",
      "PHYSICS",
      "ENVIRONMENTAL SCIENCE",
      "EARTH SCIENCE",
      "ANATOMY & PHYSIOLOGY",
      "PHYSICAL SCIENCE",
      "AEROSPACE",
      "AEROSPACE ENGINEERING",
      "ANATOMY",
      "ASTRONOMY",
      "BOTANY",
      "CIVIL ENGINEERING",
      "ECOLOGY",
      "ELECTRICITY AND MAGNETISM",
      "ENGINEERING DESIGN AND DEVELOPMENT",
      "FORENSIC SCIENCE",
      "GENETICS",
      "GEOLOGY",
      "INTEGRATED SCIENCE",
      "INTRO TO ENGINEERING",
      "INTRO TO SCIENCE",
      "LIFE SCIENCE",
      "MARINE SCIENCE/BIOLOGY",
      "METEOROLOGY",
      "MICROBIOLOGY",
      "NUTRITION/FOOD SCIENCE",
      "OCEANOGRAPHY",
      "ORGANIC CHEMISTRY",
      "PHYSIOLOGY",
      "PRINCIPLES OF ENGINEERING",
      "SCIENCE, TECH, & SOCIETY",
      "ZOOLOGY",
      "OTHER SCIENCE"
    ],
    "History / Social Studies": STARS_INTL_TITLES["History / Social Studies"],
    "World Language": [
      ...[
        "SPANISH",
        "FRENCH",
        "LATIN",
        "AMERICAN INDIAN",
        "AMERICAN SIGN LANGUAGE",
        "ARABIC",
        "CHINESE",
        "CLASSICAL GREEK",
        "CLASSICAL HEBREW",
        "FILIPINO",
        "GERMAN",
        "GREEK",
        "HEBREW",
        "HINDI",
        "ITALIAN",
        "JAPANESE",
        "KOREAN",
        "PORTUGUESE",
        "RUSSIAN",
        "SWAHILI",
        "URDU",
        "VIETNAMESE"
      ].flatMap((l) => [1, 2, 3, 4, 5, 6].map((n) => `${l} ${n}`)),
      "SPANISH FOR NATIVE SPEAKERS",
      "SPANISH LANGUAGE & CULTURE",
      "SPANISH LANGUAGE & LITERATURE",
      "SPANISH LITERATURE",
      "SPANISH LITERATURE & CULTURE",
      "FRENCH LANGUAGE & CULTURE",
      "FRENCH LANGUAGE & LITERATURE",
      "FRENCH LITERATURE",
      "AMERICAN INDIAN IMMERSION",
      "AMERICAN INDIAN LANGUAGE & LITERATURE",
      "AMERICAN INDIAN LITERATURE",
      "ARABIC LANGUAGE & LITERATURE",
      "ARABIC LITERATURE",
      "BRAILLE",
      "CHINESE LANGUAGE & CULTURE",
      "CHINESE LANGUAGE & LITERATURE",
      "CHINESE LITERATURE",
      "FILIPINO LANGUAGE & LITERATURE",
      "FILIPINO LITERATURE",
      "GERMAN LANGUAGE & CULTURE",
      "GERMAN LANGUAGE & LITERATURE",
      "GERMAN LITERATURE",
      "GREEK LANGUAGE & LITERATURE",
      "GREEK LITERATURE",
      "HEBREW LANGUAGE & LITERATURE",
      "HEBREW LITERATURE",
      "ITALIAN LANGUAGE & CULTURE",
      "ITALIAN LANGUAGE & LITERATURE",
      "ITALIAN LITERATURE",
      "JAPANESE LANGUAGE & CULTURE",
      "JAPANESE LANGUAGE & LITERATURE",
      "JAPANESE LITERATURE",
      "KOREAN LANGUAGE & LITERATURE",
      "KOREAN LITERATURE",
      "PORTUGUESE LANGUAGE & LITERATURE",
      "PORTUGUESE LITERATURE",
      "RUSSIAN LANGUAGE & LITERATURE",
      "RUSSIAN LITERATURE",
      "SWAHILI LANGUAGE & LITERATURE",
      "SWAHILI LITERATURE",
      "VIETNAMESE LANGUAGE & LITERATURE",
      "VIETNAMESE LITERATURE",
      "OTHER LANGUAGE"
    ],
    "Computer Science / Info Tech": STARS_INTL_TITLES["Computer Science / Info Tech"],
    Business: STARS_INTL_TITLES.Business,
    "Fine Arts / Music": STARS_INTL_TITLES["Fine Arts / Music"],
    "Phys. Ed / Health / Gym": STARS_INTL_TITLES["Phys. Ed / Health / Gym"],
    "Other Subject Area": STARS_INTL_TITLES["Other Subject Area"]
  };

  // ../web/lib/transcript-maps/stars-titles.ts
  var ROMAN = { I: "1", II: "2", III: "3", IV: "4", V: "5", VI: "6" };
  var NOISE = /* @__PURE__ */ new Set(["AP", "HONORS", "HONOR", "HON", "IB", "HL", "SL", "ADVANCED", "PLACEMENT", "LEVEL", "LABORATORY", "LAB", "SEMESTER", "ACCELERATED", "ENRICHED", "PRE-AP", "THE", "OF"]);
  function words(s) {
    return s.normalize("NFKC").toUpperCase().replace(/\bU\.S\.?/g, "US").replace(/\bUNITED STATES\b/g, "US").replace(/&/g, " AND ").replace(/\([^)]*\)/g, " ").replace(/[^A-Z0-9 ]+/g, " ").split(/\s+/).filter(Boolean).map((w) => ROMAN[w] ?? w);
  }
  function nameWords(name) {
    const w = words(name);
    const out = [];
    for (let i = 0; i < w.length; i++) {
      if ((w[i] === "LEVEL" || w[i] === "SEMESTER") && /^\d$/.test(w[i + 1] ?? "")) {
        i++;
        continue;
      }
      if (NOISE.has(w[i]) || /^(9|10|11|12)$/.test(w[i])) continue;
      out.push(w[i]);
    }
    return out;
  }
  var YEAR_WORD = ["FIRST", "SECOND", "THIRD", "FOURTH"];
  function matchStarsTitle(name, subject, gradeLevel, list, kind) {
    const other = list.find((t) => t.startsWith(subject === "english" ? "OTHER ENGLISH" : "OTHER")) ?? list.find((t) => t.startsWith("OTHER")) ?? list[list.length - 1];
    const upper3 = name.normalize("NFKC").trim().toUpperCase().replace(/\s+/g, " ");
    if (list.includes(upper3)) return { title: upper3, how: "exact" };
    const all = words(name);
    if (subject === "english" && all[0] === "ENGLISH" && gradeLevel != null && gradeLevel >= 9 && gradeLevel <= 12 && (all.length === 1 || /^(9|10|11|12)$/.test(all[1]))) {
      const n = gradeLevel - 8;
      const title = kind === "intl" ? `ENGLISH ${gradeLevel} (${YEAR_WORD[n - 1]} YEAR)` : `ENGLISH ${n}`;
      if (list.includes(title)) return { title, how: "matched" };
    }
    const have = new Set(nameWords(name));
    let best = null;
    for (const t of list) {
      if (t.startsWith("OTHER")) continue;
      const tw = words(t);
      if (!tw.length || !tw.every((w) => have.has(w))) continue;
      if (!best || tw.length > best.size) best = { title: t, size: tw.length };
    }
    return best ? { title: best.title, how: "matched" } : { title: other, how: "other" };
  }

  // ../web/lib/transcript-maps/stars.ts
  var HELP2 = "https://starsrecord.zendesk.com/hc/en-us/articles";
  var SUBJECT_SRC = `${HELP2}/37027194180251`;
  var LEVEL_SRC = `${HELP2}/37036006202523`;
  var LENGTH_SRC = `${HELP2}/37036235354779`;
  var IB3 = verified("International Baccalaureate (IB)", LEVEL_SRC);
  var LIVE2 = "https://srar.selfreportedtranscript.com";
  var OTHER_LEVEL = unverified(null, "STARS's full Course Level dropdown could not be retrieved", LEVEL_SRC);
  var STARS_MAP = {
    id: "stars",
    label: "STARS",
    level: table(
      LEVELS,
      {
        regular: verified("Standard", LEVEL_SRC, "The default when no other level applies"),
        honors: verified("Honors", LEVEL_SRC),
        ap: verified("Advanced Placement (AP)", LEVEL_SRC),
        ib_hl: IB3,
        ib_sl: IB3,
        ib: IB3,
        dual_enrollment: verified("Dual Enrollment", LEVEL_SRC, "Needs the college name"),
        college_prep: verified("College Prep", LEVEL_SRC),
        regents: verified("Regents", LEVEL_SRC),
        gifted: verified("Gifted and Talented", LEVEL_SRC),
        other: unverified("Standard", "Assumed; STARS's full list could not be retrieved", LEVEL_SRC),
        none: unverified("Standard", "Assumed; STARS's full list could not be retrieved", LEVEL_SRC)
      },
      OTHER_LEVEL
    ),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", SUBJECT_SRC),
        mathematics: verified("Mathematics", SUBJECT_SRC),
        science: verified("Science", SUBJECT_SRC),
        history_social: verified("History / Social Studies", SUBJECT_SRC),
        world_language: verified("World Language", SUBJECT_SRC),
        arts: verified("Fine Arts / Music", SUBJECT_SRC),
        computer_science: verified("Computer Science / Info Tech", LIVE2),
        business: verified("Business", SUBJECT_SRC),
        pe_health: verified("Phys. Ed / Health / Gym", LIVE2),
        career_technical: unverified("Other Subject Area", "No career-technical area exists in STARS's list", SUBJECT_SRC),
        other: unverified("Other Subject Area", void 0, SUBJECT_SRC)
      },
      unverified(null)
    ),
    subjectList: {
      options: [
        "English",
        "Mathematics",
        "Science",
        "History / Social Studies",
        "World Language",
        "Computer Science / Info Tech",
        "Business",
        "Fine Arts / Music",
        "Phys. Ed / Health / Gym",
        "Other Subject Area"
      ],
      verified: true,
      note: 'Psychology and economics go under History / Social Studies. Music, band, choir, art, dance and theater are all "Fine Arts / Music". STARS also asks for a Generic Course Title under each subject; those lists are not published.'
    },
    subSubject: () => unverified(null, "STARS's Generic Course Title lists could not be retrieved", SUBJECT_SRC),
    period: table(
      PERIOD_TYPES,
      {
        full_year: verified("Full Year", LENGTH_SRC),
        semester: verified("Semester", LENGTH_SRC),
        trimester: verified("Trimester", LENGTH_SRC),
        quarter: verified("Quarterly", LENGTH_SRC)
      },
      unverified(null)
    ),
    genericTitle: (school, course) => {
      const us = !isNonUs(school);
      const list = us ? STARS_US_TITLES[STARS_US_SUBJECT[course.subject]] : STARS_INTL_TITLES[STARS_INTL_SUBJECT[course.subject]];
      const m = matchStarsTitle(course.name, course.subject, course.gradeLevel, list, us ? "us" : "intl");
      if (m.how === "exact") return verified(m.title, LIVE2);
      if (m.how === "matched") return unverified(m.title, "Matched from the course name; change it if a closer title fits", LIVE2);
      return unverified(m.title, "No title in STARS's list matches the course name; pick a closer one if there is", LIVE2);
    },
    rules: (_school, course) => {
      const out = [];
      if (course.terms.some((t) => t.gradeWeighted)) out.push("STARS wants the unweighted grade when both are printed.");
      if (course.terms.some((t) => t.status === "in_progress")) out.push("Enter IP (In Progress) for courses without a final grade.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/uc-lists.ts
  var UC_DISCIPLINES = [
    { area: "History/Social Science", text: "Civics/American Government", value: "3" },
    { area: "History/Social Science", text: "U.S. History", value: "2" },
    { area: "History/Social Science", text: "World History/Cultures/Hist. Geography", value: "1" },
    { area: "English", text: "English", value: "4" },
    { area: "English", text: "English-ESL/ELD", value: "5" },
    { area: "Mathematics", text: "Algebra I", value: "6" },
    { area: "Mathematics", text: "Geometry", value: "7" },
    { area: "Mathematics", text: "Algebra II", value: "8" },
    { area: "Mathematics", text: "Mathematics I (Integrated)", value: "10" },
    { area: "Mathematics", text: "Mathematics II (Integrated)", value: "11" },
    { area: "Mathematics", text: "Mathematics III (Integrated)", value: "12" },
    { area: "Mathematics", text: "Algebra II/Trigonometry", value: "9" },
    { area: "Mathematics", text: "Statistics", value: "15" },
    { area: "Mathematics", text: "Pre-Calculus", value: "52" },
    { area: "Mathematics", text: "Calculus", value: "14" },
    { area: "Mathematics", text: "Additional Math", value: "56" },
    { area: "Mathematics", text: "Other Advanced Mathematics", value: "13" },
    { area: "Mathematics", text: "Computer Science", value: "16" },
    { area: "Science", text: "Biology/Life Sciences", value: "17" },
    { area: "Science", text: "Biology/Earth & Space Sciences", value: "43" },
    { area: "Science", text: "Chemistry", value: "18" },
    { area: "Science", text: "Chemistry/Earth & Space Sciences", value: "44" },
    { area: "Science", text: "Physics", value: "19" },
    { area: "Science", text: "Physics/Earth & Space Sciences", value: "45" },
    { area: "Science", text: "Integrated Science 1", value: "46" },
    { area: "Science", text: "Integrated Science 2", value: "47" },
    { area: "Science", text: "Integrated Science 3", value: "48" },
    { area: "Science", text: "Applied Science", value: "49" },
    { area: "Science", text: "Computer Science", value: "50" },
    { area: "Science", text: "Earth and Space Sciences", value: "22" },
    { area: "Science", text: "Engineering", value: "51" },
    { area: "Science", text: "Interdisciplinary Sciences", value: "20" },
    { area: "Language Other Than English", text: "Yr 1 Lang Other Than English", value: "23" },
    { area: "Language Other Than English", text: "Yr 2 Lang Other Than English", value: "24" },
    { area: "Language Other Than English", text: "Yr 3 Lang Other Than English", value: "25" },
    { area: "Language Other Than English", text: "Yr 4+ Lang Other Than English", value: "26" },
    { area: "Visual and Performing Arts", text: "Dance", value: "27" },
    { area: "Visual and Performing Arts", text: "Music", value: "28" },
    { area: "Visual and Performing Arts", text: "Theater", value: "29" },
    { area: "Visual and Performing Arts", text: "Visual Arts", value: "30" },
    { area: "Visual and Performing Arts", text: "Interdisciplinary Arts", value: "31" },
    { area: "College-Prep Electives", text: "Elective -English", value: "33" },
    { area: "College-Prep Electives", text: "Elective -English - ESL/ELD", value: "34" },
    { area: "College-Prep Electives", text: "Elective -History/Social Science", value: "32" },
    { area: "College-Prep Electives", text: "Elective -Interdisciplinary", value: "41" },
    { area: "College-Prep Electives", text: "Elective -Language Other Than English", value: "39" },
    { area: "College-Prep Electives", text: "Elective -Mathematics", value: "35" },
    { area: "College-Prep Electives", text: "Elective -Math -Computer Science", value: "42" },
    { area: "College-Prep Electives", text: "Elective -Science-Biology/Life Sciences", value: "36" },
    { area: "College-Prep Electives", text: "Elective -Science-Integrated Science", value: "38" },
    { area: "College-Prep Electives", text: "Elective -Science-Physical Sciences", value: "37" },
    { area: "College-Prep Electives", text: "Elective -Visual & Performing Arts", value: "40" }
  ];
  function ucDisciplineLabels() {
    return UC_DISCIPLINES.map((d) => UC_DISCIPLINES.filter((x) => x.text === d.text).length > 1 ? `${d.text} (${d.area})` : d.text);
  }
  var UC_LANGUAGES = [
    "American Sign Language",
    "Arabic",
    "Armenian",
    "Chinese",
    "Farsi",
    "Filipino",
    "French",
    "German",
    "Greek",
    "Hebrew",
    "Hindi",
    "Hmong",
    "Italian",
    "Japanese",
    "Khmer",
    "Korean",
    "Latin",
    "Other Language",
    "Portuguese",
    "Punjabi",
    "Russian",
    "Spanish",
    "Tamil",
    "Turkish",
    "Vietnamese"
  ];
  var UC_GRADE_CODES = { notTaken: "NO", inProgress: "IP", planned: "PL" };

  // ../web/lib/transcript-maps/uc.ts
  var QRG = "https://admission.universityofcalifornia.edu/counselors/_files/documents/quick-reference-guide-to-uc-admissions.pdf";
  var LIVE3 = "https://apply.universityofcalifornia.edu/my-application/";
  var DAVIS = "https://www.ucdavis.edu/admissions/undergraduate/first-year/application-tips";
  var IB4 = verified("IB", QRG);
  var NH_NOTE = "Flag UC-approved honors courses only";
  var NOT_AG = "Not an A-G subject; it may go under Other coursework in Activities & awards";
  var LETTER_SIGN = /^([A-F])[+-]$/i;
  var PASS_FAIL = /^(p|np|cr|nc|pass|fail|credit|no credit)$/i;
  var allGrades = (c) => [...c.terms.map((t) => t.grade), c.finalGrade ?? ""].filter(Boolean);
  var UC_MAP = {
    id: "uc",
    label: "UC",
    level: table(
      LEVELS,
      {
        ap: verified("AP", QRG),
        ib_hl: IB4,
        ib_sl: IB4,
        ib: IB4,
        honors: unverified("HL", "Only if the course is on the school's UC-approved honors list", QRG),
        dual_enrollment: verified("CL", DAVIS, "College course: enter it under Colleges attended"),
        high_honors: unverified("NH", NH_NOTE, QRG),
        advanced: unverified("NH", NH_NOTE, QRG),
        accelerated: unverified("NH", NH_NOTE, QRG),
        a_level: unverified("NH", "UC gives honors weight only to AP and IB for non-California students", QRG)
      },
      verified("NH", QRG, "Not honors")
    ),
    // UC's "Subject Area/Course Category" is a course category, not an A-G letter (read live 2026-10-27). It follows from our sub-category
    // where that is one-to-one (subjectFor); otherwise it is left for the student or the AI tag.
    subject: table(
      SUBJECTS,
      {
        english: verified("English", LIVE3),
        history_social: unverified(null, "U.S. History, Civics/American Government or World History/Cultures/Hist. Geography: depends on the course", LIVE3),
        world_language: unverified(null, '"Yr 1-4+ Lang Other Than English" by year of study', LIVE3),
        computer_science: unverified(null, "Computer Science is under Mathematics or Science, depending on the school", LIVE3),
        other: unverified(null, "A College-Prep Elective category, depending on the course", LIVE3),
        business: none(NOT_AG),
        pe_health: none(NOT_AG),
        career_technical: none(NOT_AG)
      },
      unverified(null, "Depends on the course", LIVE3)
    ),
    subjectFor: (subject, sub) => {
      const m = {
        mathematics: { algebra_1: "Algebra I", geometry: "Geometry", algebra_2: "Algebra II", precalculus: "Pre-Calculus", calculus: "Calculus", statistics: "Statistics" },
        science: { biology: "Biology/Life Sciences", chemistry: "Chemistry", physics: "Physics", earth_space: "Earth and Space Sciences" },
        arts: { visual: "Visual Arts", music: "Music", theater: "Theater", dance: "Dance", interdisciplinary: "Interdisciplinary Arts" }
      };
      if (!m[subject]) return null;
      const v = sub ? m[subject][sub] : void 0;
      return v ? verified(v, LIVE3) : unverified(null, "Depends on the course", LIVE3);
    },
    subjectList: {
      // UC's own "Subject Area/Course Category" options (read live 2026-10-27); a tag here becomes the course's UC subject.
      options: ucDisciplineLabels(),
      verified: true,
      note: `Pick UC's own course category. A language course is "Yr N Lang Other Than English" by its year of study; Computer Science counts under Mathematics or Science, so say which. PE, business and career-technical courses are not A-G: leave them out for UC.`
    },
    subSubject: (subject, sub) => {
      const POLICY = "A discipline in UC's policy; the application may not ask for it";
      if (subject === "arts") {
        const d = { visual: "Visual Arts", music: "Music", theater: "Theater", dance: "Dance", interdisciplinary: "Interdisciplinary Arts" };
        return sub && d[sub] ? verified(d[sub], QRG, POLICY) : none();
      }
      if (subject === "mathematics") {
        const d = { algebra_1: "Algebra I or Math I", geometry: "Geometry or Math II", algebra_2: "Algebra II or Math III", precalculus: "Precalculus", calculus: "Calculus" };
        return sub && d[sub] ? verified(d[sub], QRG, POLICY) : unverified("Other Advanced Math", POLICY, QRG);
      }
      if (subject === "science") {
        const d = { biology: "Biology/Life Sciences", chemistry: "Chemistry", physics: "Physics", earth_space: "Earth & Space Sciences", integrated: "Integrated Science" };
        return sub && d[sub] ? verified(d[sub], QRG, POLICY) : unverified(null, POLICY, QRG);
      }
      return none();
    },
    period: table(
      PERIOD_TYPES,
      { full_year: unverified("Full year"), semester: unverified("Semester"), trimester: unverified("Trimester"), quarter: unverified("Quarter") },
      unverified(null)
    ),
    termGrade: (t) => t.status === "in_progress" ? "IP" : t.status === "planned" ? "PL" : t.status === "none" ? "NO" : t.grade.replace(LETTER_SIGN, "$1"),
    noCredit: "UC has no per-course credit field",
    rules: (_school, course) => {
      const out = [];
      const grades = allGrades(course);
      if (grades.some((g) => LETTER_SIGN.test(g))) out.push("UC ignores + and -: a B+ is entered as B.");
      if (course.scale === "pass_fail" || grades.some((g) => PASS_FAIL.test(g))) out.push("UC does not accept Pass/Fail grades for A-G courses.");
      if (course.isCollege) out.push("Enter this under Colleges attended, not in the high school section.");
      if (course.isSummer) out.push("Tick the summer box for this grade level.");
      if (course.subject === "pe_health" || course.subject === "career_technical" || course.subject === "business") out.push("Not reportable as A-G; it may go under Other coursework in Activities & awards.");
      if (course.isRepeat) out.push("Report both the original course and the repeat.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/uiuc.ts
  var HELP3 = "https://www.admissions.illinois.edu/international-baccalaureate-application-help/";
  var SRC = HELP3;
  var OTHER_NOTE = "UIUC has no Fine Arts, Computer Science or PE subject; they go under Other";
  var UIUC_SUBJECTS = ["English", "Mathematics", "Science", "Social Science", "Language Other Than English", "Other"];
  var UIUC_MAP = {
    id: "uiuc",
    label: "UIUC SRAR",
    level: table(
      LEVELS,
      {
        regular: verified("Regular", SRC),
        advanced: verified("Advanced", SRC),
        enriched: verified("Enriched", SRC),
        ap: unverified("AP", 'Shown as "AP" / "AP Course" on a low-resolution screenshot', SRC),
        ib_hl: verified("IB HL", SRC),
        ib_sl: verified("IB SL", SRC),
        honors: unverified("Honors", "UIUC's tutorial mentions honors; not seen on an official screenshot", SRC),
        none: none("Leave Type empty unless the transcript lists one")
      },
      unverified(null, "UIUC's full Type list is not published; choose a Type only if the transcript lists it", SRC)
    ),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", SRC),
        mathematics: verified("Mathematics", SRC),
        science: verified("Science", SRC),
        history_social: verified("Social Science", SRC),
        world_language: verified("Language Other Than English", SRC),
        arts: verified("Other", SRC, OTHER_NOTE),
        computer_science: verified("Other", SRC, OTHER_NOTE),
        pe_health: verified("Other", SRC, OTHER_NOTE),
        career_technical: verified("Other", SRC, OTHER_NOTE),
        business: unverified("Other", "Business may be Social Science or Other", SRC),
        other: verified("Other", SRC)
      },
      unverified(null)
    ),
    subjectList: { options: UIUC_SUBJECTS, verified: true, note: 'Arts, computer science, PE and everything that is not one of the five core subjects are "Other".' },
    subSubject: () => none("UIUC has no sub-category"),
    period: table(
      PERIOD_TYPES,
      {
        full_year: verified("All Year", SRC),
        semester: verified("1st Semester / 2nd Semester", SRC, "Enter one row per semester"),
        trimester: unverified(null, "Trimester labels are not published; enter one row per trimester", SRC),
        quarter: unverified(null, "Quarter labels are not published; enter one row per quarter", SRC)
      },
      unverified(null)
    ),
    noCredit: "UIUC's SRAR has no credit field",
    rules: (_school, course) => {
      const out = [];
      if (course.terms.length > 0 && course.finalGrade) out.push("UIUC wants every semester, trimester or quarter grade listed separately; do not list a final grade.");
      if (course.terms.some((t) => t.status === "in_progress")) out.push("Enter IP (In Progress) for senior-year courses without a grade.");
      if (course.isRepeat) out.push("Tick Repeated Course.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/ut.ts
  var FAQ = "https://admissions.utexas.edu/apply/frequently-asked-questions/";
  var UT_SUBJECTS = ["English", "Mathematics", "Science", "Social Studies", "Language Other Than English", "Other"];
  var UT_MAP = {
    id: "ut",
    label: "UT Austin",
    level: table(LEVELS, {}, unverified(null, "UT's form levels are behind a login", FAQ)),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", FAQ),
        mathematics: verified("Mathematics", FAQ),
        science: verified("Science", FAQ),
        history_social: verified("Social Studies", FAQ),
        world_language: verified("Language Other Than English", FAQ)
      },
      verified("Other", FAQ, "Other coursework is optional")
    ),
    subjectList: { options: UT_SUBJECTS, verified: true, note: 'Five principal areas; "Other" coursework is optional.' },
    subSubject: () => none("UT's form has no documented sub-category"),
    period: table(PERIOD_TYPES, {}, unverified(null, "UT's term options are behind a login", FAQ)),
    rules: (_school, course) => {
      const out = [];
      if (course.terms.some((t) => t.status === "in_progress" || t.status === "planned")) out.push("UT's form takes completed courses only; leave in-progress and planned courses out.");
      if (course.isSummer) out.push("Enter summer courses under the grade level before or after.");
      if (course.credit == null) out.push("If the transcript shows no credit, UT counts a year-long course as 1 credit and a semester course as 0.5.");
      return out;
    }
  };

  // ../web/lib/transcript-maps.ts
  var SYSTEMS = {
    common_app: COMMON_APP_MAP,
    stars: STARS_MAP,
    csu: CSU_MAP,
    uc: UC_MAP,
    uiuc: UIUC_MAP,
    ut: UT_MAP
  };
  var SYSTEM_IDS = Object.keys(SYSTEMS);
  var OVERRIDE_NOTE = "Set on this course";
  var yearLabel = (y) => `${y}-${String((y + 1) % 100).padStart(2, "0")}`;
  var defaultTermGrade = (t) => t.status === "none" ? null : t.grade || (t.status === "in_progress" ? "In progress" : t.status === "planned" ? "Planned" : "");
  function gradesValue(course, termGrade) {
    const parts = course.terms.flatMap((t) => {
      const g = termGrade(t);
      return g == null ? [] : [`${t.term}: ${g}`.trimEnd()];
    });
    if (course.finalGrade) parts.push(course.terms.length ? `Final: ${course.finalGrade}` : course.finalGrade);
    return parts.length ? parts.join(", ") : null;
  }
  function mapCourse(system, school, course) {
    const map = SYSTEMS[system];
    const ov = course.overrides[system] ?? {};
    const pick = (entry, override) => override ? { value: override, status: "verified", note: OVERRIDE_NOTE, overridden: true } : { value: entry.value, status: entry.status, note: entry.note, source: entry.source };
    const credit = course.credit == null ? course.creditUnit === "not_listed" ? "N/A" : null : String(course.credit);
    const fields = [
      { key: "name", label: "Course name", value: course.name, status: "verified" },
      { key: "year", label: "School year", value: yearLabel(course.academicYear), status: "verified" },
      { key: "gradeLevel", label: "Grade level", value: course.gradeLevel == null ? null : String(course.gradeLevel), status: "verified" },
      { key: "subject", label: "Subject", ...pick(map.subjectFor?.(course.subject, course.subSubject) ?? map.subject[course.subject], ov.subject) },
      { key: "subSubject", label: "Sub-subject", ...pick(map.subSubject(course.subject, course.subSubject), ov.subSubject) },
      ...map.genericTitle ? [{ key: "genericTitle", label: "Generic course title", ...pick(map.genericTitle(school, course), ov.genericTitle) }] : [],
      { key: "level", label: "Course level", ...pick(map.level[course.level], ov.level) },
      { key: "period", label: "Term system", ...pick(map.period[course.period], ov.period) },
      { key: "grades", label: "Grades", value: gradesValue(course, map.termGrade ?? defaultTermGrade), status: "verified" },
      {
        key: "credit",
        label: "Credit",
        ...ov.credit ? pick({ value: null, status: "none" }, ov.credit) : map.noCredit ? { value: null, status: "none", note: map.noCredit } : { value: credit, status: "verified" }
      }
    ];
    return { system, fields, warnings: map.rules(school, course) };
  }

  // ../web/lib/system-fill.ts
  var FILL_SYSTEMS = ["uc", "stars", "csu", "uiuc", "ut"];
  var LETTER_SIGN2 = /^([A-F])[+-]$/i;
  var isLowerGrade = (c) => c.gradeLevel != null && c.gradeLevel < 9;
  var termBox = (t, value) => ({ term: t.term, label: TERM_LABEL[t.term], value });
  var finalBox = (value) => ({ term: "final", label: "Final", value });
  var unfinished = (c) => c.terms.some((t) => t.status === "in_progress" || t.status === "planned");
  function termsThenFinal(c, code, withFinal) {
    const out = [];
    for (const t of c.terms) {
      if (t.term === "FY") continue;
      const v = code(t);
      if (v != null && v !== "") out.push(termBox(t, v));
    }
    const fy = c.terms.find((t) => t.term === "FY");
    const final = c.finalGrade?.trim() || (fy ? code(fy) : null);
    if ((withFinal || out.length === 0) && final) out.push(finalBox(final));
    return out;
  }
  var RULES = {
    // UC Quick Reference Guide (Aug 2026): codes NO / IP / PL, no +/- in high school, no Pass/Fail for A-G, college courses in their own tab,
    // 7th/8th grade only for math and LOTE (no grades entered), non-A-G courses under Activities & awards > Other coursework.
    uc: {
      exclude: (school, c) => {
        if (school.kind !== "high_school" || c.isCollege) return "college course: enter it under Colleges attended while in high school";
        if (["business", "pe_health", "career_technical"].includes(c.subject)) return "not an A-G subject: add it under Activities & awards > Other coursework if you want";
        if (isLowerGrade(c) && c.subject !== "mathematics" && c.subject !== "world_language") return "UC takes 7th/8th grade courses only for math and language other than English";
        return null;
      },
      grades: (c) => {
        if (isLowerGrade(c)) return [];
        const code = (t) => t.status === "in_progress" ? "IP" : t.status === "planned" ? "PL" : t.status === "none" ? "NO" : t.grade.trim().replace(LETTER_SIGN2, "$1");
        return termsThenFinal(c, code, false).map((g) => g.term === "final" ? { ...g, value: g.value.replace(LETTER_SIGN2, "$1") } : g);
      },
      notes: [
        "UC drops + and -: a B+ is entered as B.",
        "Use NO for a term the course did not run, IP for in progress and PL for planned.",
        "UC asks for the school's grading system and term system once per school; pick the ones shown on each group below."
      ]
    },
    // STARS help center: unweighted grade; Full Year + only the final when the transcript prints a year grade; IP for courses without a final.
    stars: {
      exclude: (school) => school.kind === "college" ? "college transcript: STARS takes only dual-enrollment courses that appear on the high-school transcript" : null,
      grades: (c) => {
        const final = c.finalGrade?.trim();
        if (final && c.terms.some((t) => t.term !== "FY")) return [finalBox(final)];
        return termsThenFinal(c, (t) => t.status === "in_progress" || t.status === "planned" ? "IP" : t.status === "none" ? null : t.grade.trim(), false);
      },
      period: (c) => c.finalGrade?.trim() ? "Full Year" : null,
      extra: (c) => c.isCollege && c.collegeName.trim() ? [{ key: "college", label: "College name", value: c.collegeName.trim(), status: "verified" }] : [],
      notes: ['When the transcript prints a year grade, STARS wants Course Length "Full Year" and only that grade.', "Courses without a final grade get IP (In Progress)."]
    },
    // Cal State Apply help center: per-term grade, In Progress / Planned / No Grade / No Course, summer switch, college courses elsewhere.
    csu: {
      exclude: (school, c) => school.kind !== "high_school" || c.isCollege ? "college course: enter it under College Coursework" : null,
      grades: (c) => termsThenFinal(c, (t) => t.status === "in_progress" ? "In Progress" : t.status === "planned" ? "Planned" : t.status === "none" ? "No Grade / No Course" : t.grade.trim(), false),
      extra: (c) => [{ key: "summer", label: "Summer course", value: c.isSummer ? "Yes" : "No", status: "verified" }],
      notes: ["Repeated course: Cal State Apply wants only the highest grade.", "Students who attended only high schools outside the US skip course entry."]
    },
    // UIUC first-year FAQ: list every term grade, never average; no final grade when terms exist; IP for senior courses in progress.
    uiuc: {
      exclude: () => null,
      grades: (c) => termsThenFinal(c, (t) => t.status === "in_progress" || t.status === "planned" ? "IP" : t.status === "none" ? null : t.grade.trim(), false),
      extra: (c) => c.isRepeat ? [{ key: "repeat", label: "Repeated course", value: "Yes", status: "verified" }] : [],
      notes: ["UIUC wants every semester, trimester or quarter grade on its own; do not enter a year average."]
    },
    // UT Austin FAQ: completed courses only; dual credit is reported as a transfer institution.
    ut: {
      exclude: (school, c) => {
        if (school.kind !== "high_school" || c.isCollege) return "dual credit: UT wants it reported as a transfer institution";
        if (unfinished(c)) return "not finished: UT's form takes completed courses only";
        return null;
      },
      grades: (c) => termsThenFinal(c, (t) => t.status === "graded" ? t.grade.trim() : null, true),
      notes: ["UT's Academic Coursework Entry Form appears in MyStatus only for applicants from high schools outside Texas."]
    }
  };
  var FIELD_LABEL = { subject: "Subject", subSubject: "Discipline", genericTitle: "Course/Exam Content", level: "Level", period: "Term system", credit: "Credit" };
  var LIVE_STARS = "Read on STARS's page for schools outside the US";
  function starsIntl(c, key2) {
    const ov = c.overrides.stars?.[key2];
    const list = key2 === "subject" ? STARS_INTL_SUBJECTS : STARS_INTL_LEVELS;
    const hit = ov ? list.find((o) => o.toLowerCase() === ov.toLowerCase()) : void 0;
    if (hit) return { value: hit, status: "verified" };
    if (key2 === "subject") return { value: STARS_INTL_SUBJECT[c.subject], status: "verified", note: LIVE_STARS };
    const level = c.isCollege ? "Dual Enrollment" : STARS_INTL_LEVEL[c.level];
    return level ? { value: level, status: "verified", note: LIVE_STARS } : { value: null, status: "unverified", note: "No single STARS level fits; pick it on STARS" };
  }
  function fieldsFor(system, school, c) {
    const mapped = mapCourse(system, school, c);
    const fields = [{ key: "name", label: "Course name", value: c.name, status: "verified" }];
    const intl = system === "stars" && isNonUs(school);
    for (const key2 of ["subject", "subSubject", "genericTitle", "level", "period", "credit"]) {
      const found = mapped.fields.find((x) => x.key === key2);
      if (!found) continue;
      let f = found;
      if (intl && (key2 === "subject" || key2 === "level")) f = starsIntl(c, key2);
      let value = f.value;
      if (key2 === "period") value = RULES[system].period?.(c) ?? value;
      if (key2 === "level" && system === "stars" && !intl && c.isCollege && !c.overrides.stars?.level) value = "Dual Enrollment";
      if (value == null || f.status === "none") continue;
      fields.push({ key: key2, label: FIELD_LABEL[key2], value, status: f.status, ...f.note ? { note: f.note } : {} });
    }
    fields.push(...RULES[system].extra?.(c) ?? []);
    return { fields, warnings: mapped.warnings };
  }
  var gradeTitle = (g) => g == null ? "Other courses" : `Grade ${g}`;
  function buildSystemPlan(system, schools, courses) {
    const rules = RULES[system];
    const byId = new Map(schools.map((s) => [s.id, s]));
    const skipped = [];
    const groups = /* @__PURE__ */ new Map();
    const sorted = [...courses].sort((a, b) => {
      const sa = schools.findIndex((s) => s.id === a.schoolId), sb = schools.findIndex((s) => s.id === b.schoolId);
      return sa - sb || (a.gradeLevel ?? 99) - (b.gradeLevel ?? 99) || a.academicYear - b.academicYear || a.sortOrder - b.sortOrder;
    });
    for (const c of sorted) {
      const school = byId.get(c.schoolId);
      if (!school) continue;
      const why = rules.exclude(school, c);
      if (why) {
        skipped.push({ course: c.name, reason: why });
        continue;
      }
      const { fields, warnings } = fieldsFor(system, school, c);
      const grades = rules.grades(c);
      if (!grades.length && !isLowerGrade(c)) warnings.push("No grades in the tracker for this course");
      const key2 = `${school.id}|${c.gradeLevel ?? "other"}|${c.academicYear}`;
      let group = groups.get(key2);
      if (!group) {
        group = { key: key2, schoolName: school.name, gradeLevel: c.gradeLevel, year: yearLabel(c.academicYear), title: `${gradeTitle(c.gradeLevel)} \xB7 ${yearLabel(c.academicYear)} \xB7 ${school.name}`, rows: [] };
        groups.set(key2, group);
      }
      group.rows.push({ trackerId: c.id, name: c.name, fields, grades, warnings });
    }
    return { system, label: SYSTEMS[system].label, groups: [...groups.values()], skipped, notes: rules.notes };
  }
  function rowValues(row) {
    return [...row.fields.map((f) => ({ label: f.label, value: f.value })), ...row.grades.map((g) => ({ label: `Grade: ${g.label}`, value: g.value }))];
  }

  // ../web/lib/stars-fill.ts
  var LENGTH = { full_year: "Full Year", semester: "Semester", trimester: "Trimester", quarter: "Quarterly" };
  var NOT_TAKEN = "No Grade - Not In Progress";
  var IN_PROGRESS = "In Progress";
  var upper = (s) => s.normalize("NFKC").trim().toUpperCase().replace(/\s+/g, " ");
  var creditText = (n) => String(addCredits([n]));
  function starsIntlGrade(printed) {
    const g = printed.trim();
    if (/^\d{1,3}$/.test(g) && Number(g) >= 1 && Number(g) <= 200) return String(Number(g));
    return STARS_INTL_GRADE_WORDS.find((w) => normalizeName(w) === normalizeName(g)) ?? null;
  }
  var LISTS = {
    intl: { subjects: STARS_INTL_SUBJECTS, subject: STARS_INTL_SUBJECT, titles: STARS_INTL_TITLES, levels: STARS_INTL_LEVELS, level: STARS_INTL_LEVEL },
    us: { subjects: STARS_US_SUBJECTS, subject: STARS_US_SUBJECT, titles: STARS_US_TITLES, levels: STARS_US_LEVELS, level: STARS_US_LEVEL }
  };
  function subjectOf(c, kind) {
    const ov = c.overrides.stars?.subject;
    const hit = ov ? LISTS[kind].subjects.find((s) => normalizeName(s) === normalizeName(ov)) : void 0;
    return hit ?? LISTS[kind].subject[c.subject];
  }
  function titleOf(c, kind, subject, other) {
    const list = LISTS[kind].titles[subject];
    const ov = c.overrides.stars?.genericTitle;
    if (ov && list.includes(upper(ov))) return upper(ov);
    const m = matchStarsTitle(c.name, c.subject, c.gradeLevel, list, kind);
    if (m.how === "other") other.push(c.name);
    return m.title;
  }
  function levelOf(c, kind, skipped) {
    const ov = c.overrides.stars?.level;
    const hit = ov ? LISTS[kind].levels.find((l) => normalizeName(l) === normalizeName(ov)) : void 0;
    const level = hit ?? (c.isCollege ? "Dual Enrollment" : LISTS[kind].level[c.level]);
    if (!level) skipped.push({ course: c.name, field: "Proficiency Level", reason: "no single STARS level fits this course's level; pick it on STARS" });
    return level;
  }
  function starsUsGrade(printed) {
    const g = printed.trim();
    if (!g) return null;
    if (/^\d{1,3}$/.test(g)) return String(Number(g));
    return STARS_INTL_GRADE_WORDS.find((w) => normalizeName(w) === normalizeName(g)) ?? g.toUpperCase();
  }
  function boxesOf(c, kind, skipped) {
    const grade = (printed, what) => {
      const g = kind === "intl" ? starsIntlGrade(printed) : starsUsGrade(printed);
      if (g == null && printed.trim()) skipped.push({ course: c.name, field: `${what} grade`, reason: `"${printed}" is not a grade STARS lists on this scale; type it yourself` });
      return g;
    };
    const final = c.finalGrade?.trim() ?? "";
    const fy = c.terms.find((t) => t.term === "FY");
    const termOnly = c.terms.filter((t) => t.term !== "FY");
    if (c.period === "full_year" || final && termOnly.length) {
      const status = fy?.status ?? (final ? "graded" : null);
      const g = final || (fy?.status === "graded" ? fy.grade : "");
      const value = status === "in_progress" || status === "planned" ? IN_PROGRESS : g ? grade(g, "Year") : null;
      if (value == null && !g) skipped.push({ course: c.name, field: "Year grade", reason: "no year grade in the tracker" });
      const credit = c.credit ?? fy?.credit ?? null;
      return { length: "Full Year", boxes: [{ grade: value, credit: credit == null ? null : creditText(credit) }], split: false };
    }
    const codes = TERMS_FOR_PERIOD[c.period].filter((t) => t !== "FY");
    const termOf = (code) => termOnly.find((t) => t.term === code);
    const hasTermCredits = termOnly.some((t) => t.status !== "none" && t.credit != null);
    const taken = codes.filter((code) => {
      const t = termOf(code);
      return t && t.status !== "none";
    });
    const share = !hasTermCredits && c.credit != null && taken.length ? creditText(c.credit / taken.length) : null;
    const boxes = codes.map((code) => {
      const t = termOf(code);
      if (!t || t.status === "none") return { grade: NOT_TAKEN, credit: termOnly.length && (hasTermCredits || share) ? "0" : null };
      const g = t.status === "graded" ? t.grade.trim() ? grade(t.grade, code) : null : IN_PROGRESS;
      if (t.status === "graded" && !t.grade.trim()) skipped.push({ course: c.name, field: `${code} grade`, reason: "the grade is missing in the tracker" });
      return { grade: g, credit: t.credit != null ? creditText(t.credit) : share };
    });
    return { length: LENGTH[c.period], boxes, split: share != null };
  }
  function buildStarsPlans(schools, courses) {
    const byId = new Map(schools.map((s) => [s.id, s]));
    const plans = /* @__PURE__ */ new Map();
    for (const c of [...courses].sort((a, b) => a.academicYear - b.academicYear || a.sortOrder - b.sortOrder)) {
      const school = byId.get(c.schoolId);
      if (!school || school.kind !== "high_school") continue;
      const kind = isNonUs(school) ? "intl" : "us";
      const key2 = `${school.id}|${c.academicYear}`;
      let plan = plans.get(key2);
      if (!plan) {
        plan = { kind, endYear: c.academicYear + 1, schoolName: school.name, schoolCode: school.schoolCode, scaleQuestions: [], rows: [], skipped: [], warnings: [], titleOther: [], creditsSplit: 0 };
        plans.set(key2, plan);
      }
      const gl = c.gradeLevel;
      if (gl == null || gl < 9 || gl > 13) {
        plan.skipped.push({ course: c.name, field: "course", reason: "STARS's coursework pages take grades 9-13; set the grade level in the tracker or enter it by hand" });
        continue;
      }
      const subject = subjectOf(c, kind);
      const title = titleOf(c, kind, subject, plan.titleOther);
      const level = levelOf(c, kind, plan.skipped);
      const { length, boxes, split } = boxesOf(c, kind, plan.skipped);
      if (split) plan.creditsSplit++;
      const scaleOptions = kind === "intl" ? starsIntlScalesFor(c.scale, c.scaleMax) : [];
      if (scaleOptions.length > 1 && !plan.scaleQuestions.some((q) => q.join("|") === scaleOptions.join("|"))) plan.scaleQuestions.push(scaleOptions);
      if (kind === "intl" && !scaleOptions.length) plan.skipped.push({ course: c.name, field: "Grading Scale", reason: "STARS's international page has no scale for this kind of grade (e.g. letters); pick one on STARS" });
      const academicLevel = kind === "intl" ? STARS_INTL_ACADEMIC_LEVELS[gl - 9] : null;
      plan.rows.push({ trackerId: c.id, name: c.name, academicLevel, subject, title, level, length, scaleOptions, boxes });
    }
    return [...plans.values()];
  }
  function starsRowsToAdd(rows, existingNames) {
    const have = new Set(existingNames.map(upper));
    return rows.filter((r) => !have.has(upper(r.name)));
  }
  function starsScaleFor(row, picked2) {
    if (row.scaleOptions.length === 1) return row.scaleOptions[0];
    return row.scaleOptions.find((o) => picked2.includes(o)) ?? null;
  }

  // src/ui.ts
  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    for (const c of children) if (c) el.append(c);
    return el;
  }
  function button(label, onClick, cls = "btn", disabled = false) {
    const b = h("button", { type: "button", class: cls }, label);
    b.disabled = disabled;
    b.addEventListener("click", onClick);
    return b;
  }

  // src/assist-panel.ts
  var STATUS_NOTE = { unverified: " (unconfirmed wording: check it matches the page)" };
  async function send(tabId, msg) {
    if (tabId == null) return null;
    try {
      return await chrome.tabs.sendMessage(tabId, msg) ?? null;
    } catch {
      return null;
    }
  }
  async function copy(value) {
    try {
      await navigator.clipboard.writeText(value);
      return true;
    } catch {
      return false;
    }
  }
  var doneKey = (system) => `assistDone:${system}`;
  async function loadDone(system) {
    try {
      const got = await chrome.storage.local.get(doneKey(system));
      const ids = got[doneKey(system)];
      return new Set(Array.isArray(ids) ? ids : []);
    } catch {
      return /* @__PURE__ */ new Set();
    }
  }
  async function saveDone(system, ids) {
    try {
      await chrome.storage.local.set({ [doneKey(system)]: [...ids] });
    } catch {
    }
  }
  async function assistView(plan, tabId, auto = null) {
    const done = await loadDone(plan.system);
    const status = h("p", { class: "status" }, tabId == null ? "Open the portal in this window to type values in. Until then, pressing a value copies it." : "Click a box on the page, then press the value here.");
    const report = (text, warn = false) => {
      status.textContent = text;
      status.className = warn ? "status warn" : "status";
    };
    const put = async (label, value, advance = true) => {
      const r = await send(tabId, { type: "assistInsert", value, advance });
      if (r?.type === "assistInsert" && r.result.ok) {
        report(`${label}: "${value}" ${r.result.how}${r.label ? ` into "${r.label}"` : ""}.`);
        return true;
      }
      const why = r?.type === "assistInsert" && !r.result.ok ? r.result.reason : tabId == null ? "" : "The page did not answer; reload it.";
      const copied = await copy(value);
      report(`${why}${why ? " " : ""}${copied ? `Copied "${value}": paste it with Ctrl+V.` : `Could not copy "${value}".`}`, !!why);
      return false;
    };
    const fillFrom = async (row) => {
      const values = rowValues(row);
      for (let i = 0; i < values.length; i++) {
        const v = values[i];
        if (!await put(v.label, v.value)) {
          report(`Stopped at ${v.label} (${i} of ${values.length} filled). ${status.textContent}`, true);
          return;
        }
      }
      report(`${row.name}: ${values.length} values filled in page order. Check each box before you save.`);
    };
    const rowEl = (row) => {
      const tick = h("input", { type: "checkbox" });
      tick.checked = done.has(row.trackerId);
      tick.addEventListener("change", () => {
        if (tick.checked) done.add(row.trackerId);
        else done.delete(row.trackerId);
        void saveDone(plan.system, done);
      });
      const values = rowValues(row).map((v, i) => {
        const f = row.fields[i];
        const unconfirmed = f?.status === "unverified" ? STATUS_NOTE.unverified : "";
        const b = button(`${v.label}: ${v.value}${unconfirmed ? " ?" : ""}`, () => void put(v.label, v.value), "chip");
        return withTitle(b, f?.note ? `${f.note}${unconfirmed}` : unconfirmed.trim());
      });
      return h(
        "section",
        { class: "item" },
        h("label", { class: "check" }, tick, h("strong", {}, row.name)),
        h("div", { class: "chips" }, ...values),
        ...row.warnings.map((w) => h("p", { class: "note" }, w)),
        button("Fill from here", () => void fillFrom(row), "link", tabId == null)
      );
    };
    const manual = [
      status,
      h("p", { class: "muted" }, 'Click the first box of a course on the page, then press "Fill from here" to type its values in page order, or press values one at a time. Nothing is saved or submitted for you.'),
      plan.notes.length ? h("ul", { class: "warnings" }, ...plan.notes.map((n) => h("li", {}, n))) : false,
      ...plan.groups.flatMap((g) => [h("h3", {}, g.title), ...g.rows.map(rowEl)]),
      plan.groups.length ? false : h("p", { class: "note" }, "No courses from your transcript go into this system."),
      plan.skipped.length ? h("details", {}, h("summary", {}, `Not entered here (${plan.skipped.length})`), h("ul", {}, ...plan.skipped.map((s) => h("li", {}, `${s.course}: ${s.reason}`)))) : false
    ];
    return auto ? h("div", {}, h("h2", {}, plan.label), auto, h("details", {}, h("summary", {}, "Fill by hand instead"), ...manual)) : h("div", {}, h("h2", {}, `${plan.label}: fill assistant`), ...manual);
  }
  function withTitle(el, title) {
    if (title) el.title = title;
    return el;
  }

  // src/auto-view.ts
  function autoView(o) {
    const ticked2 = new Set(o.items.map((_, i) => i));
    const boxes = o.items.map((item, i) => {
      const box = h("input", { type: "checkbox" });
      box.checked = true;
      box.addEventListener("change", () => {
        if (box.checked) ticked2.add(i);
        else ticked2.delete(i);
        go.disabled = ticked2.size === 0;
      });
      return h("label", { class: "check" }, box, h("span", {}, item.label));
    });
    const status = h("p", { class: "status" }, "");
    const results = h("div", {});
    let stop = false;
    const stopBtn = button("Stop", () => {
      stop = true;
      stopBtn.disabled = true;
      status.textContent = "Stopping after the current course...";
    }, "btn danger", true);
    const go = button("Fill selected", async () => {
      const plans = o.items.filter((_, i) => ticked2.has(i)).map((x) => x.plan);
      const blocked = await o.before?.() ?? null;
      if (blocked) {
        status.textContent = blocked;
        status.className = "status warn";
        return;
      }
      stop = false;
      go.disabled = true;
      stopBtn.disabled = false;
      boxes.forEach((b) => b.querySelector("input").disabled = true);
      results.replaceChildren();
      status.className = "status";
      const { reports, stopped } = await o.run(plans, () => stop, (t) => status.textContent = t);
      go.disabled = false;
      stopBtn.disabled = true;
      boxes.forEach((b) => b.querySelector("input").disabled = false);
      const trouble = reports.filter((r) => r.problems.length || r.left.length).length;
      status.className = stopped || trouble ? "status warn" : "status";
      status.textContent = stopped ? `Stopped after ${reports.length} of ${plans.length}.` : trouble ? `Done. ${trouble} of ${reports.length} need a look (below); the rest are complete.` : `Done: all ${reports.length} filled and saved. Nothing needs checking.`;
      results.replaceChildren(...reports.map(reportEl));
    }, "btn primary", o.items.length === 0);
    return h(
      "section",
      { class: "item" },
      h("h3", {}, o.title),
      h("p", { class: "muted" }, o.intro),
      o.items.length ? h("div", { class: "list" }, ...boxes) : h("p", { class: "note" }, "Your transcript has no courses to add here."),
      ...o.options ?? [],
      status,
      h("div", { class: "row" }, go, stopBtn),
      results,
      ...o.footer ?? []
    );
  }
  function reportEl(r) {
    return h(
      "section",
      { class: "item" },
      h("h4", {}, r.title),
      ...r.done.map((d) => h("p", { class: "done" }, d)),
      ...r.problems.map((p) => h("p", { class: "warn" }, p)),
      r.left.length ? h("p", { class: "note" }, `Enter by hand (the tracker can't fill a box for them): ${r.left.join(", ")}.`) : false
    );
  }

  // src/sites.ts
  var SITE_ORIGINS = {
    common_app: ["https://apply.commonapp.org"],
    uc: ["https://apply.universityofcalifornia.edu"],
    stars: ["https://srar.selfreportedtranscript.com"],
    csu: ["https://calstate.cas.myliaison.com", "https://calstate.liaisoncas.com"],
    uiuc: ["https://myillini.illinois.edu"],
    ut: ["https://utdirect.utexas.edu", "https://mystatus.admissions.utexas.edu", "https://admissions.utexas.edu"]
  };
  var SITE_LABEL = {
    common_app: "Common App",
    uc: "UC application",
    stars: "STARS",
    csu: "Cal State Apply",
    uiuc: "UIUC SRAR (myIllini)",
    ut: "UT Austin (MyStatus)"
  };
  var SITE_HOME = {
    common_app: "https://apply.commonapp.org/dashboard",
    uc: "https://apply.universityofcalifornia.edu/my-application/login",
    stars: "https://srar.selfreportedtranscript.com/Login.aspx",
    csu: "https://calstate.cas.myliaison.com/applicant/login",
    uiuc: "https://myillini.illinois.edu/",
    ut: "https://utdirect.utexas.edu/apps/adm/mystatus/"
  };
  function siteOf(url) {
    if (!url) return null;
    let origin;
    try {
      origin = new URL(url).origin;
    } catch {
      return null;
    }
    for (const [site, origins] of Object.entries(SITE_ORIGINS)) if (origins.includes(origin)) return site;
    return null;
  }

  // src/tab-wait.ts
  var RELOAD_MS = 3e4;
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function sendTo(tabId, msg) {
    try {
      return await chrome.tabs.sendMessage(tabId, msg) ?? null;
    } catch {
      return null;
    }
  }
  function afterReload(tabId, what) {
    return new Promise((resolve, reject) => {
      let sawLoading = false;
      const timer = setTimeout(() => done(new Error(`${what} did not finish saving (no reload). Check the page for a message`)), RELOAD_MS);
      const listener = (id, change) => {
        if (id !== tabId) return;
        if (change.status === "loading") sawLoading = true;
        else if (change.status === "complete" && sawLoading) void ready();
      };
      const done = (err) => {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        if (err) reject(err);
        else resolve();
      };
      const ready = async () => {
        for (let i = 0; i < 50; i++) {
          if ((await sendTo(tabId, { type: "ready" }))?.type === "ready") return done();
          await sleep(200);
        }
        done(new Error(`The ${what} page did not respond after saving`));
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
  }
  async function navigate(tabId, url, what) {
    const loaded = afterReload(tabId, what).catch(() => {
      throw new Error(`The ${what} page did not open. Check the tab, then run again`);
    });
    await chrome.tabs.update(tabId, { url });
    await loaded;
  }

  // ../web/lib/school-match.ts
  var ABBR = {
    intl: "international",
    int: "international",
    sch: "school",
    schl: "school",
    hs: "high school",
    acad: "academy",
    acd: "academy",
    cmp: "campus",
    camp: "campus",
    cmps: "campus",
    st: "saint",
    ste: "sainte",
    mt: "mount",
    jr: "junior",
    sr: "senior",
    sci: "science",
    tech: "technology",
    inst: "institute",
    univ: "university",
    coll: "college",
    prep: "preparatory",
    ctr: "center",
    centre: "center",
    elem: "elementary",
    sec: "secondary",
    natl: "national",
    ms: "middle school",
    bil: "bilingual",
    amer: "american",
    ctry: "country",
    co: "county",
    cty: "county",
    dist: "district",
    isd: "independent school district"
  };
  var STOP = /* @__PURE__ */ new Set(["the", "of", "and", "at", "a", "an", "in", "for", "de", "la", "le"]);
  function schoolWords(name) {
    const out = [];
    const raw = name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/&/g, " and ").replace(/\bh\.\s?s\./g, " hs ").replace(/['\u2019]/g, "").replace(/[^a-z0-9\u3400-\u9fff]+/g, " ").split(" ").filter(Boolean);
    for (const w of raw) for (const x of (ABBR[w] ?? w).split(" ")) if (!STOP.has(x)) out.push(x);
    return out;
  }
  function sameWord(a, b) {
    if (a === b) return true;
    if (Math.min(a.length, b.length) < 5 || Math.abs(a.length - b.length) > 1) return false;
    let i = 0;
    let j = 0;
    let edits = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) {
        i++;
        j++;
        continue;
      }
      if (++edits > 1) return false;
      if (a.length > b.length) i++;
      else if (b.length > a.length) j++;
      else {
        i++;
        j++;
      }
    }
    return edits + (a.length - i) + (b.length - j) <= 1;
  }
  var shared = (a, b) => a.filter((w) => b.some((x) => sameWord(w, x))).length;
  function schoolNameScore(a, b) {
    const wa = [...new Set(schoolWords(a))];
    const wb = [...new Set(schoolWords(b))];
    if (!wa.length || !wb.length) return 0;
    if (wa.join("") === wb.join("")) return 1;
    const both = shared(wa, wb);
    const small = Math.min(wa.length, wb.length);
    const big = Math.max(wa.length, wb.length);
    const ca = wa.join("");
    const cb = wb.join("");
    if (both === small && (small >= 2 || big === 1)) return 0.9 + 0.1 * (small / big);
    if (Math.min(ca.length, cb.length) >= 8 && (ca.includes(cb) || cb.includes(ca))) return 0.88;
    return 0.85 * (2 * both / (wa.length + wb.length));
  }
  var SAME_SCHOOL = 0.75;
  var codeKey = (c) => (c ?? "").toUpperCase().replace(/[\s-]+/g, "");
  function sameSchoolCode(a, b) {
    const ka = codeKey(a);
    return ka !== "" && ka === codeKey(b);
  }
  function bestSchoolMatch(options, school, view2) {
    const norm = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
    const exact = options.filter((o) => norm(view2(o).name) === norm(school.name));
    if (exact.length === 1) return exact[0];
    if (school.code) {
      const byCode = options.filter((o) => sameSchoolCode(view2(o).code, school.code));
      if (byCode.length === 1) return byCode[0];
    }
    const scored = options.map((o) => ({ o, s: schoolNameScore(view2(o).name, school.name) })).sort((x, y) => y.s - x.s);
    const top = scored[0];
    if (!top || top.s < SAME_SCHOOL) return null;
    if (scored[1] && scored[1].s >= top.s - 0.02) return null;
    return top.o;
  }

  // src/stars/run.ts
  var upper2 = (s) => s.normalize("NFKC").trim().toUpperCase().replace(/\s+/g, " ");
  async function page(tab) {
    const r = await tab.send({ type: "starsPage" });
    if (r?.type !== "starsPage") throw new Error("The STARS page did not answer. Reload it and try again.");
    return r;
  }
  async function runStarsYear(plan, picked2, language, tab, shouldStop, progress) {
    const added = [];
    let state;
    try {
      state = await page(tab);
    } catch (e) {
      return { added, skippedExisting: 0, stopped: e.message };
    }
    if (state.year !== plan.endYear || state.kind !== plan.kind) return { added, skippedExisting: 0, stopped: `Open the ${plan.endYear - 1}-${String(plan.endYear % 100).padStart(2, "0")} coursework page on STARS first.` };
    const todo = starsRowsToAdd(plan.rows, state.existing);
    const skippedExisting = plan.rows.length - todo.length;
    for (const [i, row] of todo.entries()) {
      if (shouldStop()) return { added, skippedExisting, stopped: "Stopped." };
      progress(`Adding ${row.name} (${i + 1} of ${todo.length})...`);
      const scale = starsScaleFor(row, picked2);
      const r = await tab.send({ type: "starsFill", row, scale, language });
      if (r?.type !== "starsFill") return { added, skippedExisting, stopped: "The STARS page stopped responding. Reload it and try again." };
      if (!r.ok) return { added, skippedExisting, stopped: `${row.name}: ${r.error}. Nothing was saved for it; fix it on STARS or in the tracker, then run again.` };
      if (!r.saved) return { added, skippedExisting, stopped: `${row.name} is filled in but not saved: choose ${r.blanks.join(", ")} on STARS and press Save Course, then run again.` };
      try {
        await tab.afterSave();
        state = await page(tab);
      } catch (e) {
        const errors = (await page(tab).catch(() => null))?.errors ?? [];
        return { added, skippedExisting, stopped: `${row.name}: ${errors.length ? `STARS says: ${errors.join("; ")}` : e.message}` };
      }
      if (!state.existing.some((n) => upper2(n) === upper2(row.name))) {
        return { added, skippedExisting, stopped: `STARS did not save ${row.name}. Check the page for a message (a required box may be empty).` };
      }
      added.push(row.name);
    }
    return { added, skippedExisting, stopped: null };
  }
  var yearText = (endYear) => `${endYear - 1}-${String(endYear % 100).padStart(2, "0")}`;
  var SIGNED_OUT = /signed you out/i;
  function starsSchoolFor(plan, schools) {
    if (schools.length === 1) return schools[0];
    return bestSchoolMatch(schools, { name: plan.schoolName, code: plan.schoolCode }, (s) => ({ name: s.name, code: s.ceeb }));
  }
  async function openStarsYear(plan, tab, schools) {
    const list = await schools();
    if (typeof list === "string") return list;
    const school = starsSchoolFor(plan, list);
    if (!school) return `STARS lists ${list.length ? list.map((s) => s.name).join(", ") : "no schools"} and none of them reads as "${plan.schoolName}": add the school (or its code) on STARS's Enter Schools page, or the school code in the tracker`;
    const now = await page(tab);
    const here = now.year === plan.endYear && now.kind === plan.kind && now.pageText.split("\n", 1)[0].trim() === school.ceeb;
    if (!here) {
      if (!tab.go) return `Open the ${yearText(plan.endYear)} coursework page on STARS first`;
      const r = await tab.send({ type: "starsYearPath", ceeb: school.ceeb, year: plan.endYear });
      if (r?.type !== "starsYearPath") return "The STARS page did not answer. Reload it and try again";
      if (!r.path) {
        return r.years.length ? `STARS offers ${r.years.map(yearText).join(", ")} for ${school.name}, not ${yearText(plan.endYear)}: check the school's dates on STARS's Enter Schools page` : `STARS did not show ${school.name}'s school years (it may have signed you out): open STARS's summary page, then run again`;
      }
      await tab.go(r.path);
      const after = await page(tab);
      if (after.year !== plan.endYear) return `STARS did not open the ${yearText(plan.endYear)} coursework page (it may have signed you out)`;
      if (after.kind !== plan.kind) {
        return `STARS treats ${school.name} as ${after.kind === "us" ? "a US" : "a non-US"} school and the tracker as ${plan.kind === "us" ? "a US" : "a non-US"} one: make the school's country match, then run again`;
      }
    }
    return null;
  }
  async function runStarsPlans(plans, picked2, language, tab, shouldStop, progress) {
    const reports = [];
    let schools = null;
    const loadSchools = () => schools ??= tab.send({ type: "starsSchools" }).then(
      (r) => r?.type !== "starsSchools" ? "The STARS page did not answer. Reload it and try again" : r.ok ? r.schools : r.error
    );
    for (const plan of plans) {
      if (shouldStop()) return { reports, stopped: true };
      progress(`Opening ${yearText(plan.endYear)} on STARS...`);
      let problem;
      try {
        problem = await openStarsYear(plan, tab, loadSchools);
      } catch (e) {
        problem = e.message;
      }
      if (problem) {
        reports.push({ plan, result: { added: [], skippedExisting: 0, stopped: problem } });
        if (SIGNED_OUT.test(problem)) return { reports, stopped: true };
        continue;
      }
      const result = await runStarsYear(plan, picked2, plan.kind === "intl" ? language : null, tab, shouldStop, (t) => progress(`${yearText(plan.endYear)}: ${t}`));
      reports.push({ plan, result });
      if (result.stopped === "Stopped.") return { reports, stopped: true };
    }
    return { reports, stopped: false };
  }

  // src/stars/panel.ts
  var PICKS_KEY = "starsScalePicks";
  async function loadPicks() {
    try {
      const v = (await chrome.storage.local.get(PICKS_KEY))[PICKS_KEY];
      return Array.isArray(v) ? v : [];
    } catch {
      return [];
    }
  }
  async function savePicks(picks) {
    try {
      await chrome.storage.local.set({ [PICKS_KEY]: picks });
    } catch {
    }
  }
  var LANGUAGE_KEY = "starsLanguage";
  async function loadLanguage() {
    try {
      const v = (await chrome.storage.local.get(LANGUAGE_KEY))[LANGUAGE_KEY];
      return typeof v === "string" && v.trim() ? v : "English";
    } catch {
      return "English";
    }
  }
  var yearText2 = (endYear) => `${endYear - 1}-${String(endYear % 100).padStart(2, "0")}`;
  var plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
  function starsReport(r, schools) {
    const { added, skippedExisting, stopped } = r.result;
    const done = [];
    if (added.length) done.push(`Added and saved ${plural(added.length, "course")}.`);
    if (skippedExisting) done.push(`${plural(skippedExisting, "course")} already on STARS left alone.`);
    if (!done.length && !stopped) done.push("Nothing new to add.");
    return {
      title: `${yearText2(r.plan.endYear)}${schools > 1 ? `, ${r.plan.schoolName}` : ""}`,
      done,
      problems: stopped && stopped !== "Stopped." ? [stopped] : [],
      left: r.plan.skipped.map((s) => s.course).filter((c, i, all) => all.indexOf(c) === i)
    };
  }
  async function starsAutoView(plans, tabId) {
    const items = plans.filter((p) => p.rows.length).sort((a, b) => a.endYear - b.endYear);
    const schools = new Set(items.map((p) => p.schoolName)).size;
    const picks = await loadPicks();
    const sets = [...new Map(items.flatMap((p) => p.scaleQuestions).map((q) => [q.join("|"), q])).values()];
    const questions = sets.map((options) => {
      const select = h("select", { "aria-label": "Grading Scale" });
      select.append(h("option", { value: "" }, "Choose your school's scale..."));
      for (const o of options) {
        const opt = h("option", { value: o }, o);
        opt.selected = picks.includes(o);
        select.append(opt);
      }
      return select;
    });
    const chosen = () => questions.map((q) => q.value).filter(Boolean);
    const intl = items.some((p) => p.kind === "intl");
    const language = h("input", { type: "text", value: await loadLanguage(), "aria-label": "Language of instruction" });
    const tab = {
      send: (m) => sendTo(tabId, m),
      afterSave: () => afterReload(tabId, "STARS"),
      go: (path) => navigate(tabId, `${SITE_ORIGINS.stars[0]}${path}`, "STARS")
    };
    return autoView({
      title: "Add your courses to STARS",
      intro: "Tick the school years, then Fill selected. The extension opens each year's coursework page in this tab and saves each new course with STARS's Save Course button. Courses already on STARS are left alone; nothing is removed or submitted.",
      items: items.map((p) => ({ plan: p, label: `${yearText2(p.endYear)}${schools > 1 ? ` at ${p.schoolName}` : ""}: ${plural(p.rows.length, "course")}` })),
      options: [
        ...questions.map((q) => h("label", { class: "picker" }, "Grading Scale (your school's pass mark) ", q)),
        intl ? h("label", { class: "picker" }, "Language of instruction ", language) : false
      ],
      before: async () => {
        if (questions.some((q) => !q.value)) return "Choose the Grading Scale first (your school's passing mark decides which).";
        await savePicks([.../* @__PURE__ */ new Set([...picks.filter((p) => !sets.flat().includes(p)), ...chosen()])]);
        try {
          await chrome.storage.local.set({ [LANGUAGE_KEY]: language.value.trim() });
        } catch {
        }
        return null;
      },
      run: async (chosenPlans, shouldStop, progress) => {
        const { reports, stopped } = await runStarsPlans(chosenPlans, chosen(), intl ? language.value.trim() || null : null, tab, shouldStop, progress);
        return { reports: reports.map((r) => starsReport(r, schools)), stopped };
      },
      footer: [summary(items), items.some((p) => p.warnings.length) ? h("ul", { class: "warnings" }, ...[...new Set(items.flatMap((p) => p.warnings))].map((w) => h("li", {}, w))) : false]
    });
  }
  function summary(plans) {
    const lines = [];
    const other = plans.flatMap((p) => p.titleOther);
    const split = plans.reduce((n, p) => n + p.creditsSplit, 0);
    if (other.length) lines.push(`STARS has no closer course title for ${other.join(", ")}: they go in as "OTHER ...". Change one on STARS only if a listed title fits better.`);
    if (split) lines.push(`${split} course${split === 1 ? " prints" : "s print"} one credit for the whole course; it is split evenly over the terms.`);
    return lines.length ? h("ul", { class: "note" }, ...lines.map((l) => h("li", {}, l))) : false;
  }

  // src/csu/panel.ts
  function csuAutoView(plans, tabId) {
    if (!plans.length) return h("p", { class: "note" }, "No US high school in your transcript: Cal State Apply skips course entry for schools outside the US.");
    const sections = plans.map((plan) => {
      const status = h("p", { class: "status" }, `${plan.rows.length} courses (school Term Type in the tracker: ${plan.termType}).`);
      const stop = button("Stop", () => {
        stop.disabled = true;
        void chrome.tabs.sendMessage(tabId, { type: "csuStop" }).catch(() => {
        });
      }, "btn danger", true);
      const go = button(`Add courses to ${plan.schoolName}`, async () => {
        go.disabled = true;
        stop.disabled = false;
        status.className = "status";
        status.textContent = "Adding courses on Cal State Apply... keep this tab open.";
        let r;
        try {
          r = await chrome.tabs.sendMessage(tabId, { type: "csuFill", plan });
        } catch {
          r = void 0;
        }
        go.disabled = false;
        stop.disabled = true;
        if (r?.type !== "csuFill") {
          status.className = "status warn";
          status.textContent = "The Cal State Apply page stopped responding. Reload it and try again.";
          return;
        }
        const { added, skippedExisting, stopped } = r.result;
        status.className = stopped ? "status warn" : "status";
        status.textContent = [
          `Added ${added.length} course${added.length === 1 ? "" : "s"}${added.length ? `: ${added.join(", ")}` : ""}.`,
          skippedExisting ? `${skippedExisting} already there were left alone.` : "",
          stopped ?? "Check each course, then set each one's A-G area on the A-G Matching page."
        ].filter(Boolean).join(" ");
      }, "btn primary");
      const codes = plan.rows.filter((r) => r.agCode).map((r) => `${r.name}: ${r.agCode}`);
      return h(
        "section",
        { class: "item" },
        h("h3", {}, plan.schoolName),
        status,
        h("div", { class: "row" }, go, stop),
        codes.length ? h("details", {}, h("summary", {}, "A-G areas to pick on A-G Matching"), h("ul", {}, ...codes.map((c) => h("li", {}, c)))) : false,
        plan.warnings.length ? h("ul", { class: "warnings" }, ...plan.warnings.map((w) => h("li", {}, w))) : false,
        plan.skipped.length ? h("details", {}, h("summary", {}, `Left for you (${plan.skipped.length})`), h("ul", {}, ...plan.skipped.map((s) => h("li", {}, `${s.course}: ${s.field}: ${s.reason}`)))) : false
      );
    });
    return h("div", {}, h("h3", {}, "Add courses automatically"), h("p", { class: "muted" }, "Open Academic History > High School Coursework on Cal State Apply. Nothing is removed, marked done or submitted."), ...sections);
  }

  // src/uc/nav.ts
  var ucGradePath = (grade) => `/my-application/acadHistFrGrades/${String(grade).padStart(2, "0")}`;

  // src/uc/run.ts
  var key = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  var NO_ANSWER = "The UC page stopped responding. Reload it and try again";
  async function oneGrade(plan, all, tab) {
    const report = { plan, added: [], skippedExisting: 0, left: [], problem: null };
    const g = plan.gradeLevel;
    const now = await tab.send({ type: "ucPage" });
    const here = now?.type === "ucPage" && now.grade === g && all.filter((p) => p.gradeLevel === g).length === 1;
    if (!here) {
      await tab.go(ucGradePath(g));
      const open = await tab.send({ type: "ucOpenClasses", grade: g, schoolName: plan.schoolName, schoolCode: plan.schoolCode });
      if (open?.type !== "ucOpenClasses") return { ...report, problem: NO_ANSWER };
      if (!open.ok) return { ...report, problem: open.error };
      await tab.afterReload();
      const there = await tab.send({ type: "ucPage" });
      if (there?.type !== "ucPage" || there.grade !== g) return { ...report, problem: `UC did not open the ${g}th grade courses page (it may have signed you out)` };
    }
    const r = await tab.send({ type: "ucFill", plan });
    if (r?.type !== "ucFill") return { ...report, problem: NO_ANSWER };
    if (!r.ok) return { ...report, problem: `${r.error}. Nothing was saved` };
    const { added, skippedExisting, left, saving } = r.result;
    Object.assign(report, { added, skippedExisting, left });
    if (saving) {
      await tab.afterReload();
      const after = await tab.send({ type: "ucPage" });
      const names = after?.type === "ucPage" ? after.names.map(key) : [];
      const missing = added.filter((n) => !names.includes(key(n)));
      if (missing.length) report.problem = `UC does not list ${missing.join(", ")} after saving: check the page for a message`;
    }
    return report;
  }
  async function runUcPlans(plans, tab, shouldStop, progress) {
    const reports = [];
    for (const plan of plans) {
      if (shouldStop()) return { reports, stopped: true };
      progress(`Filling ${plan.gradeLevel}th grade on UC...`);
      try {
        reports.push(await oneGrade(plan, plans, tab));
      } catch (e) {
        reports.push({ plan, added: [], skippedExisting: 0, left: [], problem: e.message });
      }
    }
    return { reports, stopped: false };
  }

  // src/uc/panel.ts
  var plural2 = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
  function ucReport(r, schools) {
    const done = [];
    if (r.added.length) done.push(`Added ${plural2(r.added.length, "course")} and saved.`);
    if (r.skippedExisting) done.push(`${plural2(r.skippedExisting, "course")} already on UC left alone.`);
    if (!done.length && !r.problem && !r.left.length) done.push("Nothing new to add.");
    return {
      title: `${r.plan.gradeLevel}th grade (${r.plan.year})${schools > 1 ? `, ${r.plan.schoolName}` : ""}`,
      done,
      problems: r.problem ? [r.problem] : [],
      left: r.left
    };
  }
  function ucAutoView(plans, tabId) {
    const items = plans.filter((p) => p.rows.length);
    const schools = new Set(items.map((p) => p.schoolName)).size;
    const tab = {
      send: (m) => sendTo(tabId, m),
      go: (path) => navigate(tabId, `${SITE_ORIGINS.uc[0]}${path}`, "UC"),
      afterReload: () => afterReload(tabId, "UC")
    };
    const warnings = items.flatMap((p) => p.warnings);
    const skipped = items.flatMap((p) => p.skipped);
    return autoView({
      title: "Add your courses to UC",
      intro: "Tick the grades, then Fill selected. The extension opens each grade's Enter courses & grades page in this tab, adds the courses that are not there yet and saves. Nothing is removed or submitted.",
      items: items.map((p) => ({ plan: p, label: `${p.gradeLevel}th grade (${p.year})${schools > 1 ? ` at ${p.schoolName}` : ""}: ${plural2(p.rows.length, "course")}` })),
      run: async (chosen, shouldStop, progress) => {
        const { reports, stopped } = await runUcPlans(chosen, tab, shouldStop, progress);
        return { reports: reports.map((r) => ucReport(r, schools)), stopped };
      },
      footer: [
        warnings.length ? h("ul", { class: "warnings" }, ...[...new Set(warnings)].map((w) => h("li", {}, w))) : false,
        skipped.length ? h("details", {}, h("summary", {}, `Not added automatically (${skipped.length})`), h("ul", {}, ...skipped.map((s) => h("li", {}, `${s.course}: ${s.field}: ${s.reason}`)))) : false
      ]
    });
  }

  // ../web/lib/uc-fill.ts
  var LETTER = /^([A-F])[+-]?$/i;
  var byText = (t) => UC_DISCIPLINES.find((d) => d.text === t);
  function ucDiscipline(c) {
    for (const ov of [c.overrides.uc?.subject, c.overrides.uc?.subSubject]) {
      if (!ov) continue;
      const i = ucDisciplineLabels().findIndex((l) => normalizeName(l) === normalizeName(ov));
      if (i >= 0) return UC_DISCIPLINES[i];
    }
    const name = c.name;
    switch (c.subject) {
      case "english":
        return byText(/\b(ESL|ELD)\b/i.test(name) ? "English-ESL/ELD" : "English");
      case "mathematics": {
        const m = { algebra_1: "Algebra I", geometry: "Geometry", algebra_2: "Algebra II", precalculus: "Pre-Calculus", calculus: "Calculus", statistics: "Statistics" };
        return c.subSubject && m[c.subSubject] ? byText(m[c.subSubject]) : null;
      }
      case "science": {
        const m = { biology: "Biology/Life Sciences", chemistry: "Chemistry", physics: "Physics", earth_space: "Earth and Space Sciences" };
        return c.subSubject && m[c.subSubject] ? byText(m[c.subSubject]) : null;
      }
      case "arts": {
        const m = { visual: "Visual Arts", music: "Music", theater: "Theater", dance: "Dance", interdisciplinary: "Interdisciplinary Arts" };
        return c.subSubject && m[c.subSubject] ? byText(m[c.subSubject]) : null;
      }
      case "world_language": {
        const roman = { I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6 };
        const m = name.match(/\b([1-9]|I{1,3}|IV|V|VI)\b(?!.*\b([1-9]|I{1,3}|IV|V|VI)\b)/);
        const n = m ? roman[m[1]] ?? Number(m[1]) : null;
        return n ? byText(`Yr ${n >= 4 ? "4+" : n} Lang Other Than English`) : null;
      }
      case "history_social":
        if (/\b(U\.?S\.?|American|United States)\b.*\bHistory\b/i.test(name)) return byText("U.S. History");
        if (/\b(Civics|Government)\b/i.test(name)) return byText("Civics/American Government");
        if (/\bWorld (History|Cultures?)\b|\bGeography\b/i.test(name)) return byText("World History/Cultures/Hist. Geography");
        return null;
      default:
        return null;
    }
  }
  function ucDisciplineFromTranscript(c, mine) {
    if (c.subject === "world_language" && c.languageName.trim()) {
      const before = mine.filter((x) => x.subject === "world_language" && normalizeName(x.languageName) === normalizeName(c.languageName) && x.academicYear < c.academicYear);
      const years = new Set(before.map((x) => x.academicYear)).size;
      const n = years + 1;
      const text = `Yr ${n >= 4 ? "4+" : n} Lang Other Than English`;
      return { discipline: byText(text), warning: `${c.name}: entered as "${text}" (year ${n} of ${c.languageName} on your transcript); change it on UC if your school counts it differently` };
    }
    if (c.subject === "computer_science") {
      return { discipline: byText("Elective -Math -Computer Science"), warning: `${c.name}: entered as the college-prep elective "Elective -Math -Computer Science"; on UC you can pick Computer Science under Mathematics or Science instead` };
    }
    if (/\bAP\s+(Seminar|Research)\b/i.test(c.name)) {
      return { discipline: byText("Elective -Interdisciplinary"), warning: `${c.name}: entered as the college-prep elective "Elective -Interdisciplinary"` };
    }
    return null;
  }
  function ucGrade(printed) {
    const g = printed.trim();
    const letter = g.match(LETTER);
    if (letter) return letter[1].toUpperCase();
    if (/^\d{1,3}$/.test(g) && Number(g) <= 100) return String(Number(g));
    return null;
  }
  function honorsOf(school, c, warnings) {
    const ov = c.overrides.uc?.level?.toUpperCase();
    if (ov === "AP" || ov === "IB" || ov === "HL" || ov === "NH") return ov;
    if (c.level === "ap") return "AP";
    if (c.level === "ib" || c.level === "ib_hl" || c.level === "ib_sl") return "IB";
    if ((c.level === "honors" || c.level === "high_honors") && !isNonUs(school)) {
      warnings.push(`${c.name}: marked HL; UC counts honors only for courses on the school's UC-approved honors list`);
      return "HL";
    }
    if (c.level === "honors" || c.level === "high_honors") warnings.push(`${c.name}: an honors course at a school outside the US is NH on UC (only AP and IB get honors weight)`);
    return "NH";
  }
  function buildUcPlans(schools, courses) {
    const out = [];
    for (const school of schools) {
      if (school.kind !== "high_school") continue;
      const boxes = TERMS_FOR_PERIOD[school.defaultPeriod].filter((t) => school.defaultPeriod === "full_year" || t !== "FY");
      const mine = courses.filter((c) => c.schoolId === school.id).sort((a, b) => (a.gradeLevel ?? 0) - (b.gradeLevel ?? 0) || a.sortOrder - b.sortOrder);
      const plans = /* @__PURE__ */ new Map();
      for (const c of mine) {
        const gl = c.gradeLevel;
        if (gl == null || gl < 9 || gl > 12) continue;
        let plan = plans.get(gl);
        if (!plan) {
          plan = { schoolName: school.name, schoolCode: school.schoolCode, gradeLevel: gl, year: `${c.academicYear} - ${c.academicYear + 1}`, rows: [], skipped: [], warnings: [] };
          plans.set(gl, plan);
        }
        const skip = (field, reason) => plan.skipped.push({ course: c.name, field, reason });
        if (c.isCollege) {
          skip("course", "college course: enter it under Colleges attended while in high school");
          continue;
        }
        if (c.subject === "business" || c.subject === "pe_health" || c.subject === "career_technical") {
          skip("course", "not an A-G course: UC says to leave it out here (it may go under Activities & awards > Other coursework)");
          continue;
        }
        let discipline = ucDiscipline(c);
        if (!discipline) {
          const guess = ucDisciplineFromTranscript(c, mine);
          if (guess) {
            discipline = guess.discipline;
            plan.warnings.push(guess.warning);
          }
        }
        if (!discipline && c.subject === "other") {
          skip("course", "not an A-G subject: UC says to leave it out here (it may go under Activities & awards > Other coursework)");
          continue;
        }
        if (!discipline) skip("Subject Area/Course Category", "UC's subject could not be told from the course; pick it on UC (or set it for UC in the tracker)");
        const grades = boxes.map((code) => {
          if (c.period !== school.defaultPeriod) return null;
          const t = c.terms.find((x) => x.term === code) ?? (code === "FY" && c.finalGrade ? { term: "FY", grade: c.finalGrade, status: "graded" } : void 0);
          if (!t || t.status === "none") return UC_GRADE_CODES.notTaken;
          if (t.status === "in_progress") return UC_GRADE_CODES.inProgress;
          if (t.status === "planned") return UC_GRADE_CODES.planned;
          const g = ucGrade(t.grade);
          if (g == null) skip(`${code} grade`, t.grade.trim() ? `"${t.grade}" is not a grade UC takes (no Pass/Fail or decimals for A-G); enter it by hand` : "the grade is missing in the tracker");
          return g;
        });
        if (c.period !== school.defaultPeriod) skip("grades", `the course is on a ${c.period.replace("_", " ")} schedule but the school's term system is ${school.defaultPeriod.replace("_", " ")}: enter its grades by hand`);
        if (grades.some((g, i) => g && /^[A-F]$/.test(g) && /[+-]$/.test((c.terms.find((t) => t.term === boxes[i])?.grade ?? "").trim()))) {
          plan.warnings.push(`${c.name}: UC drops + and -, so the grade is entered without them`);
        }
        const language = c.subject === "world_language" ? UC_LANGUAGES.find((l) => normalizeName(l) === normalizeName(c.languageName)) ?? (c.languageName.trim() ? "Other Language" : null) : null;
        if (c.subject === "world_language" && !language) skip("language", "the language is not set in the tracker; pick it on UC");
        plan.rows.push({ trackerId: c.id, name: c.name, discipline, honors: honorsOf(school, c, plan.warnings), grades, language });
      }
      out.push(...[...plans.values()].sort((a, b) => a.gradeLevel - b.gradeLevel));
    }
    return out;
  }

  // ../web/lib/csu-labels.ts
  var csuYear = (startYear) => `${startYear}-${startYear + 1}`;

  // ../web/lib/csu-fill.ts
  var CSU_GRADES = ["A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F", "In Progress", "Planned", "No Course", "Pass", "No Pass"];
  var CSU_COURSE_TYPES = ["None", "Advanced Placement", "International Baccalaureate", "Honors"];
  var CSU_TERM_TYPES = { full_year: "Full Year", semester: "Semester", trimester: "Trimester", quarter: "Quarter" };
  var CHART = "Cal State Apply's grade chart for US percentages (90-100 A, 80-89 B, 70-79 C, 60-69 D, 59 and below F; between values rounds up)";
  function csuGrade(printed, scale) {
    const g = printed.trim();
    const up = g.toUpperCase();
    if (/^(P|PASS)$/i.test(g)) return { value: "Pass", converted: false };
    if (/^(NP|NO PASS)$/i.test(g)) return { value: "No Pass", converted: false };
    if ((scale === "letter" || scale === "letter_plus_minus" || scale === "pass_fail") && CSU_GRADES.includes(up)) return { value: up, converted: false };
    if (scale === "percent_100" && /^\d{1,3}(\.\d+)?$/.test(g)) {
      const n = Number(g);
      if (n > 100) return { value: null, converted: false };
      const letter = n > 89 ? "A" : n > 79 ? "B" : n > 69 ? "C" : n > 59 ? "D" : "F";
      return { value: letter, converted: true };
    }
    return { value: null, converted: false };
  }
  function courseType(c, warnings) {
    const ov = c.overrides.csu?.level;
    const hit = ov ? CSU_COURSE_TYPES.find((t) => t.toLowerCase() === ov.toLowerCase()) : void 0;
    if (hit) return hit;
    if (c.level === "ap") return "Advanced Placement";
    if (c.level === "ib" || c.level === "ib_hl" || c.level === "ib_sl") return "International Baccalaureate";
    if (c.level === "honors" || c.level === "high_honors") {
      warnings.push(`${c.name}: marked Honors; Cal State Apply gives honors points only to CSU-approved honors courses`);
      return "Honors";
    }
    return "None";
  }
  function agCode(school, c) {
    const v = mapCourse("csu", school, c).fields.find((f) => f.key === "subject")?.value;
    const m = v?.match(/^(D1|D2|[A-G])\b/);
    return m ? m[1] : null;
  }
  function buildCsuPlans(schools, courses) {
    const out = [];
    for (const school of schools) {
      if (school.kind !== "high_school" || isNonUs(school)) continue;
      const plan = { schoolId: school.id, schoolName: school.name, schoolCode: school.schoolCode, termType: CSU_TERM_TYPES[school.defaultPeriod], rows: [], skipped: [], warnings: [] };
      const mine = courses.filter((c) => c.schoolId === school.id).sort((a, b) => (a.gradeLevel ?? 0) - (b.gradeLevel ?? 0) || a.academicYear - b.academicYear || a.sortOrder - b.sortOrder);
      for (const c of mine) {
        const skip = (field, reason) => plan.skipped.push({ course: c.name, field, reason });
        if (c.isCollege) {
          skip("course", "college course: enter it under College Coursework");
          continue;
        }
        if (c.subject === "pe_health") {
          skip("course", "physical education is not a college-preparatory (A-G) course; Cal State Apply says to leave it out");
          continue;
        }
        if (c.gradeLevel == null || c.gradeLevel < 7 || c.gradeLevel > 12) {
          skip("course", "Cal State Apply takes grades 7-12; set the grade level in the tracker");
          continue;
        }
        if (c.gradeLevel < 9 && c.subject !== "mathematics" && c.subject !== "world_language") {
          skip("course", "7th/8th grade courses count only for math and languages other than English");
          continue;
        }
        if (c.period !== school.defaultPeriod) {
          skip("grades", `the course is on a ${c.period.replace("_", " ")} schedule but the school is set to ${CSU_TERM_TYPES[school.defaultPeriod]}: enter its grades by hand`);
        }
        const codes = TERMS_FOR_PERIOD[school.defaultPeriod].filter((t) => school.defaultPeriod === "full_year" || t !== "FY");
        const grades = codes.map((code) => {
          if (c.period !== school.defaultPeriod) return null;
          const t = c.terms.find((x) => x.term === code) ?? (code === "FY" && c.finalGrade ? { term: "FY", grade: c.finalGrade, status: "graded" } : void 0);
          if (!t || t.status === "none") return "No Course";
          if (t.status === "in_progress") return "In Progress";
          if (t.status === "planned") return "Planned";
          const { value, converted } = csuGrade(t.grade, c.scale);
          if (value == null) skip(`${code} grade`, t.grade.trim() ? `"${t.grade}" has no Cal State Apply grade; enter it by hand` : "the grade is missing in the tracker");
          else if (converted) plan.warnings.push(`${c.name} ${code}: ${t.grade} entered as ${value} using ${CHART}`);
          return value;
        });
        const ag = agCode(school, c);
        if (!ag) skip("A-G area", "choose D1 (biological) or D2 (physical) science on the A-G Matching page");
        if (c.subject === "business" || c.subject === "career_technical" || c.subject === "computer_science") plan.warnings.push(`${c.name}: counts only if it is an A-G approved course`);
        plan.rows.push({ trackerId: c.id, name: c.name, gradeLevel: c.gradeLevel, year: csuYear(c.academicYear), summer: c.isSummer, courseType: courseType(c, plan.warnings), grades, agCode: ag });
      }
      out.push(plan);
    }
    return out;
  }

  // src/commonapp/pages.ts
  var COMMONAPP_ORIGIN = "https://apply.commonapp.org";
  var CG_GRADE_PATH = {
    "9": "/common/13/55",
    "10": "/common/13/56",
    "11": "/common/13/57",
    "12": "/common/13/58",
    other: "/common/13/59"
  };
  var CURRENT_YEAR_PATH = "/common/4/24";
  var GRADE_LABEL = { "9": "9th grade", "10": "10th grade", "11": "11th grade", "12": "12th grade", other: "Other Courses" };
  function targetUrl(target) {
    return COMMONAPP_ORIGIN + (target === "current" ? CURRENT_YEAR_PATH : CG_GRADE_PATH[target]);
  }

  // src/chrome-driver.ts
  var DRIVER_TIMING = { loadMs: 3e4, noNavigationMs: 3e3, readyMs: 2e4, readyPollMs: 300 };
  var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
  async function navigate2(tabs, tabId, url) {
    let sawLoading = false;
    let finish = () => {
    };
    const done = new Promise((resolve) => finish = resolve);
    const listener = (id, change) => {
      if (id !== tabId) return;
      if (change.status === "loading") sawLoading = true;
      else if (change.status === "complete" && sawLoading) finish();
    };
    tabs.onUpdated.addListener(listener);
    try {
      await tabs.update(tabId, { url });
      const timers = [];
      const grace = new Promise((resolve) => timers.push(setTimeout(() => sawLoading ? void 0 : resolve(), DRIVER_TIMING.noNavigationMs)));
      const timeout = new Promise((_, reject) => timers.push(setTimeout(() => reject(new Error("Common App did not finish loading")), DRIVER_TIMING.loadMs)));
      try {
        await Promise.race([done, grace, timeout]);
      } finally {
        timers.forEach(clearTimeout);
      }
    } finally {
      tabs.onUpdated.removeListener(listener);
    }
  }
  async function waitForReady(tabs, tabId) {
    const start = Date.now();
    for (; ; ) {
      try {
        const r = await tabs.sendMessage(tabId, { type: "ready" });
        if (r?.type === "ready") return;
      } catch {
      }
      if (Date.now() - start >= DRIVER_TIMING.readyMs) throw new Error("The Common App page did not respond. Reload it and try again");
      await sleep2(DRIVER_TIMING.readyPollMs);
    }
  }
  async function send2(tabs, tabId, message) {
    let r;
    try {
      r = await tabs.sendMessage(tabId, message);
    } catch {
      throw new Error("The Common App page stopped responding");
    }
    if (!r) throw new Error("The Common App page did not answer");
    return r;
  }
  function createDriver(tabs, tabId, plans) {
    return {
      async open(target) {
        await navigate2(tabs, tabId, targetUrl(target));
        await waitForReady(tabs, tabId);
      },
      async inspect(target) {
        const r = await send2(tabs, tabId, { type: "inspect", target });
        if (r.type !== "inspect") throw new Error("Unexpected answer from the Common App page");
        if (!r.ok) throw new Error(r.error);
        return { existing: r.existing };
      },
      async fill(target, mode) {
        let message;
        if (target === "current") {
          if (!plans.current) throw new Error("No current year courses to fill");
          message = { type: "fill", target: "current", plan: plans.current, mode };
        } else {
          const plan = plans.cg.get(target);
          if (!plan || !(target in CG_GRADE_PATH)) throw new Error("No courses to fill for this grade");
          message = { type: "fill", target, plan, mode };
        }
        const r = await send2(tabs, tabId, message);
        if (r.type !== "fill") throw new Error("Unexpected answer from the Common App page");
        if (!r.ok) throw new Error(r.error);
        return r.result;
      }
    };
  }

  // ../web/lib/commonapp-fill.ts
  var GRADE_ORDER = ["9", "10", "11", "12", "other"];
  var STEM = { full_year: "year", semester: "semester", trimester: "trimester", quarter: "quarter" };
  var COLUMN = { S1: "1", T1: "1", Q1: "1", S2: "2", T2: "2", Q2: "2", T3: "3", Q3: "3", Q4: "4", FY: "final" };
  var SCHEDULE_COLUMNS = { semester: ["1", "2"], trimester: ["1", "2", "3"], quarter: ["1", "2", "3", "4"], year: [] };
  var INTEGER_SCALES = ["1-100", "1-7", "1-10", "1-11", "1-20"];
  var NO_GRADE = "No Grade";
  var NUMERIC = /^\d+(\.\d+)?$/;
  var creditText2 = (n) => String(addCredits([n]));
  function schoolYearLabel(year) {
    return yearLabel(year);
  }
  function gradingScaleFor(scale, max) {
    if (scale === "percent_100") return "1-100";
    if (scale === "letter" || scale === "letter_plus_minus") return "A-F";
    if (scale === "ib_7") return "1-7";
    if (scale === "gpa_decimal") return max === 4 ? "0.0-4.0" : max === 5 ? "0.0-5.0" : "Other";
    if (scale === "other") return max === 10 ? "1-10" : max === 11 ? "1-11" : max === 20 ? "1-20" : "Other";
    return "Other";
  }
  var gradeKey = (c) => c.gradeLevel != null && c.gradeLevel >= 9 && c.gradeLevel <= 12 ? String(c.gradeLevel) : "other";
  function mostCommon(items) {
    const counts = /* @__PURE__ */ new Map();
    for (const i of items) counts.set(i, (counts.get(i) ?? 0) + 1);
    let best = items[0];
    for (const [v, n] of counts) if (n > counts.get(best)) best = v;
    return best;
  }
  function gradesFor(c) {
    const out = {};
    for (const t of c.terms) {
      const g = t.grade.trim();
      if (t.status === "graded" && g) out[COLUMN[t.term]] = g;
    }
    const final = c.finalGrade?.trim();
    if (final) out.final = final;
    return out;
  }
  function subjectAndLevel(school, c, where, skipped) {
    const mapped = mapCourse("common_app", school, c);
    const pick = (key2) => {
      const f = mapped.fields.find((x) => x.key === key2);
      if (f.value == null || f.status === "none") {
        skipped.push({ where, course: c.name, field: key2, reason: f.note ?? `no Common App ${key2} for this course` });
        return null;
      }
      return f.value;
    };
    const subject = pick("subject");
    const dual = c.isCollege && !c.overrides.common_app?.level ? COMMON_APP_MAP.level.dual_enrollment.value : null;
    return { subject, level: dual ?? pick("level"), warnings: mapped.warnings };
  }
  function totalCredit(c) {
    return termCreditSum(c.terms) ?? c.credit;
  }
  function cellsInDialog(c, scale, stem, where, skipped, warnings) {
    const printed = gradesFor(c);
    const total = totalCredit(c);
    const finalCreditOnly = total != null ? { final: creditText2(total) } : {};
    const own = gradingScaleFor(c.scale, c.scaleMax);
    if (own !== scale) {
      skipped.push({ where, course: c.name, field: "grades", reason: `grades are on scale ${own}; this grade uses ${scale} on Common App: enter them by hand` });
      return { grades: {}, credits: finalCreditOnly };
    }
    if (STEM[c.period] !== stem) {
      for (const t of c.terms) {
        if (t.status !== "graded" || !t.grade.trim() || COLUMN[t.term] === "final") continue;
        skipped.push({ where, course: c.name, field: `${t.term} grade`, reason: `the course is on a ${STEM[c.period]} schedule; this grade uses the ${stem} schedule on Common App, which has no ${t.term} column: enter it by hand` });
      }
      return { grades: printed.final ? { final: printed.final } : {}, credits: finalCreditOnly };
    }
    const grades = {};
    const credits = {};
    const cols = SCHEDULE_COLUMNS[stem];
    const termOf = (col) => c.terms.find((t) => COLUMN[t.term] === col);
    const hasTerms = cols.some((col) => termOf(col));
    const hasTermCredits = c.terms.some((t) => t.status !== "none" && t.credit != null);
    const graded = [];
    const termCredits = [];
    let unfinished2 = false;
    for (const col of cols) {
      const t = termOf(col);
      if (!t || t.status === "none") {
        if (hasTerms) {
          grades[col] = NO_GRADE;
          credits[col] = "0";
        }
        continue;
      }
      const g = t.grade.trim();
      if (t.status !== "graded" || !g) {
        unfinished2 = true;
        continue;
      }
      grades[col] = g;
      graded.push(g);
      if (t.credit != null) {
        credits[col] = creditText2(t.credit);
        termCredits.push(t.credit);
      } else if (hasTermCredits) {
        skipped.push({ where, course: c.name, field: `${t.term} credit`, reason: "no credit for this term in the tracker; Final credit may be too low" });
      }
    }
    if (printed.final) grades.final = printed.final;
    else if (graded.length) {
      if (!unfinished2 && INTEGER_SCALES.includes(scale) && graded.every((g) => NUMERIC.test(g))) {
        const avg = graded.reduce((sum, g) => sum + Number(g), 0) / graded.length;
        grades.final = String(Math.round(Number(avg.toFixed(6))));
        warnings.push(`${c.name}: Final grade ${grades.final} is the rounded average of the term grades`);
      } else {
        skipped.push({
          where,
          course: c.name,
          field: "final grade",
          reason: unfinished2 ? "a term is not graded yet, so there is no final grade; type it yourself" : "no final grade on the transcript; type it yourself"
        });
      }
    }
    if (termCredits.length) credits.final = creditText2(addCredits(termCredits));
    else if (c.credit != null) credits.final = creditText2(c.credit);
    return { grades, credits };
  }
  function buildCgPlan(schools, courses) {
    const byId = new Map(schools.map((s) => [s.id, s]));
    const byGrade = /* @__PURE__ */ new Map();
    for (const c of [...courses].sort((a, b) => a.sortOrder - b.sortOrder)) {
      if (byId.get(c.schoolId)?.kind !== "high_school") continue;
      const k = gradeKey(c);
      byGrade.set(k, [...byGrade.get(k) ?? [], c]);
    }
    const plans = [];
    for (const grade of GRADE_ORDER) {
      const all = byGrade.get(grade);
      if (!all) continue;
      const skipped = [];
      const warnings = [];
      const fillable = [];
      for (const c of all) {
        if (Object.keys(gradesFor(c)).length) fillable.push(c);
        else {
          const status = courseStatus(c);
          skipped.push({ where: grade, course: c.name, field: "course", reason: status === "graded" ? "no grades in tracker" : `${status.replace("_", " ")}: goes to Current Year Courses` });
        }
      }
      const pool = fillable.length ? fillable : all;
      const mainSchool = byId.get(mostCommon(pool.map((c) => c.schoolId)));
      const ofSchool = pool.filter((c) => c.schoolId === mainSchool.id);
      const mainYear = mostCommon(ofSchool.map((c) => c.academicYear));
      const rowsOf = [];
      for (const c of fillable) {
        if (c.schoolId !== mainSchool.id) skipped.push({ where: grade, course: c.name, field: "course", reason: `another school (${byId.get(c.schoolId).name}): not filled, one school per grade` });
        else if (c.academicYear !== mainYear) skipped.push({ where: grade, course: c.name, field: "course", reason: `another school year (${schoolYearLabel(c.academicYear)}): not filled, one year per grade` });
        else rowsOf.push(c);
      }
      const scales = ofSchool.filter((c) => c.academicYear === mainYear).map((c) => gradingScaleFor(c.scale, c.scaleMax));
      const scale = mostCommon(scales);
      const stem = mostCommon(ofSchool.filter((c) => c.academicYear === mainYear).map((c) => STEM[c.period]));
      const rows = rowsOf.map((c) => {
        const { subject, level, warnings: ruleWarnings } = subjectAndLevel(mainSchool, c, grade, skipped);
        for (const w of ruleWarnings) warnings.push(`${c.name}: ${w}`);
        const cells = cellsInDialog(c, scale, stem, grade, skipped, warnings);
        const hasCredit = cells.credits.final != null;
        const creditNA = !hasCredit && c.creditUnit === "not_listed";
        if (!hasCredit && !creditNA) skipped.push({ where: grade, course: c.name, field: "credit", reason: "no credit in tracker" });
        return { trackerId: c.id, name: c.name, subject, level, grades: cells.grades, credits: creditNA ? {} : cells.credits, creditNA };
      });
      plans.push({ grade, schoolName: mainSchool.name, schoolCode: mainSchool.schoolCode, schoolYear: schoolYearLabel(mainYear), scale, scheduleStem: stem, rows, skipped, warnings });
    }
    return plans;
  }
  function currentSchedule(c) {
    const codes = new Set(c.terms.map((t) => t.term));
    if (c.period === "full_year" || codes.has("FY")) return "Full Year";
    if (c.period === "semester") {
      if (codes.has("S1") && codes.has("S2")) return "Full Year";
      if (codes.has("S1")) return "First Semester";
      if (codes.has("S2")) return "Second Semester";
      return null;
    }
    const terms = TERMS_FOR_PERIOD[c.period].filter((t) => t !== "FY");
    if (terms.every((t) => codes.has(t))) return "Full Year";
    const have = terms.filter((t) => codes.has(t));
    return have.length === 1 ? SINGLE_TERM[have[0]] ?? null : null;
  }
  var SINGLE_TERM = {
    T1: "First Trimester",
    T2: "Second Trimester",
    T3: "Third Trimester",
    Q1: "First Quarter",
    Q2: "Second Quarter",
    Q3: "Third Quarter",
    Q4: "Fourth Quarter"
  };
  function buildCurrentYearPlan(schools, courses) {
    const byId = new Map(schools.map((s) => [s.id, s]));
    const hs = [...courses].sort((a, b) => a.sortOrder - b.sortOrder).filter((c) => byId.get(c.schoolId)?.kind === "high_school");
    if (!hs.length) return null;
    const latest = Math.max(...hs.map((c) => c.academicYear));
    const skipped = [];
    const rows = [];
    const periods = [];
    for (const c of hs.filter((x) => x.academicYear === latest)) {
      const { subject, level } = subjectAndLevel(byId.get(c.schoolId), c, "current", skipped);
      const schedule = currentSchedule(c);
      if (schedule == null) skipped.push({ where: "current", course: c.name, field: "schedule", reason: c.terms.length ? "terms are not the whole year or a single term: pick the schedule options by hand" : "no terms in tracker" });
      rows.push({ trackerId: c.id, name: c.name, subject, level, schedule });
      periods.push(c.period);
    }
    return { scheduleStem: STEM[mostCommon(periods)], rows, skipped };
  }

  // src/runner.ts
  var OPEN_RELOADS_NOTE = "Opening reloads the page: anything not yet saved in an open popup is discarded.";
  function needsSaveGuidance(item) {
    return item.stoppedOnPage === true && item.target !== "current";
  }
  var GRADE_ORDER2 = ["9", "10", "11", "12", "other"];
  var CURRENT_LABEL = "Current year courses";
  var TICK_REMINDER = "On each grade, tick 'I have reported all of my courses for this grade' yourself.";
  var STOP_GUIDANCE = "Nothing was saved for this grade yet. Press X on Common App to keep what was filled, or reload the page to discard it.";
  var STATUS = {
    signedOut: "Sign in again",
    studentsOnly: "This extension is for student accounts. Sign in with a student account.",
    network: "Could not load your transcript. Check your connection and try again.",
    nothing: "Nothing to fill: tick at least one item.",
    done: "Done",
    stopped: "Stopped"
  };
  function targetLabel(target) {
    return target === "current" ? CURRENT_LABEL : GRADE_LABEL[target];
  }
  var plural3 = (n, one, many) => `${n} ${n === 1 ? one : many}`;
  async function runFill(targets, driver, ask, shouldStop) {
    const items = [];
    for (const target of targets) {
      if (shouldStop()) return { items, stopped: true };
      try {
        await driver.open(target);
        if (shouldStop()) return { items, stopped: true };
        const { existing } = await driver.inspect(target);
        if (shouldStop()) return { items, stopped: true };
        const mode = existing.length > 0 ? await ask(target, existing.length) : "keep";
        if (shouldStop()) return { items, stopped: true };
        const result = await driver.fill(target, mode);
        const changes = result.notes?.length ? { changes: result.notes } : {};
        if (result.stoppedReason) {
          items.push({ target, filled: result.filled, blanks: result.blanks, ...changes, note: result.stoppedReason, stoppedOnPage: true });
          return { items, stopped: true };
        }
        items.push({ target, filled: result.filled, blanks: result.blanks, ...changes });
      } catch (e) {
        const reason = e instanceof Error ? e.message : String(e);
        items.push({ target, filled: 0, blanks: [], note: `Stopped: ${reason}` });
        return { items, stopped: true };
      }
    }
    return { items, stopped: false };
  }
  function buildPlans(schools, courses) {
    const cg = /* @__PURE__ */ new Map();
    for (const plan of buildCgPlan(schools, courses)) cg.set(plan.grade, plan);
    return { cg, current: buildCurrentYearPlan(schools, courses) };
  }
  function offersFor(plans) {
    const offers = [];
    for (const grade of GRADE_ORDER2) {
      const plan = plans.cg.get(grade);
      if (plan && plan.rows.length > 0) offers.push({ target: grade, label: GRADE_LABEL[grade], count: plan.rows.length });
    }
    if (plans.current && plans.current.rows.length > 0) offers.push({ target: "current", label: CURRENT_LABEL, count: plans.current.rows.length });
    return offers;
  }
  function offerText(offer) {
    return `${offer.label} (${plural3(offer.count, "course", "courses")})`;
  }
  async function startFill(load, run2, opts) {
    let loaded;
    try {
      loaded = await load();
    } catch {
      loaded = { ok: false, reason: "network" };
    }
    if (!loaded.ok) {
      const status = loaded.reason === "signed_out" ? STATUS.signedOut : loaded.reason === "students_only" ? STATUS.studentsOnly : STATUS.network;
      return { ok: false, status, reason: loaded.reason };
    }
    const plans = buildPlans(loaded.schools, loaded.courses);
    const offered = new Set(offersFor(plans).map((o) => o.target));
    const targets = [...GRADE_ORDER2, "current"].filter((t) => opts.targets.includes(t) && offered.has(t));
    if (targets.length === 0) return { ok: false, status: STATUS.nothing, reason: "nothing" };
    const warnings = [];
    for (const t of targets) if (t !== "current") for (const w of plans.cg.get(t)?.warnings ?? []) warnings.push(`${GRADE_LABEL[t]}: ${w}`);
    const { items, stopped } = await run2(targets, opts.makeDriver(plans), opts.ask, opts.shouldStop);
    return { ok: true, status: stopped ? STATUS.stopped : STATUS.done, items, stopped, warnings };
  }
  function filledText(item) {
    return `Filled ${plural3(item.filled, "course", "courses")}`;
  }
  function blankText(b) {
    const what = [b.course, b.field].filter(Boolean).join(": ");
    return what ? `${what} left blank: ${b.reason}` : b.reason;
  }
  function askText(target, existingCount) {
    return `${targetLabel(target)} already ${existingCount === 1 ? "has 1 course" : `has ${existingCount} courses`} on Common App.`;
  }

  // src/panel.ts
  var app = document.getElementById("app");
  function show(...nodes) {
    app.replaceChildren(h("h1", {}, "College application filler"), ...nodes.filter((n) => !!n));
  }
  async function loadTranscript() {
    try {
      const r = await chrome.runtime.sendMessage({ type: "loadTranscript" });
      return r?.type === "loadTranscript" ? r.result : { ok: false, reason: "network" };
    } catch {
      return { ok: false, reason: "network" };
    }
  }
  async function signIn() {
    try {
      const r = await chrome.runtime.sendMessage({ type: "signIn" });
      return r?.type === "signIn" && r.ok;
    } catch {
      return false;
    }
  }
  async function signOut() {
    try {
      await chrome.runtime.sendMessage({ type: "signOut" });
    } catch {
    }
  }
  async function activeTab() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      return { id: tab?.id ?? null, site: siteOf(tab?.url) };
    } catch {
      return { id: null, site: null };
    }
  }
  var ticked = /* @__PURE__ */ new Set();
  var transcript = null;
  var picked = null;
  var shownSite = null;
  var view = "other";
  var currentOffers = [];
  var stopRequested = false;
  function signedOutView(message) {
    view = "other";
    const note = h("p", { class: "note" }, message ?? "");
    show(
      h("p", {}, "Sign in with your College Tracker account so the extension can read your transcript. It cannot see anything else in your account."),
      message ? note : null,
      button("Sign in", async () => {
        note.textContent = "Waiting for the sign-in window...";
        if (await signIn()) await refresh();
        else signedOutView("Sign in did not finish. Try again.");
      }, "btn primary")
    );
  }
  function messageView(text, ...actions) {
    view = "other";
    show(h("p", { class: "note" }, text), h("div", { class: "row" }, ...actions));
  }
  async function refresh() {
    view = "other";
    show(h("p", { class: "muted" }, "Loading your transcript..."));
    const result = await loadTranscript();
    if (!result.ok) {
      if (result.reason === "signed_out") return signedOutView();
      if (result.reason === "students_only") return messageView(STATUS.studentsOnly, button("Sign out", async () => {
        await signOut();
        signedOutView();
      }));
      return messageView(STATUS.network, button("Try again", () => void refresh(), "btn primary"));
    }
    transcript = { schools: result.schools, courses: result.courses };
    currentOffers = offersFor(buildPlans(result.schools, result.courses));
    ticked = new Set(currentOffers.map((o) => o.target));
    await readyView();
  }
  function sitePicker(current) {
    const select = h("select", { "aria-label": "Application system" });
    for (const s of ["common_app", ...FILL_SYSTEMS]) {
      const o = h("option", { value: s }, SITE_LABEL[s]);
      o.selected = s === current;
      select.append(o);
    }
    select.addEventListener("change", () => {
      picked = select.value;
      void readyView();
    });
    return h("label", { class: "picker" }, "Fill for ", select);
  }
  async function readyView() {
    view = "ready";
    const tab = await activeTab();
    if (view !== "ready") return;
    const site = picked ?? tab.site ?? "common_app";
    shownSite = site;
    if (site !== "common_app") {
      if (!transcript) return void refresh();
      const onSite = tab.site === site ? tab.id : null;
      const auto = onSite == null ? site === "stars" || site === "uc" || site === "csu" ? h("p", { class: "note" }, `Open ${SITE_LABEL[site]} in this window (signed in), and the extension adds your courses for you.`) : null : site === "stars" ? await starsAutoView(buildStarsPlans(transcript.schools, transcript.courses), onSite) : site === "csu" ? csuAutoView(buildCsuPlans(transcript.schools, transcript.courses), onSite) : site === "uc" ? ucAutoView(buildUcPlans(transcript.schools, transcript.courses), onSite) : null;
      const node = await assistView(buildSystemPlan(site, transcript.schools, transcript.courses), onSite, auto);
      if (view !== "ready" || shownSite !== site) return;
      show(
        sitePicker(site),
        tab.site !== site && button(`Open ${SITE_LABEL[site]}`, () => void chrome.tabs.create({ url: SITE_HOME[site] }), "link"),
        node,
        h("div", { class: "row" }, button("Reload transcript", () => void refresh()), button("Sign out", async () => {
          await signOut();
          signedOutView();
        }))
      );
      return;
    }
    const tabId = tab.site === "common_app" ? tab.id : null;
    const boxes = currentOffers.map((o) => {
      const box = h("input", { type: "checkbox" });
      box.checked = ticked.has(o.target);
      box.addEventListener("change", () => {
        if (box.checked) ticked.add(o.target);
        else ticked.delete(o.target);
        fill.disabled = tabId === null || ticked.size === 0;
      });
      return h("label", { class: "check" }, box, h("span", {}, offerText(o)));
    });
    const fill = button("Fill selected", () => void run(tabId), "btn primary", tabId === null || ticked.size === 0);
    show(
      sitePicker("common_app"),
      currentOffers.length ? h("div", { class: "list" }, ...boxes) : h("p", { class: "note" }, "No courses with grades or current-year courses were found in your transcript."),
      tabId === null && h("p", { class: "note" }, "Open your Common App in this window first."),
      h("div", { class: "row" }, fill, button("Sign out", async () => {
        await signOut();
        signedOutView();
      }))
    );
  }
  async function run(tabId) {
    view = "other";
    stopRequested = false;
    const status = h("p", { class: "status" }, "Starting...");
    const prompt = h("div", {});
    let dismissPrompt = null;
    const stop = button("Stop", () => {
      stopRequested = true;
      dismissPrompt?.();
      status.textContent = "Stopping after the current field...";
      stop.disabled = true;
      chrome.tabs.sendMessage(tabId, { type: "stop" }).catch(() => {
      });
    }, "btn danger");
    show(status, prompt, h("div", { class: "row" }, stop));
    const ask = (target, count) => new Promise((resolve) => {
      const choose = (mode) => {
        dismissPrompt = null;
        prompt.replaceChildren();
        resolve(mode);
      };
      dismissPrompt = () => choose("keep");
      prompt.replaceChildren(
        h("div", { class: "ask" }, h("p", {}, askText(target, count)), h("div", { class: "row" }, button("Replace them", () => choose("replace"), "btn"), button("Keep them, add the rest", () => choose("keep"), "btn primary")))
      );
    });
    const targets = currentOffers.map((o) => o.target).filter((t) => ticked.has(t));
    const outcome = await startFill(loadTranscript, runFill, {
      targets,
      ask,
      shouldStop: () => stopRequested,
      makeDriver: (plans) => {
        const real = createDriver(chrome.tabs, tabId, plans);
        return {
          ...real,
          async open(t) {
            status.textContent = `Filling ${targetLabel(t)}...`;
            return real.open(t);
          }
        };
      }
    });
    reportView(outcome, targets, tabId);
  }
  function reportView(outcome, targets, tabId) {
    view = "other";
    if (!outcome.ok) {
      if (outcome.reason === "signed_out") return signedOutView(outcome.status);
      return messageView(outcome.status, button("Back", () => void refresh(), "btn primary"));
    }
    const sections = outcome.items.map((item) => {
      return h(
        "section",
        { class: "item" },
        h("h2", {}, targetLabel(item.target)),
        h("p", { class: "done" }, filledText(item)),
        item.note ? h("p", { class: "warn" }, item.note) : false,
        needsSaveGuidance(item) ? h("p", { class: "warn" }, STOP_GUIDANCE) : false,
        ...(item.changes ?? []).map((c) => h("p", { class: "note" }, c)),
        item.blanks.length ? h("ul", {}, ...item.blanks.map((b) => h("li", {}, blankText(b)))) : false,
        button(`Open ${targetLabel(item.target)} on Common App`, () => void chrome.tabs.update(tabId, { url: targetUrl(item.target) }), "link"),
        // After a stop the tab may hold an open dialog with unsaved rows; any of these links navigates that tab away.
        outcome.stopped ? h("p", { class: "note" }, OPEN_RELOADS_NOTE) : false
      );
    });
    const done = new Set(outcome.items.map((i) => i.target));
    const left = targets.filter((t) => !done.has(t));
    show(
      h("p", { class: outcome.stopped ? "status warn" : "status" }, outcome.status),
      ...sections,
      left.length ? h("p", { class: "note" }, `Not filled: ${left.map(targetLabel).join(", ")}.`) : false,
      outcome.warnings.length ? h("ul", { class: "warnings" }, ...outcome.warnings.map((w) => h("li", {}, w))) : false,
      h("p", { class: "note" }, TICK_REMINDER),
      h("div", { class: "row" }, button("Back", () => void refresh(), "btn primary"))
    );
  }
  var retab = async () => {
    if (view !== "ready") return;
    const { site } = await activeTab();
    if (shownSite !== "common_app" && (picked ?? site ?? "common_app") === shownSite) return;
    void readyView();
  };
  chrome.tabs.onActivated.addListener(() => void retab());
  chrome.tabs.onUpdated.addListener((_id, change) => {
    if (change.url || change.status === "complete") void retab();
  });
  void refresh();
})();
