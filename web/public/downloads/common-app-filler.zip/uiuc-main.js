"use strict";
(() => {
  // src/uiuc/dialogs.ts
  var DIALOG_CONTROL = "college-filler:uiuc-dialogs";
  var DIALOG_REPORT = "college-filler:uiuc-dialog";
  var DIALOG_HOOK_MAX_MS = 15 * 60 * 1e3;
  function installDialogHook(win) {
    let original = null;
    let timer = null;
    const report = (kind, message) => win.dispatchEvent(new win.CustomEvent(DIALOG_REPORT, { detail: JSON.stringify({ kind, text: String(message ?? "") }) }));
    const off = () => {
      if (original) {
        win.alert = original.alert;
        win.confirm = original.confirm;
      }
      original = null;
      if (timer) win.clearTimeout(timer);
      timer = null;
    };
    win.addEventListener(DIALOG_CONTROL, (e) => {
      const d = e.detail;
      if (d === "on") {
        if (!original) original = { alert: win.alert, confirm: win.confirm };
        win.alert = (m) => void report("alert", m);
        win.confirm = (m) => {
          report("confirm", m);
          return false;
        };
        if (timer) win.clearTimeout(timer);
        timer = win.setTimeout(off, DIALOG_HOOK_MAX_MS);
      } else if (d === "off") off();
    });
  }

  // src/uiuc-main.ts
  installDialogHook(window);
})();
