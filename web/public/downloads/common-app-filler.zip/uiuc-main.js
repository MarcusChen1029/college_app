"use strict";
(() => {
  // src/uiuc/dialogs.ts
  var DIALOG_CONTROL = "college-filler:uiuc-dialogs";
  var DIALOG_REPORT = "college-filler:uiuc-dialog";
  var DIALOG_HOOK_MAX_MS = 15 * 60 * 1e3;
  var NONCE_SHAPE = /^[0-9a-f]{32}$/;
  function parseControl(detail) {
    if (typeof detail !== "string") return null;
    try {
      const x = JSON.parse(detail);
      if ((x.cmd === "on" || x.cmd === "off") && typeof x.nonce === "string" && NONCE_SHAPE.test(x.nonce)) return { cmd: x.cmd, nonce: x.nonce };
    } catch {
    }
    return null;
  }
  function installDialogHook(win) {
    const dispatch = win.dispatchEvent.bind(win);
    const Custom = win.CustomEvent;
    let original = null;
    let timer = null;
    let nonce = null;
    const report = (kind, message) => {
      if (nonce) dispatch(new Custom(DIALOG_REPORT, { detail: JSON.stringify({ kind, text: String(message ?? ""), nonce }) }));
    };
    const off = () => {
      if (original) {
        win.alert = original.alert;
        win.confirm = original.confirm;
      }
      original = null;
      nonce = null;
      if (timer) win.clearTimeout(timer);
      timer = null;
    };
    win.addEventListener(DIALOG_CONTROL, (e) => {
      const c = parseControl(e.detail);
      if (!c) return;
      if (c.cmd === "on") {
        nonce = c.nonce;
        if (!original) original = { alert: win.alert, confirm: win.confirm };
        win.alert = (m) => void report("alert", m);
        win.confirm = (m) => {
          report("confirm", m);
          return false;
        };
        if (timer) win.clearTimeout(timer);
        timer = win.setTimeout(off, DIALOG_HOOK_MAX_MS);
      } else if (c.nonce === nonce) off();
    });
  }

  // src/uiuc-main.ts
  installDialogHook(window);
})();
