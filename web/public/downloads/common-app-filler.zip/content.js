"use strict";
(() => {
  // ../web/lib/transcript.ts
  var PERIOD_TYPES = ["full_year", "semester", "trimester", "quarter"];
  var LEVELS = [
    "regular",
    "accelerated",
    "advanced",
    "honors",
    "high_honors",
    "ap",
    "ib_hl",
    "ib_sl",
    "ib",
    "pre_ib",
    "a_level",
    "gcse_igcse",
    "college_prep",
    "dual_enrollment",
    "enriched",
    "gifted",
    "intensive",
    "regents",
    "other",
    "none"
  ];
  var SUBJECTS = ["english", "mathematics", "science", "history_social", "world_language", "arts", "computer_science", "business", "pe_health", "career_technical", "other"];
  var normalizeName = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();

  // ../web/lib/transcript-maps/types.ts
  var verified = (value, source, note) => ({ value, status: "verified", ...source ? { source } : {}, ...note ? { note } : {} });
  var unverified = (value, note, source) => ({ value, status: "unverified", ...note ? { note } : {}, ...source ? { source } : {} });
  var none = (note) => ({ value: null, status: "none", ...note ? { note } : {} });
  function table(keys, entries, fallback) {
    const out = {};
    for (const k of keys) out[k] = entries[k] ?? fallback;
    return out;
  }
  var isNonUs = (school) => {
    const c = school.country.trim().toLowerCase().replace(/\./g, "");
    return c !== "" && !["us", "usa", "united states", "united states of america", "america"].includes(c);
  };

  // ../web/lib/transcript-maps/common-app.ts
  var DECK = "https://www.commonapp.org/files/webinar_decks/Academic-Record-Reporting.pdf";
  var CATALOG = "https://appsupport.commonapp.org/applicantsupport/s/article/Data-catalogs";
  var IB = verified("International Baccalaureate (IB)", CATALOG, "Common App does not distinguish HL and SL");
  var NA = verified("N/A", CATALOG);
  var COMMON_APP_SUBJECTS = [
    "Pre-Algebra",
    "Algebra",
    "Geometry",
    "Trigonometry",
    "Pre-Calculus",
    "Calculus",
    "Math (Other)",
    "Biology",
    "Chemistry",
    "Physics",
    "Earth/Environmental Science",
    "Science (Other)",
    "English",
    "History/Social Science",
    "Foreign/World Language",
    "Physical Education/Health",
    "Art (Visual or Performing)",
    "Computer Science",
    "Religion",
    "Other/Elective"
  ];
  var S = (value, note) => verified(value, CATALOG, note);
  var MATH = { pre_algebra: "Pre-Algebra", algebra_1: "Algebra", algebra_2: "Algebra", geometry: "Geometry", trigonometry: "Trigonometry", precalculus: "Pre-Calculus", calculus: "Calculus" };
  var SCIENCE = { biology: "Biology", chemistry: "Chemistry", physics: "Physics", earth_space: "Earth/Environmental Science" };
  var COMMON_APP_MAP = {
    id: "common_app",
    label: "Common App",
    level: table(
      LEVELS,
      {
        regular: verified("Regular/Standard", CATALOG),
        accelerated: verified("Accelerated", CATALOG),
        advanced: verified("Advanced", CATALOG),
        honors: verified("Honors", CATALOG),
        high_honors: verified("High Honors", CATALOG),
        ap: verified("Advanced Placement (AP)", CATALOG),
        ib_hl: IB,
        ib_sl: IB,
        ib: IB,
        pre_ib: verified("Pre-IB", CATALOG),
        a_level: verified("AS/A-level/International A-level, Cambridge AICE", CATALOG, "One option"),
        gcse_igcse: verified("GCSE, IGCSE", CATALOG, "One option"),
        college_prep: verified("College Prep", CATALOG),
        dual_enrollment: verified("Dual Enrollment", CATALOG),
        enriched: verified("Enriched", CATALOG),
        gifted: verified("Gifted", CATALOG),
        intensive: verified("Intensive", CATALOG),
        regents: verified("Regents", CATALOG),
        other: NA,
        none: NA
      },
      unverified(null)
    ),
    subject: table(
      SUBJECTS,
      {
        english: S("English"),
        mathematics: S("Math (Other)", "Common App splits math by course; pick the sub-subject to get Algebra, Geometry, Calculus ..."),
        science: S("Science (Other)", "Common App splits science by course; pick the sub-subject to get Biology, Chemistry, Physics ..."),
        history_social: S("History/Social Science"),
        world_language: S("Foreign/World Language"),
        arts: S("Art (Visual or Performing)", "One option for visual art, music, dance and theater"),
        computer_science: S("Computer Science"),
        pe_health: S("Physical Education/Health"),
        business: S("Other/Elective"),
        career_technical: S("Other/Elective"),
        other: S("Other/Elective")
      },
      S("Other/Elective")
    ),
    subjectFor: (subject, sub) => {
      if (subject === "mathematics") return S(sub ? MATH[sub] ?? "Math (Other)" : "Math (Other)");
      if (subject === "science") return S(sub ? SCIENCE[sub] ?? "Science (Other)" : "Science (Other)");
      return null;
    },
    subjectList: {
      options: COMMON_APP_SUBJECTS,
      verified: true,
      note: 'One flat list with no sub-categories: music, dance, theater and visual art are all "Art (Visual or Performing)". Math and science are split by course, each with an "(Other)" option. Business, career-technical and anything else that is not listed go in "Other/Elective"; religion has its own option.'
    },
    subSubject: () => none("Common App's Subject list has no sub-category"),
    period: table(
      PERIOD_TYPES,
      {
        semester: verified("Semester", DECK),
        trimester: verified("Trimester", DECK),
        quarter: verified("Quarterly", DECK),
        full_year: verified("Yearly", DECK)
      },
      unverified(null)
    ),
    rules: (_school, course) => {
      const out = [];
      const graded = course.terms.some((t) => t.status === "graded" && t.grade);
      if (!graded && !course.finalGrade) out.push("Common App needs at least one grade for each course; leave a term blank only if the transcript shows none.");
      if (course.credit == null && course.creditUnit !== "not_listed") out.push("Common App needs at least one credit for each course; tick N/A if the transcript lists no credit.");
      if (!course.terms.length && course.finalGrade) out.push("Enter the term grades if the transcript shows them; Common App wants one grade per term.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/csu.ts
  var HELP = "https://help.liaisonedu.com/Cal_State_Apply_Applicant_Help_Center/Filling_Out_Your_Cal_State_Apply_Application/Cal_State_Apply_Academic_History";
  var COURSEWORK = `${HELP}/03_High_School_Coursework`;
  var AG = `${HELP}/07_A-G_Matching`;
  var GUIDE = "https://www.calstate.edu/apply/freshman/Documents/cal-state-apply-freshman-application-guide.pdf";
  var LIVE = "https://calstate.cas.myliaison.com/applicant/my-application";
  var IB2 = verified("International Baccalaureate", COURSEWORK);
  var CSU_MAP = {
    id: "csu",
    label: "Cal State Apply",
    level: table(
      LEVELS,
      {
        ap: verified("Advanced Placement", COURSEWORK, "+1 GPA point"),
        ib_hl: IB2,
        ib_sl: IB2,
        ib: IB2,
        honors: verified("Honors", COURSEWORK, "Only CSU-approved honors courses get the +1 point"),
        high_honors: unverified("Honors", "Only CSU-approved honors courses get the +1 point", COURSEWORK)
      },
      verified("None", COURSEWORK, "Course Type None (standard)")
    ),
    subject: table(
      SUBJECTS,
      {
        history_social: verified("A \u2013 History / Social Science", LIVE),
        english: verified("B \u2013 English", LIVE),
        mathematics: verified("C \u2013 Mathematics", LIVE),
        science: unverified(null, "Choose D1 (biological) or D2 (physical) science", GUIDE),
        world_language: verified("E \u2013 Language Other than English", LIVE),
        arts: verified("F \u2013 Visual & Performing Arts", LIVE),
        computer_science: unverified("G \u2013 College-Preparatory Elective", "Computer science may count under another area", AG),
        business: unverified("G \u2013 College-Preparatory Elective", "Only A-G approved courses count", AG),
        pe_health: unverified("G \u2013 College-Preparatory Elective", "Only A-G approved courses count", AG),
        career_technical: unverified("G \u2013 College-Preparatory Elective", "Only A-G approved courses count", AG),
        other: verified("G \u2013 College-Preparatory Elective", LIVE)
      },
      unverified(null)
    ),
    subjectFor: (subject, sub) => {
      if (subject !== "science") return null;
      if (sub === "biology") return verified("D1 \u2013 Biological Science", LIVE);
      if (sub === "chemistry" || sub === "physics") return verified("D2 \u2013 Physical Science", LIVE);
      if (sub === "earth_space") return unverified("D2 \u2013 Physical Science", "Earth and space science may be matched differently", GUIDE);
      return unverified(null, "Choose D1 (biological) or D2 (physical) science", GUIDE);
    },
    subjectList: {
      options: [
        "A \u2013 History / Social Science",
        "B \u2013 English",
        "C \u2013 Mathematics",
        "D1 \u2013 Biological Science",
        "D2 \u2013 Physical Science",
        "E \u2013 Language Other than English",
        "F \u2013 Visual & Performing Arts",
        "G \u2013 College-Preparatory Elective"
      ],
      verified: true,
      note: "Biology and life science are D1; chemistry, physics and earth science are D2. Music, art, dance and theater are all F. Anything else that counts is G."
    },
    subSubject: () => none("Cal State Apply has no sub-category under an A-G area"),
    period: table(
      PERIOD_TYPES,
      { full_year: verified("Full Year", LIVE), semester: verified("Semester", LIVE), trimester: verified("Trimester", LIVE), quarter: verified("Quarter", LIVE) },
      unverified(null)
    ),
    rules: (school, course) => {
      const out = [];
      if (isNonUs(school)) out.push("Applicants who attended only foreign high schools skip course entry on Cal State Apply; type grades as printed if you do enter them.");
      if (school.kind === "college" || course.isCollege) out.push("College courses go in the College Coursework section, not High School Coursework.");
      if (course.terms.some((t) => t.gradeWeighted)) out.push("Enter the grade shown on the transcript; Cal State Apply computes its own GPA.");
      if (course.terms.some((t) => t.status === "in_progress" || t.status === "planned")) out.push("Mark in-progress terms In Progress and later terms Planned.");
      if (course.isRepeat) out.push("Report only the highest grade for a repeated course.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/stars-lists.ts
  var STARS_INTL_TITLES = {
    Mathematics: [
      "ALGEBRA 1",
      "GEOMETRY",
      "ALGEBRA 2",
      "TRIGONOMETRY",
      "PRECALCULUS",
      "CALCULUS",
      "STATISTICS",
      "ADVANCED MATH",
      "APPLIED MATH",
      "BUSINESS MATH",
      "CONSUMER MATH",
      "DIFFERENTIAL EQUATIONS",
      "DISCRETE MATH",
      "ELEMENTARY FUNCTIONS",
      "FINITE MATHEMATICS",
      "LINEAR ALGEBRA",
      "LINEAR PROGRAMMING",
      "MATH ANALYSIS",
      "PRE-ALGEBRA",
      "INTEGRATED ALGEBRA/GEOMETRY",
      "INTEGRATED ALGEBRA/GEOMETRY/TRIGONOMETRY",
      "IB MATH ANALYSIS AND APPROACHES HL",
      "IB MATH ANALYSIS AND APPROACHES SL",
      "IB MATH APPLICATIONS AND INTERPRETATIONS HL",
      "IB MATH APPLICATIONS AND INTERPRETATIONS SL",
      "IB MATH MYP",
      "IB MATH STUDIES",
      "IB MATHEMATICS",
      "OTHER MATH",
      "ALGEBRA 2/TRIGONOMETRY",
      "ALGEBRA 3/TRIGONOMETRY",
      "COLLEGE ALGEBRA",
      "COLLEGE ALGEBRA/TRIGONOMETRY",
      "COLLEGE MATH",
      "TRIGONOMETRY/PRE-CALCULUS"
    ],
    Science: [
      "BIOLOGY",
      "CHEMISTRY",
      "PHYSICS",
      "ENVIRONMENTAL SCIENCE",
      "EARTH SCIENCE",
      "ANATOMY & PHYSIOLOGY",
      "PHYSICAL SCIENCE",
      "AEROSPACE",
      "ANATOMY",
      "ASTRONOMY",
      "BOTANY",
      "ECOLOGY",
      "ELECTRICITY AND MAGNETISM",
      "FORENSIC SCIENCE",
      "GENETICS",
      "GEOLOGY",
      "INTEGRATED SCIENCE",
      "INTRO TO ENGINEERING",
      "INTRO TO SCIENCE",
      "LIFE SCIENCE",
      "MARINE SCIENCE/BIOLOGY",
      "METEOROLOGY",
      "MICROBIOLOGY",
      "NUTRITION/FOOD SCIENCE",
      "OCEANOGRAPHY",
      "ORGANIC CHEMISTRY",
      "PHYSIOLOGY",
      "PRINCIPLES OF ENGINEERING",
      "SCIENCE, TECH, & SOCIETY",
      "ZOOLOGY",
      "OTHER SCIENCE"
    ],
    "History / Social Studies": [
      "AMERICAN/US HISTORY",
      "CIVICS",
      "ECONOMICS",
      "GEOGRAPHY",
      "GOVERNMENT AND POLITICS",
      "PSYCHOLOGY",
      "SOCIOLOGY",
      "US GOVERNMENT",
      "WORLD HISTORY",
      "AFRICAN AMERICAN STUDIES/HISTORY",
      "ANCIENT & MEDIEVAL HISTORY",
      "ANCIENT CIVILIZATIONS",
      "ANTHROPOLOGY",
      "COMPARATIVE GOVT/POLITICS",
      "CONTEMPORARY WORLD ISSUES",
      "ETHNIC STUDIES",
      "EUROPEAN HISTORY",
      "GENDER STUDIES",
      "GLOBAL STUDIES",
      "HUMANITIES",
      "INTERNATIONAL RELATIONS",
      "LAW STUDIES",
      "MACROECONOMICS",
      "MICROECONOMICS",
      "PHILOSOPHY",
      "POLITICAL SCIENCE",
      "SOCIAL STUDIES",
      "SOCIOLOGY 2",
      "US & WORLD AFFAIRS",
      "WESTERN CIVILIZATION",
      "WORLD CIVILIZATIONS",
      "WORLD CULTURES",
      "WORLD RELIGIONS",
      "OTHER HISTORY/SOCIAL STUDIES"
    ],
    Languages: [
      "ENGLISH 9 (FIRST YEAR)",
      "SPANISH 1 (FIRST YEAR)",
      "SPANISH 2 (SECOND YEAR)",
      "SPANISH 3 (THIRD YEAR)",
      "SPANISH 4 (FOURTH YEAR)",
      "SPANISH 5 (FIFTH YEAR)",
      "SPANISH 6 (SIXTH YEAR)",
      "SPANISH FOR NATIVE SPEAKERS",
      "SPANISH LANGUAGE & CULTURE",
      "SPANISH LANGUAGE & LITERATURE",
      "SPANISH LITERATURE",
      "SPANISH LITERATURE & CULTURE",
      "ENGLISH 10 (SECOND YEAR)",
      "ENGLISH 11 (THIRD YEAR)",
      "ENGLISH 12 (FOURTH YEAR)",
      "FRENCH 1 (FIRST YEAR)",
      "FRENCH 2 (SECOND YEAR)",
      "FRENCH 3 (THIRD YEAR)",
      "FRENCH 4 (FOURTH YEAR)",
      "FRENCH 5 (FIFTH YEAR)",
      "FRENCH 6 (SIXTH YEAR)",
      "FRENCH LANGUAGE & CULTURE",
      "FRENCH LANGUAGE & LITERATURE",
      "FRENCH LITERATURE",
      "ENGLISH LANGUAGE AND COMPOSITION",
      "ENGLISH LANGUAGE AND LITERATURE",
      "ENGLISH LITERATURE AND COMPOSITION",
      "LATIN 1 (FIRST YEAR)",
      "LATIN 2 (SECOND YEAR)",
      "LATIN 3 (THIRD YEAR)",
      "LATIN 4 (FOURTH YEAR)",
      "LATIN 5 (FIFTH YEAR)",
      "LATIN 6 (SIXTH YEAR)",
      "ENGLISH LITERATURE",
      "AMERICAN LITERATURE",
      "BRITISH LITERATURE",
      "CLASSIC LITERATURE",
      "COMMUNICATIONS",
      "CREATIVE WRITING",
      "ENGLISH COMPOSITION 1",
      "ENGLISH COMPOSITION 2",
      "ESL 1 (ENGL AS A SECOND LANG 1)",
      "ESL 2 (ENGL AS A SECOND LANG 2)",
      "FORENSIC SPEECH-DEBATE",
      "JOURNALISM",
      "MYTHOLOGY",
      "PUBLIC SPEAKING",
      "RESEARCH (ENGLISH)",
      "SEMINAR",
      "WORLD LITERATURE",
      "AMERICAN INDIAN 1 (FIRST YEAR)",
      "AMERICAN INDIAN 2 (SECOND YEAR)",
      "AMERICAN INDIAN 3 (THIRD YEAR)",
      "AMERICAN INDIAN 4 (FOURTH YEAR)",
      "AMERICAN INDIAN 5 (FIFTH YEAR)",
      "AMERICAN INDIAN 6 (SIXTH YEAR)",
      "AMERICAN INDIAN IMMERSION",
      "AMERICAN INDIAN LANGUAGE & LITERATURE",
      "AMERICAN INDIAN LITERATURE",
      "AMERICAN SIGN LANGUAGE 1 (FIRST YEAR)",
      "AMERICAN SIGN LANGUAGE 2 (SECOND YEAR)",
      "AMERICAN SIGN LANGUAGE 3 (THIRD YEAR)",
      "AMERICAN SIGN LANGUAGE 4 (FOURTH YEAR)",
      "AMERICAN SIGN LANGUAGE 5 (FIFTH YEAR)",
      "AMERICAN SIGN LANGUAGE 6 (SIXTH YEAR)",
      "ARABIC 1 (FIRST YEAR)",
      "ARABIC 2 (SECOND YEAR)",
      "ARABIC 3 (THIRD YEAR)",
      "ARABIC 4 (FOURTH YEAR)",
      "ARABIC 5 (FIFTH YEAR)",
      "ARABIC 6 (SIXTH YEAR)",
      "ARABIC LANGUAGE & LITERATURE",
      "ARABIC LITERATURE",
      "BRAILLE",
      "CHINESE 1 (FIRST YEAR)",
      "CHINESE 2 (SECOND YEAR)",
      "CHINESE 3 (THIRD YEAR)",
      "CHINESE 4 (FOURTH YEAR)",
      "CHINESE 5 (FIFTH YEAR)",
      "CHINESE 6 (SIXTH YEAR)",
      "CHINESE LANGUAGE & CULTURE",
      "CHINESE LANGUAGE & LITERATURE",
      "CHINESE LITERATURE",
      "CLASSICAL GREEK 1 (FIRST YEAR)",
      "CLASSICAL GREEK 2 (SECOND YEAR)",
      "CLASSICAL GREEK 3 (THIRD YEAR)",
      "CLASSICAL GREEK 4 (FOURTH YEAR)",
      "CLASSICAL GREEK 5 (FIFTH YEAR)",
      "CLASSICAL GREEK 6 (SIXTH YEAR)",
      "CLASSICAL HEBREW 1 (FIRST YEAR)",
      "CLASSICAL HEBREW 2 (SECOND YEAR)",
      "CLASSICAL HEBREW 3 (THIRD YEAR)",
      "CLASSICAL HEBREW 4 (FOURTH YEAR)",
      "CLASSICAL HEBREW 5 (FIFTH YEAR)",
      "CLASSICAL HEBREW 6 (SIXTH YEAR)",
      "FILIPINO 1 (FIRST YEAR)",
      "FILIPINO 2 (SECOND YEAR)",
      "FILIPINO 3 (THIRD YEAR)",
      "FILIPINO 4 (FOURTH YEAR)",
      "FILIPINO 5 (FIFTH YEAR)",
      "FILIPINO 6 (SIXTH YEAR)",
      "FILIPINO LANGUAGE & LITERATURE",
      "FILIPINO LITERATURE",
      "GERMAN 1 (FIRST YEAR)",
      "GERMAN 2 (SECOND YEAR)",
      "GERMAN 3 (THIRD YEAR)",
      "GERMAN 4 (FOURTH YEAR)",
      "GERMAN 5 (FIFTH YEAR)",
      "GERMAN 6 (SIXTH YEAR)",
      "GERMAN LANGUAGE & CULTURE",
      "GERMAN LANGUAGE & LITERATURE",
      "GERMAN LITERATURE",
      "GREEK 1 (FIRST YEAR)",
      "GREEK 2 (SECOND YEAR)",
      "GREEK 3 (THIRD YEAR)",
      "GREEK 4 (FOURTH YEAR)",
      "GREEK 5 (FIFTH YEAR)",
      "GREEK 6 (SIXTH YEAR)",
      "GREEK LANGUAGE & LITERATURE",
      "GREEK LITERATURE",
      "HEBREW 1 (FIRST YEAR)",
      "HEBREW 2 (SECOND YEAR)",
      "HEBREW 3 (THIRD YEAR)",
      "HEBREW 4 (FOURTH YEAR)",
      "HEBREW 5 (FIFTH YEAR)",
      "HEBREW 6 (SIXTH YEAR)",
      "HEBREW LANGUAGE & LITERATURE",
      "HEBREW LITERATURE",
      "HINDI 1 (FIRST YEAR)",
      "HINDI 2 (SECOND YEAR)",
      "HINDI 3 (THIRD YEAR)",
      "HINDI 4 (FOURTH YEAR)",
      "HINDI 5 (FIFTH YEAR)",
      "HINDI 6 (SIXTH YEAR)",
      "ITALIAN 1 (FIRST YEAR)",
      "ITALIAN 2 (SECOND YEAR)",
      "ITALIAN 3 (THIRD YEAR)",
      "ITALIAN 4 (FOURTH YEAR)",
      "ITALIAN 5 (FIFTH YEAR)",
      "ITALIAN 6 (SIXTH YEAR)",
      "ITALIAN LANGUAGE & CULTURE",
      "ITALIAN LANGUAGE & LITERATURE",
      "ITALIAN LITERATURE",
      "JAPANESE 1 (FIRST YEAR)",
      "JAPANESE 2 (SECOND YEAR)",
      "JAPANESE 3 (THIRD YEAR)",
      "JAPANESE 4 (FOURTH YEAR)",
      "JAPANESE 5 (FIFTH YEAR)",
      "JAPANESE 6 (SIXTH YEAR)",
      "JAPANESE LANGUAGE & CULTURE",
      "JAPANESE LANGUAGE & LITERATURE",
      "JAPANESE LITERATURE",
      "KOREAN 1 (FIRST YEAR)",
      "KOREAN 2 (SECOND YEAR)",
      "KOREAN 3 (THIRD YEAR)",
      "KOREAN 4 (FOURTH YEAR)",
      "KOREAN 5 (FIFTH YEAR)",
      "KOREAN 6 (SIXTH YEAR)",
      "KOREAN LANGUAGE & LITERATURE",
      "KOREAN LITERATURE",
      "PORTUGUESE 1 (FIRST YEAR)",
      "PORTUGUESE 2 (SECOND YEAR)",
      "PORTUGUESE 3 (THIRD YEAR)",
      "PORTUGUESE 4 (FOURTH YEAR)",
      "PORTUGUESE 5 (FIFTH YEAR)",
      "PORTUGUESE 6 (SIXTH YEAR)",
      "PORTUGUESE LANGUAGE & LITERATURE",
      "PORTUGUESE LITERATURE",
      "RUSSIAN 1 (FIRST YEAR)",
      "RUSSIAN 2 (SECOND YEAR)",
      "RUSSIAN 3 (THIRD YEAR)",
      "RUSSIAN 4 (FOURTH YEAR)",
      "RUSSIAN 5 (FIFTH YEAR)",
      "RUSSIAN 6 (SIXTH YEAR)",
      "RUSSIAN LANGUAGE & LITERATURE",
      "RUSSIAN LITERATURE",
      "SWAHILI 1 (FIRST YEAR)",
      "SWAHILI 2 (SECOND YEAR)",
      "SWAHILI 3 (THIRD YEAR)",
      "SWAHILI 4 (FOURTH YEAR)",
      "SWAHILI 5 (FIFTH YEAR)",
      "SWAHILI 6 (SIXTH YEAR)",
      "SWAHILI LANGUAGE & LITERATURE",
      "SWAHILI LITERATURE",
      "URDU 1 (FIRST YEAR)",
      "URDU 2 (SECOND YEAR)",
      "URDU 3 (THIRD YEAR)",
      "URDU 4 (FOURTH YEAR)",
      "URDU 5 (FIFTH YEAR)",
      "URDU 6 (SIXTH YEAR)",
      "VIETNAMESE 1 (FIRST YEAR)",
      "VIETNAMESE 2 (SECOND YEAR)",
      "VIETNAMESE 3 (THIRD YEAR)",
      "VIETNAMESE 4 (FOURTH YEAR)",
      "VIETNAMESE 5 (FIFTH YEAR)",
      "VIETNAMESE 6 (SIXTH YEAR)",
      "VIETNAMESE LANGUAGE & LITERATURE",
      "VIETNAMESE LITERATURE",
      "OTHER ENGLISH",
      "OTHER LANGUAGE"
    ],
    "Computer Science / Info Tech": [
      "COMPUTER APPLICATIONS",
      "COMPUTER GRAPHICS DESIGN",
      "COMPUTER KEYBOARDING",
      "COMPUTER PROGRAMMING",
      "COMPUTER SCIENCE 1",
      "COMPUTER SCIENCE 2",
      "INFORMATION TECHNOLOGY",
      "WEB DESIGN AND DEVELOPMENT",
      "OTHER COMPUTER SCIENCE"
    ],
    Business: [
      "ACCOUNTING 1",
      "BUSINESS LAW",
      "BUSINESS MANAGEMENT",
      "ENTREPRENEURSHIP",
      "FINANCE",
      "INTRO TO BUSINESS",
      "MARKETING",
      "ACCOUNTING 2",
      "ADVERTISING",
      "BANKING",
      "BANKING AND FINANCE",
      "COMPUTER BUSINESS APPLICATIONS",
      "CONSUMER LAW",
      "HUMAN RESOURCES",
      "INTERNATIONAL BUSINESS",
      "INVESTING",
      "LEGAL SYSTEM",
      "MANAGEMENT",
      "OTHER BUSINESS",
      "FINANCIAL LITERACY/PERSONAL FINANCE"
    ],
    "Fine Arts / Music": [
      "ART",
      "BAND",
      "CERAMICS",
      "CHORUS",
      "MUSIC",
      "ORCHESTRA",
      "PHOTOGRAPHY",
      "THEATRE ARTS",
      "ACTING/DRAMA",
      "ART HISTORY",
      "CERAMICS 2",
      "CREATIVE ART--DRAW-PAINT-ETC",
      "DANCE",
      "DRAMA",
      "GRAPHIC DESIGN",
      "INSTRUMENTAL MUSIC",
      "MUSIC APPRECIATION",
      "MUSIC HISTORY 1",
      "MUSIC HISTORY 2",
      "MUSIC THEORY 1",
      "MUSIC THEORY 2",
      "PHOTOGRAPHY 2",
      "STUDIO ART",
      "VIDEO PRODUCTION",
      "OTHER FINE ART",
      "OTHER MUSIC"
    ],
    "Phys. Ed / Health / Gym": ["HEALTH EDUCATION", "PHYSICAL EDUCATION", "PHYSICAL EDUCATION AND HEALTH", "VARSITY SPORT", "OTHER PHYSICAL EDUCATION"],
    "Other Subject Area": [
      "ACT/SAT PREPARATION",
      "CULINARY ARTS",
      "DRIVERS EDUCATION",
      "RELIGION",
      "SEMINAR",
      "AGRICULTURE",
      "ARCHITECTURE",
      "CRIMINAL JUSTICE",
      "DIGITAL ELECTRONICS",
      "ETHICS/MORALITY",
      "FAMILY CONSUMER SCIENCE",
      "FRESHMAN SEMINAR",
      "INTERNSHIP",
      "JUNIOR ROTC / ROTC",
      "RESEARCH",
      "ROBOTICS",
      "YEARBOOK",
      "OTHER",
      "CONSTRUCTION / MANUFACTURING",
      "HOSPITALITY / TOURISM",
      "MILITARY SCIENCE",
      "NATURAL RESOURCES /FORESTRY",
      "TRANSPORTATION / LOGISTICS"
    ]
  };
  var STARS_INTL_SUBJECT = {
    english: "Languages",
    mathematics: "Mathematics",
    science: "Science",
    history_social: "History / Social Studies",
    world_language: "Languages",
    arts: "Fine Arts / Music",
    computer_science: "Computer Science / Info Tech",
    business: "Business",
    pe_health: "Phys. Ed / Health / Gym",
    career_technical: "Other Subject Area",
    other: "Other Subject Area"
  };
  function starsIntlOtherTitle(subject) {
    if (subject === "english") return "OTHER ENGLISH";
    if (subject === "world_language") return "OTHER LANGUAGE";
    if (subject === "arts") return "OTHER FINE ART";
    return STARS_INTL_TITLES[STARS_INTL_SUBJECT[subject]].find((t) => t.startsWith("OTHER"));
  }

  // ../web/lib/transcript-maps/stars.ts
  var HELP2 = "https://starsrecord.zendesk.com/hc/en-us/articles";
  var SUBJECT_SRC = `${HELP2}/37027194180251`;
  var LEVEL_SRC = `${HELP2}/37036006202523`;
  var LENGTH_SRC = `${HELP2}/37036235354779`;
  var IB3 = verified("International Baccalaureate (IB)", LEVEL_SRC);
  var LIVE2 = "https://srar.selfreportedtranscript.com";
  var OTHER_LEVEL = unverified(null, "STARS's full Course Level dropdown could not be retrieved", LEVEL_SRC);
  var STARS_MAP = {
    id: "stars",
    label: "STARS",
    level: table(
      LEVELS,
      {
        regular: verified("Standard", LEVEL_SRC, "The default when no other level applies"),
        honors: verified("Honors", LEVEL_SRC),
        ap: verified("Advanced Placement (AP)", LEVEL_SRC),
        ib_hl: IB3,
        ib_sl: IB3,
        ib: IB3,
        dual_enrollment: verified("Dual Enrollment", LEVEL_SRC, "Needs the college name"),
        college_prep: verified("College Prep", LEVEL_SRC),
        regents: verified("Regents", LEVEL_SRC),
        gifted: verified("Gifted and Talented", LEVEL_SRC),
        other: unverified("Standard", "Assumed; STARS's full list could not be retrieved", LEVEL_SRC),
        none: unverified("Standard", "Assumed; STARS's full list could not be retrieved", LEVEL_SRC)
      },
      OTHER_LEVEL
    ),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", SUBJECT_SRC),
        mathematics: verified("Mathematics", SUBJECT_SRC),
        science: verified("Science", SUBJECT_SRC),
        history_social: verified("History / Social Studies", SUBJECT_SRC),
        world_language: verified("World Language", SUBJECT_SRC),
        arts: verified("Fine Arts / Music", SUBJECT_SRC),
        computer_science: verified("Computer Science", SUBJECT_SRC),
        business: verified("Business", SUBJECT_SRC),
        pe_health: verified("Physical Education / Health / Gym", SUBJECT_SRC),
        career_technical: unverified("Other Subject Area", "No career-technical area exists in STARS's list", SUBJECT_SRC),
        other: unverified("Other Subject Area", void 0, SUBJECT_SRC)
      },
      unverified(null)
    ),
    subjectList: {
      options: [
        "English",
        "Mathematics",
        "Science",
        "History / Social Studies",
        "World Language",
        "Business",
        "Computer Science",
        "Fine Arts / Music",
        "Physical Education / Health / Gym",
        "Other Subject Area"
      ],
      verified: true,
      note: 'Psychology and economics go under History / Social Studies. Music, band, choir, art, dance and theater are all "Fine Arts / Music". STARS also asks for a Generic Course Title under each subject; those lists are not published.'
    },
    subSubject: () => unverified(null, "STARS's Generic Course Title lists could not be retrieved", SUBJECT_SRC),
    period: table(
      PERIOD_TYPES,
      {
        full_year: verified("Full Year", LENGTH_SRC),
        semester: verified("Semester", LENGTH_SRC),
        trimester: verified("Trimester", LENGTH_SRC),
        quarter: verified("Quarterly", LENGTH_SRC)
      },
      unverified(null)
    ),
    genericTitle: (school, course) => {
      if (!isNonUs(school)) return unverified(null, "STARS's generic course titles for US schools could not be read; pick it on STARS", SUBJECT_SRC);
      const title = course.name.normalize("NFKC").trim().toUpperCase().replace(/\s+/g, " ");
      const list = STARS_INTL_TITLES[STARS_INTL_SUBJECT[course.subject]];
      if (list.includes(title)) return verified(title, LIVE2);
      return unverified(starsIntlOtherTitle(course.subject), "No title in STARS's list matches the course name exactly; pick a closer one if there is", LIVE2);
    },
    rules: (_school, course) => {
      const out = [];
      if (course.terms.some((t) => t.gradeWeighted)) out.push("STARS wants the unweighted grade when both are printed.");
      if (course.terms.some((t) => t.status === "in_progress")) out.push("Enter IP (In Progress) for courses without a final grade.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/uc.ts
  var QRG = "https://admission.universityofcalifornia.edu/counselors/_files/documents/quick-reference-guide-to-uc-admissions.pdf";
  var DAVIS = "https://www.ucdavis.edu/admissions/undergraduate/first-year/application-tips";
  var IB4 = verified("IB", QRG);
  var NH_NOTE = "Flag UC-approved honors courses only";
  var NOT_AG = "Not an A-G subject; it may go under Other coursework in Activities & awards";
  var WORDING = "UC's A-G area names are official, but the exact dropdown wording is not published";
  var area = (value, note) => unverified(value, note ? `${WORDING}. ${note}` : WORDING, QRG);
  var LETTER_SIGN = /^([A-F])[+-]$/i;
  var PASS_FAIL = /^(p|np|cr|nc|pass|fail|credit|no credit)$/i;
  var allGrades = (c) => [...c.terms.map((t) => t.grade), c.finalGrade ?? ""].filter(Boolean);
  var UC_MAP = {
    id: "uc",
    label: "UC",
    level: table(
      LEVELS,
      {
        ap: verified("AP", QRG),
        ib_hl: IB4,
        ib_sl: IB4,
        ib: IB4,
        honors: unverified("HL", "Only if the course is on the school's UC-approved honors list", QRG),
        dual_enrollment: verified("CL", DAVIS, "College course: enter it under Colleges attended"),
        high_honors: unverified("NH", NH_NOTE, QRG),
        advanced: unverified("NH", NH_NOTE, QRG),
        accelerated: unverified("NH", NH_NOTE, QRG),
        a_level: unverified("NH", "UC gives honors weight only to AP and IB for non-California students", QRG)
      },
      verified("NH", QRG, "Not honors")
    ),
    subject: table(
      SUBJECTS,
      {
        history_social: area("A \u2013 History / social science"),
        english: area("B \u2013 English"),
        mathematics: area("C \u2013 Mathematics"),
        science: area("D \u2013 Science"),
        world_language: area("E \u2013 Language other than English"),
        arts: area("F \u2013 Visual and performing arts"),
        computer_science: area("G \u2013 College-preparatory elective", "Computer science may count under C or D when the school lists it there"),
        other: area("G \u2013 College-preparatory elective"),
        business: none(NOT_AG),
        pe_health: none(NOT_AG),
        career_technical: none(NOT_AG)
      },
      unverified(null)
    ),
    subjectList: {
      options: [
        "A \u2013 History / social science",
        "B \u2013 English",
        "C \u2013 Mathematics",
        "D \u2013 Science",
        "E \u2013 Language other than English",
        "F \u2013 Visual and performing arts",
        "G \u2013 College-preparatory elective"
      ],
      verified: false,
      note: "These are UC's A-G area names; the exact dropdown wording is not published. For visual and performing arts UC's disciplines are Dance, Music, Theater, Visual Arts and Interdisciplinary Arts; for science: Biology/Life Sciences, Chemistry, Physics, Earth & Space Sciences, Integrated Science. PE, business and career-technical courses are not A-G subjects."
    },
    subSubject: (subject, sub) => {
      const POLICY = "A discipline in UC's policy; the application may not ask for it";
      if (subject === "arts") {
        const d = { visual: "Visual Arts", music: "Music", theater: "Theater", dance: "Dance", interdisciplinary: "Interdisciplinary Arts" };
        return sub && d[sub] ? verified(d[sub], QRG, POLICY) : none();
      }
      if (subject === "mathematics") {
        const d = { algebra_1: "Algebra I or Math I", geometry: "Geometry or Math II", algebra_2: "Algebra II or Math III", precalculus: "Precalculus", calculus: "Calculus" };
        return sub && d[sub] ? verified(d[sub], QRG, POLICY) : unverified("Other Advanced Math", POLICY, QRG);
      }
      if (subject === "science") {
        const d = { biology: "Biology/Life Sciences", chemistry: "Chemistry", physics: "Physics", earth_space: "Earth & Space Sciences", integrated: "Integrated Science" };
        return sub && d[sub] ? verified(d[sub], QRG, POLICY) : unverified(null, POLICY, QRG);
      }
      return none();
    },
    period: table(
      PERIOD_TYPES,
      { full_year: unverified("Full year"), semester: unverified("Semester"), trimester: unverified("Trimester"), quarter: unverified("Quarter") },
      unverified(null)
    ),
    termGrade: (t) => t.status === "in_progress" ? "IP" : t.status === "planned" ? "PL" : t.status === "none" ? "NO" : t.grade.replace(LETTER_SIGN, "$1"),
    noCredit: "UC has no per-course credit field",
    rules: (_school, course) => {
      const out = [];
      const grades = allGrades(course);
      if (grades.some((g) => LETTER_SIGN.test(g))) out.push("UC ignores + and -: a B+ is entered as B.");
      if (course.scale === "pass_fail" || grades.some((g) => PASS_FAIL.test(g))) out.push("UC does not accept Pass/Fail grades for A-G courses.");
      if (course.isCollege) out.push("Enter this under Colleges attended, not in the high school section.");
      if (course.isSummer) out.push("Tick the summer box for this grade level.");
      if (course.subject === "pe_health" || course.subject === "career_technical" || course.subject === "business") out.push("Not reportable as A-G; it may go under Other coursework in Activities & awards.");
      if (course.isRepeat) out.push("Report both the original course and the repeat.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/uiuc.ts
  var HELP3 = "https://www.admissions.illinois.edu/international-baccalaureate-application-help/";
  var SRC = HELP3;
  var OTHER_NOTE = "UIUC has no Fine Arts, Computer Science or PE subject; they go under Other";
  var UIUC_SUBJECTS = ["English", "Mathematics", "Science", "Social Science", "Language Other Than English", "Other"];
  var UIUC_MAP = {
    id: "uiuc",
    label: "UIUC SRAR",
    level: table(
      LEVELS,
      {
        regular: verified("Regular", SRC),
        advanced: verified("Advanced", SRC),
        enriched: verified("Enriched", SRC),
        ap: unverified("AP", 'Shown as "AP" / "AP Course" on a low-resolution screenshot', SRC),
        ib_hl: verified("IB HL", SRC),
        ib_sl: verified("IB SL", SRC),
        honors: unverified("Honors", "UIUC's tutorial mentions honors; not seen on an official screenshot", SRC),
        none: none("Leave Type empty unless the transcript lists one")
      },
      unverified(null, "UIUC's full Type list is not published; choose a Type only if the transcript lists it", SRC)
    ),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", SRC),
        mathematics: verified("Mathematics", SRC),
        science: verified("Science", SRC),
        history_social: verified("Social Science", SRC),
        world_language: verified("Language Other Than English", SRC),
        arts: verified("Other", SRC, OTHER_NOTE),
        computer_science: verified("Other", SRC, OTHER_NOTE),
        pe_health: verified("Other", SRC, OTHER_NOTE),
        career_technical: verified("Other", SRC, OTHER_NOTE),
        business: unverified("Other", "Business may be Social Science or Other", SRC),
        other: verified("Other", SRC)
      },
      unverified(null)
    ),
    subjectList: { options: UIUC_SUBJECTS, verified: true, note: 'Arts, computer science, PE and everything that is not one of the five core subjects are "Other".' },
    subSubject: () => none("UIUC has no sub-category"),
    period: table(
      PERIOD_TYPES,
      {
        full_year: verified("All Year", SRC),
        semester: verified("1st Semester / 2nd Semester", SRC, "Enter one row per semester"),
        trimester: unverified(null, "Trimester labels are not published; enter one row per trimester", SRC),
        quarter: unverified(null, "Quarter labels are not published; enter one row per quarter", SRC)
      },
      unverified(null)
    ),
    noCredit: "UIUC's SRAR has no credit field",
    rules: (_school, course) => {
      const out = [];
      if (course.terms.length > 0 && course.finalGrade) out.push("UIUC wants every semester, trimester or quarter grade listed separately; do not list a final grade.");
      if (course.terms.some((t) => t.status === "in_progress")) out.push("Enter IP (In Progress) for senior-year courses without a grade.");
      if (course.isRepeat) out.push("Tick Repeated Course.");
      return out;
    }
  };

  // ../web/lib/transcript-maps/ut.ts
  var FAQ = "https://admissions.utexas.edu/apply/frequently-asked-questions/";
  var UT_SUBJECTS = ["English", "Mathematics", "Science", "Social Studies", "Language Other Than English", "Other"];
  var UT_MAP = {
    id: "ut",
    label: "UT Austin",
    level: table(LEVELS, {}, unverified(null, "UT's form levels are behind a login", FAQ)),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", FAQ),
        mathematics: verified("Mathematics", FAQ),
        science: verified("Science", FAQ),
        history_social: verified("Social Studies", FAQ),
        world_language: verified("Language Other Than English", FAQ)
      },
      verified("Other", FAQ, "Other coursework is optional")
    ),
    subjectList: { options: UT_SUBJECTS, verified: true, note: 'Five principal areas; "Other" coursework is optional.' },
    subSubject: () => none("UT's form has no documented sub-category"),
    period: table(PERIOD_TYPES, {}, unverified(null, "UT's term options are behind a login", FAQ)),
    rules: (_school, course) => {
      const out = [];
      if (course.terms.some((t) => t.status === "in_progress" || t.status === "planned")) out.push("UT's form takes completed courses only; leave in-progress and planned courses out.");
      if (course.isSummer) out.push("Enter summer courses under the grade level before or after.");
      if (course.credit == null) out.push("If the transcript shows no credit, UT counts a year-long course as 1 credit and a semester course as 0.5.");
      return out;
    }
  };

  // ../web/lib/transcript-maps.ts
  var SYSTEMS = {
    common_app: COMMON_APP_MAP,
    stars: STARS_MAP,
    csu: CSU_MAP,
    uc: UC_MAP,
    uiuc: UIUC_MAP,
    ut: UT_MAP
  };
  var SYSTEM_IDS = Object.keys(SYSTEMS);

  // ../web/lib/commonapp-fill.ts
  var NO_GRADE = "No Grade";
  function matchOption(options, wanted) {
    const w = normalizeName(wanted);
    return options.find((o) => normalizeName(o) === w) ?? null;
  }
  function matchStem(options, stem) {
    return options.find((o) => o.trim().toLowerCase().startsWith(stem)) ?? null;
  }
  function rowsToAdd(rows, existingNames) {
    const left = /* @__PURE__ */ new Map();
    for (const n of existingNames) left.set(normalizeName(n), (left.get(normalizeName(n)) ?? 0) + 1);
    return rows.filter((r) => {
      const key = normalizeName(r.name);
      const n = left.get(key) ?? 0;
      if (n > 0) left.set(key, n - 1);
      return n === 0;
    });
  }

  // src/commonapp/dom.ts
  var PageChanged = class extends Error {
    constructor(detail) {
      super(detail);
      this.name = "PageChanged";
    }
  };
  var StopRequested = class extends Error {
    constructor() {
      super("stopped");
      this.name = "StopRequested";
    }
  };
  var TIMING = { stepMs: 120, panelMs: 4e3, valueMs: 4e3, pageMs: 2e4, saveMs: 2e4 };
  var stopFlag = false;
  function requestStop() {
    stopFlag = true;
  }
  function resetStop() {
    stopFlag = false;
  }
  function checkStop() {
    if (stopFlag) throw new StopRequested();
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function waitFor(probe, opts = {}) {
    const timeoutMs = opts.timeoutMs ?? TIMING.valueMs;
    const intervalMs = opts.intervalMs ?? TIMING.stepMs;
    const start = Date.now();
    for (; ; ) {
      const v = probe();
      if (v !== null && v !== void 0 && v !== false) return v;
      if (Date.now() - start >= timeoutMs) throw new Error("timeout");
      await sleep(intervalMs);
    }
  }
  async function need(probe, what, timeoutMs) {
    try {
      return await waitFor(probe, { timeoutMs });
    } catch {
      throw new PageChanged(what);
    }
  }
  function cgFieldId(field, t, c) {
    const tc = `T${t}C${c}`;
    if (field === "creditNA") return `creditNA_${tc}-input`;
    if (field === "credit") return `creditFinalControl_${tc}`;
    if (field === "gradefinal") return `gradeFinalControl_${tc}`;
    return `${field}Control_${tc}`;
  }
  function cgCreditId(col, t, c) {
    return col === "final" ? `creditFinalControl_T${t}C${c}` : `credit${col}Control_T${t}C${c}`;
  }
  var text = (el) => (el?.textContent ?? "").trim();
  var CLEAR_SELECTION = "Clear selection";
  var CLEAR = CLEAR_SELECTION;
  function eventOf(el, kind, type, init) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = view[kind] ?? view.Event ?? Event;
    return new Ctor(type, init);
  }
  function click(el) {
    el.click();
  }
  function isChecked(input) {
    const c = input.checked;
    return typeof c === "boolean" ? c : input.hasAttribute("checked");
  }
  function isReadOnly(input) {
    const r = input.readOnly;
    return typeof r === "boolean" ? r : input.hasAttribute("readonly");
  }
  function isShown(el) {
    if (typeof el.getBoundingClientRect !== "function") return true;
    return el.getBoundingClientRect().height > 0;
  }
  function setText(input, value) {
    input.focus?.();
    input.value = value;
    input.dispatchEvent(eventOf(input, "Event", "input", { bubbles: true }));
    input.dispatchEvent(eventOf(input, "Event", "change", { bubbles: true }));
    input.dispatchEvent(eventOf(input, "Event", "blur", { bubbles: false }));
  }
  function pressEscape(el) {
    el.dispatchEvent(eventOf(el, "KeyboardEvent", "keydown", { bubbles: true, cancelable: true, key: "Escape", code: "Escape", keyCode: 27, which: 27 }));
  }
  function matShownText(select) {
    return text(select.querySelector(".mat-mdc-select-value-text"));
  }
  var describe = (el) => el.getAttribute("aria-label") || el.id || el.tagName.toLowerCase();
  function matPanel(select) {
    const doc = select.ownerDocument;
    const byId = select.id ? doc.getElementById(`${select.id}-panel`) : null;
    if (byId) return byId;
    const controls = select.getAttribute("aria-controls");
    return controls ? doc.getElementById(controls) : null;
  }
  var optionText = (o) => text(o.querySelector(".mdc-list-item__primary-text") ?? o);
  async function openMatPanel(select) {
    const open = matPanel(select);
    if (open) return open;
    click(select.querySelector(".mat-mdc-select-trigger") ?? select);
    return need(() => matPanel(select), `the list for "${describe(select)}" did not open`, TIMING.panelMs);
  }
  async function closeMatPanel(select, panel) {
    const options = [...panel.querySelectorAll("mat-option")];
    const chosen = options.find((o) => o.getAttribute("aria-selected") === "true");
    const clear = options.find((o) => optionText(o) === CLEAR);
    if (chosen) click(chosen);
    else if (clear && !matShownText(select)) click(clear);
    else if (matPanel(select)) pressEscape(select);
    await need(() => !matPanel(select), `the list for "${describe(select)}" did not close`, TIMING.panelMs);
  }
  var sameText = (a, b) => matchOption([a], b) !== null;
  async function chooseMatOption(select, choose) {
    checkStop();
    const panel = await openMatPanel(select);
    const options = [...panel.querySelectorAll("mat-option")];
    const wanted = choose(options.map(optionText));
    const opt = wanted == null ? void 0 : options.find((o) => optionText(o) === wanted);
    if (!opt) {
      await closeMatPanel(select, panel);
      return null;
    }
    click(opt);
    const expect = wanted === CLEAR ? "" : wanted;
    await need(() => !matPanel(select) && (expect ? sameText(matShownText(select), expect) : !matShownText(select)), `"${describe(select)}" does not show "${expect}" after picking it`, TIMING.valueMs);
    return expect;
  }
  function selectMatOption(el, wanted) {
    return chooseMatOption(el, (opts) => matchOption(opts.filter((o) => o !== CLEAR), wanted));
  }
  async function clearMatSelect(el) {
    if (!matShownText(el)) return;
    const r = await chooseMatOption(el, (opts) => opts.includes(CLEAR) ? CLEAR : null);
    if (r === null) throw new PageChanged(`"${describe(el)}" has no "${CLEAR}" option`);
  }
  function cgDialog(doc) {
    return doc.getElementById("changePreferencesTitle")?.closest("mat-dialog-container") ?? null;
  }
  function ngOf(input) {
    const ng = input.closest("ng-select");
    if (!ng) throw new PageChanged(`"${input.id}" is not an ng-select`);
    return ng;
  }
  function ngPanel(input) {
    return ngOf(input).querySelector("ng-dropdown-panel");
  }
  var ngOptionEls = (panel) => [...panel.querySelectorAll(".ng-option")].filter((o) => !o.classList.contains("ng-option-disabled"));
  var ngOptionText = (o) => text(o.querySelector(".ng-option-label") ?? o);
  function ngValues(input) {
    const ng = ngOf(input);
    if (ng.classList.contains("ng-select-multiple")) return [...ng.querySelectorAll(".ng-value .ng-value-label")].map(text).filter(Boolean);
    const chip = text(ng.querySelector(".ng-value .ng-value-label"));
    const v = chip || (input.value ?? "").trim();
    return v ? [v] : [];
  }
  async function openNg(input) {
    const open = ngPanel(input);
    if (open) return open;
    const container = ngOf(input).querySelector(".ng-select-container") ?? input;
    container.dispatchEvent(eventOf(container, "MouseEvent", "mousedown", { bubbles: true, cancelable: true, button: 0 }));
    return need(() => ngPanel(input), `the list for "${input.id}" did not open`, TIMING.panelMs);
  }
  async function closeNg(input) {
    if (!ngPanel(input)) return;
    pressEscape(input);
    try {
      await waitFor(() => !ngPanel(input), { timeoutMs: TIMING.panelMs });
    } catch {
      input.blur?.();
    }
  }
  async function selectNgOption(input, wanted) {
    checkStop();
    const panel = await openNg(input);
    const els = ngOptionEls(panel);
    const pick = matchOption(els.map(ngOptionText), wanted);
    const el = pick == null ? void 0 : els.find((o) => ngOptionText(o) === pick);
    if (!el) {
      await closeNg(input);
      return null;
    }
    if (!ngValues(input).some((v) => sameText(v, pick))) click(el);
    await need(() => ngValues(input).some((v) => sameText(v, pick)), `"${input.id}" does not show "${pick}" after picking it`, TIMING.valueMs);
    await closeNg(input);
    return pick;
  }
  async function clearNg(input, keep = null) {
    checkStop();
    const ng = ngOf(input);
    if (ng.classList.contains("ng-select-multiple")) {
      for (const chip of [...ng.querySelectorAll(".ng-value")]) {
        const label = text(chip.querySelector(".ng-value-label"));
        if (keep != null && sameText(label, keep)) continue;
        const x = chip.querySelector(".ng-value-icon");
        if (!x) throw new PageChanged(`"${input.id}" has no remove button on "${label}"`);
        click(x);
      }
      await need(() => ngValues(input).every((v) => keep != null && sameText(v, keep)), `"${input.id}" kept old schedule values`, TIMING.valueMs);
      return;
    }
    if (!ngValues(input).length) return;
    const clear = ng.querySelector(".ng-clear, .ng-clear-wrapper");
    if (!clear) throw new PageChanged(`"${input.id}" has no clear button`);
    click(clear);
    await need(() => !ngValues(input).length, `"${input.id}" did not clear`, TIMING.valueMs);
  }

  // src/commonapp/pages.ts
  var CG_GRADE_PATH = {
    "9": "/common/13/55",
    "10": "/common/13/56",
    "11": "/common/13/57",
    "12": "/common/13/58",
    other: "/common/13/59"
  };
  var CG_INTRO_PATH = "/common/13/54";
  var CG_NOT_REQUIRED_PATH = "/common/13/not-required";
  var CURRENT_YEAR_PATH = "/common/4/24";
  var GRADE_LABEL = { "9": "9th grade", "10": "10th grade", "11": "11th grade", "12": "12th grade", other: "Other Courses" };
  var CG_YES_NO_QUESTION = { "12": 1927, other: 1933 };
  function currentPath() {
    const p = globalThis.location?.pathname ?? "";
    return p.length > 1 ? p.replace(/\/+$/, "") : p;
  }

  // src/commonapp/cg.ts
  var COLUMNS = ["1", "2", "3", "4", "final"];
  var NOT_SAVED = "Nothing is saved for this grade yet: press X on the dialog to keep what was filled, or reload the page to discard it.";
  var LEFT_OPEN = "Nothing was filled for this grade; the dialog was left open (reload the page to close it without saving).";
  var Unreachable = class extends Error {
  };
  function unreachableReason(path) {
    if (path === CG_NOT_REQUIRED_PATH) return "Add your school in Education first";
    if (path === CG_INTRO_PATH) return "Answer Yes on the Courses & Grades intro first";
    return null;
  }
  var rowEl = (doc, n) => doc.getElementById(cgFieldId("courseName", 1, n))?.closest("ca-cng-course") ?? null;
  function cgRows(doc) {
    const root = cgDialog(doc) ?? doc;
    const empty = (i) => !(i.value ?? "").trim();
    return [...root.querySelectorAll('input[id^="courseNameControl_T1C"]')].map((input) => {
      const n = Number(input.id.slice("courseNameControl_T1C".length));
      const name = (input.value ?? "").trim();
      const row = input.closest("ca-cng-course");
      const all = (sel) => [...row?.querySelectorAll(sel) ?? []];
      const selectsEmpty = all("mat-select").every((s) => !matShownText(s));
      const textGradesEmpty = all('input[id^="gradeControl_"]').every(empty);
      const creditsEmpty = all('input[id^="credit"][id*="Control_T1C"]').every(empty);
      const na = doc.getElementById(cgFieldId("creditNA", 1, n));
      const naOff = !na || !isChecked(na);
      return { n, name, blank: !name && selectsEmpty && textGradesEmpty && creditsEmpty && naOff };
    });
  }
  function termOfLabel(aria) {
    const rest = aria.replace(/^.*Course \d+,\s*/i, "");
    if (/^final/i.test(rest)) return "final";
    const m = /^(?:semester|trimester|quarter|term)\s*([1-4])/i.exec(rest);
    return m ? m[1] : null;
  }
  function otherGradeBox(doc, n, col) {
    const row = rowEl(doc, n);
    if (!row) return null;
    const hits = [...row.querySelectorAll(`input[id="gradeControl_T1C${n}"]`)].filter((i) => termOfLabel(i.getAttribute("aria-label") ?? "") === col);
    return hits.length === 1 ? hits[0] : null;
  }
  function cgGradeBox(doc, scale, n, col) {
    return scale === "Other" ? otherGradeBox(doc, n, col) : doc.getElementById(cgFieldId(`grade${col}`, 1, n));
  }
  function headerMismatch(doc, plan) {
    const checks = [
      ["schoolNameControl1", "School Name", plan.schoolName, (s) => sameText(s, plan.schoolName)],
      ["schoolYearControl1", "School Year", plan.schoolYear, (s) => sameText(s, plan.schoolYear)],
      ["gradingScaleControl1", "Grading Scale", plan.scale, (s) => sameText(s, plan.scale)],
      ["scheduleControl1", "Schedule", plan.scheduleStem, (s) => matchStem([s], plan.scheduleStem) !== null]
    ];
    for (const [id, label, want, ok] of checks) {
      const el = doc.getElementById(id);
      const shown = el ? matShownText(el) : "";
      if (shown && !ok(shown))
        return `Common App already has ${label} '${shown}' for this grade and the tracker has '${want}'. Changing it would change the courses already there, so nothing was added: choose Replace, or change it on Common App yourself.`;
    }
    return null;
  }
  async function reachGradePage(doc, grade) {
    const want = CG_GRADE_PATH[grade];
    let path = "";
    try {
      await waitFor(() => {
        path = currentPath();
        if (unreachableReason(path)) return true;
        return path === want && (cgDialog(doc) || doc.getElementById("addCG")) ? true : null;
      }, { timeoutMs: TIMING.pageMs });
    } catch {
      if (path === want) throw new PageChanged(`no "Add/Edit ${GRADE_LABEL[grade]}" button`);
      throw new Unreachable(`Not on the ${GRADE_LABEL[grade]} page (Common App shows ${path || "another page"})`);
    }
    const why = unreachableReason(path);
    if (why) throw new Unreachable(why);
  }
  var labelOf = (doc, input) => (doc.querySelector(`label[for="${input.id}"]`)?.textContent ?? "").trim().toLowerCase();
  var changedToYesNote = (grade) => `Changed your answer to 'courses to report' to Yes for ${GRADE_LABEL[grade]}.`;
  async function answerYesIfAsked(doc, grade, notes) {
    const q = CG_YES_NO_QUESTION[grade];
    if (q == null || cgDialog(doc)) return;
    const addShown = () => {
      const b = doc.getElementById("addCG");
      return b && isShown(b) ? b : null;
    };
    const asked = doc.querySelector(`[id^="option_ques_${q}_"], #title_ques_${q}, #clear_ques_${q}, #radioGroup${q}`);
    if (!asked) {
      if (addShown()) return;
      throw new PageChanged(`no Yes/No question before the "Add ${GRADE_LABEL[grade]}" button`);
    }
    const radios = [...doc.querySelectorAll(`input[type="radio"][id^="option_ques_${q}_"]`)];
    const yes = radios.filter((r) => labelOf(doc, r) === "yes");
    if (yes.length !== 1) throw new PageChanged(`the 'courses to report?' question has ${yes.length ? "more than one" : "no"} Yes answer`);
    if (!isChecked(yes[0])) {
      const wasNo = radios.some((r) => labelOf(doc, r) === "no" && isChecked(r));
      click(yes[0]);
      if (wasNo) notes.push(changedToYesNote(grade));
    }
    await need(() => isChecked(yes[0]) && addShown(), `the "Add ${GRADE_LABEL[grade]}" button did not appear after answering Yes`);
  }
  async function openDialog(doc, grade) {
    if (cgDialog(doc)) return;
    const btn = await need(() => {
      const b = doc.getElementById("addCG");
      return b && isShown(b) ? b : null;
    }, `no "Add/Edit ${GRADE_LABEL[grade]}" button`);
    click(btn);
    await need(() => cgDialog(doc) && doc.getElementById(cgFieldId("courseName", 1, 1)), "the Courses & Grades dialog did not open", TIMING.pageMs);
  }
  function dialogButton(doc, test) {
    const dialog = cgDialog(doc);
    if (!dialog) return null;
    return [...dialog.querySelectorAll("button")].find((b) => test.test((b.textContent ?? "").trim())) ?? null;
  }
  async function addRow(doc) {
    checkStop();
    const n = cgRows(doc).length + 1;
    const btn = dialogButton(doc, /^add another course$/i);
    if (!btn) throw new PageChanged('no "Add another course" button');
    click(btn);
    await need(() => doc.getElementById(cgFieldId("courseName", 1, n)), `"Add another course" did not add course ${n}`);
    return n;
  }
  async function removeRow(doc, n) {
    checkStop();
    const before = cgRows(doc).length;
    const btn = rowEl(doc, n)?.querySelector(`button[aria-label^="Remove transcript 1, course ${n} of "]`);
    if (!btn) throw new PageChanged(`no Remove button on course ${n}`);
    click(btn);
    const confirm = await need(() => doc.getElementById("alert_rc_r"), "the Remove confirmation did not open");
    click(confirm);
    await need(() => !doc.getElementById("alert_rc_r") && cgRows(doc).length === before - 1, `course ${n} was not removed`);
  }
  var header = (doc, id, label) => need(() => doc.getElementById(id), `no ${label} select`);
  function schoolMissingText(name, options) {
    const shown = options.slice(0, 5).map((o) => `'${o}'`);
    if (options.length > 5) shown.push(`and ${options.length - 5} more`);
    const list = shown.length ? shown.join(", ") : "no schools";
    return `Your tracker school '${name}' doesn't match any school in Common App's list (${list}). Rename it in the tracker to match exactly, or add it in Common App's Education section.`;
  }
  async function setSchoolAndYear(doc, plan, blank) {
    const school = await header(doc, "schoolNameControl1", "School Name");
    if (!sameText(matShownText(school), plan.schoolName)) {
      let options = [];
      const picked = await chooseMatOption(school, (opts) => {
        options = opts.filter((o) => o !== CLEAR_SELECTION);
        return matchOption(options, plan.schoolName);
      });
      if (picked === null) {
        blank("", "school", `${schoolMissingText(plan.schoolName, options)} ${LEFT_OPEN}`);
        return false;
      }
    }
    const year = await header(doc, "schoolYearControl1", "School Year");
    if (!sameText(matShownText(year), plan.schoolYear) && await selectMatOption(year, plan.schoolYear) === null) {
      blank("", "school year", `School year '${plan.schoolYear}' is not in Common App's School Year list. ${LEFT_OPEN}`);
      return false;
    }
    return true;
  }
  async function setScaleAndSchedule(doc, plan) {
    const scale = await header(doc, "gradingScaleControl1", "Grading Scale");
    if (!sameText(matShownText(scale), plan.scale) && await selectMatOption(scale, plan.scale) === null) throw new PageChanged(`Grading Scale has no "${plan.scale}"`);
    const schedule = await header(doc, "scheduleControl1", "Schedule");
    if (matchStem([matShownText(schedule)], plan.scheduleStem) === null) {
      const got = await chooseMatOption(schedule, (opts) => matchStem(opts.filter((o) => o !== CLEAR_SELECTION), plan.scheduleStem));
      if (got === null) throw new PageChanged(`Schedule has no option for "${plan.scheduleStem}"`);
    }
    await need(() => cgGradeBox(doc, plan.scale, 1, "final"), "the Final grade column of course 1");
  }
  var maxLen = (el) => {
    const m = Number(el.getAttribute("maxlength"));
    return Number.isFinite(m) && m > 0 ? m : Infinity;
  };
  var colName = (col) => col === "final" ? "Final" : `term ${col}`;
  async function clearBox(box) {
    if (box.tagName === "INPUT") {
      if ((box.value ?? "") && !isReadOnly(box)) setText(box, "");
    } else await clearMatSelect(box);
  }
  async function fillRow(doc, plan, row, n, overwrite, blank) {
    const get = (id, what) => need(() => doc.getElementById(id), `no ${what} box on course ${n}`);
    const typeExact = (el, value, field) => {
      if (value.length > maxLen(el)) blank(row.name, field, `'${value}' is longer than the ${maxLen(el)} characters Common App allows`);
      else setText(el, value);
    };
    const pick = async (el, value, field) => {
      if (value == null) {
        if (overwrite) await clearMatSelect(el);
        return;
      }
      if (sameText(matShownText(el), value)) return;
      if (await selectMatOption(el, value) === null) {
        blank(row.name, field, `'${value}' is not in Common App's list`);
        if (overwrite) await clearMatSelect(el);
      }
    };
    await pick(await get(cgFieldId("subject", 1, n), "Subject"), row.subject, "subject");
    checkStop();
    const name = await get(cgFieldId("courseName", 1, n), "Course Name");
    if (row.name.length > maxLen(name)) {
      blank(row.name, "name", `the name is longer than the ${maxLen(name)} characters Common App allows`);
      if (overwrite) setText(name, "");
    } else setText(name, row.name);
    await pick(await get(cgFieldId("level", 1, n), "Course Level"), row.level, "level");
    const failed = /* @__PURE__ */ new Set();
    for (const col of COLUMNS) {
      checkStop();
      const want = row.grades[col];
      const box = cgGradeBox(doc, plan.scale, n, col);
      const field = `${colName(col)} grade`;
      if (want == null) {
        if (overwrite && box) await clearBox(box);
        continue;
      }
      failed.add(col);
      if (!box) {
        blank(row.name, field, plan.scale === "Other" ? `no single ${colName(col)} grade box on Common App for this course` : `Common App's ${plan.scheduleStem} schedule has no ${colName(col)} column`);
        continue;
      }
      if (box.tagName === "INPUT") {
        if (want === NO_GRADE) {
          blank(row.name, field, `scale Other has no '${NO_GRADE}' option: enter what your transcript shows for this term`);
          continue;
        }
        if (want.length > maxLen(box)) {
          typeExact(box, want, field);
          continue;
        }
        setText(box, want);
      } else if (await selectMatOption(box, want) === null) {
        blank(row.name, field, `'${want}' is not in Common App's list`);
        if (overwrite) await clearMatSelect(box);
        continue;
      }
      failed.delete(col);
    }
    checkStop();
    const na = await get(cgFieldId("creditNA", 1, n), "Credits N/A");
    const setNA = async (on) => {
      if (isChecked(na) === on) return;
      click(na);
      await need(() => isChecked(na) === on, `Credits N/A did not ${on ? "tick" : "untick"} on course ${n}`);
    };
    if (overwrite) {
      await setNA(false);
      for (const col of COLUMNS) {
        const c = doc.getElementById(cgCreditId(col, 1, n));
        if (c) await clearBox(c);
      }
    }
    if (row.creditNA) await setNA(true);
    else {
      await setNA(false);
      for (const col of COLUMNS) {
        checkStop();
        const want = row.credits[col];
        if (want == null || col !== "final" && failed.has(col)) continue;
        const field = col === "final" ? "credit" : `${colName(col)} credit`;
        const box = doc.getElementById(cgCreditId(col, 1, n));
        if (!box) blank(row.name, field, `Common App's ${plan.scheduleStem} schedule has no ${colName(col)} credit box`);
        else typeExact(box, want, field);
      }
    }
  }
  function stopText(e, dialogOpen) {
    const tail = dialogOpen ? ` ${NOT_SAVED}` : "";
    if (e instanceof Unreachable) return e.message;
    if (e instanceof StopRequested) return `Stopped.${tail}`;
    const detail = e instanceof Error ? e.message : String(e);
    return `Common App's page changed (${detail}).${tail}`;
  }
  async function inspectCgGrade(grade, doc = document) {
    try {
      await reachGradePage(doc, grade);
      if (!cgDialog(doc)) {
        const btn = doc.getElementById("addCG");
        if (!btn || !isShown(btn) || !/^\s*edit\b/i.test(btn.textContent ?? "")) return { existing: [] };
        await openDialog(doc, grade);
      }
      return { existing: cgRows(doc).filter((r) => !r.blank).map((r) => r.name) };
    } catch (e) {
      throw new Error(stopText(e, false));
    }
  }
  async function fillCgGrade(plan, mode, doc = document) {
    resetStop();
    const blanks = [...plan.skipped];
    const blank = (course, field, reason) => blanks.push({ where: plan.grade, course, field, reason });
    const notes = [];
    let filled = 0;
    const result = (stoppedReason) => ({ filled, blanks, ...notes.length ? { notes } : {}, ...stoppedReason ? { stoppedReason } : {} });
    if (!plan.rows.length) return result();
    try {
      await reachGradePage(doc, plan.grade);
      await answerYesIfAsked(doc, plan.grade, notes);
      await openDialog(doc, plan.grade);
      const existing = cgRows(doc).filter((r) => !r.blank);
      if (mode === "keep" && existing.length) {
        const why = headerMismatch(doc, plan);
        if (why) {
          blank("", "grade", `${why} ${LEFT_OPEN}`);
          return result();
        }
      }
      if (!await setSchoolAndYear(doc, plan, blank)) return result();
      if (mode === "replace") for (const r of cgRows(doc).filter((x) => x.n > 1).sort((a, b) => b.n - a.n)) await removeRow(doc, r.n);
      await setScaleAndSchedule(doc, plan);
      const toFill = mode === "keep" ? rowsToAdd(plan.rows, existing.map((r) => r.name)) : plan.rows;
      const slots = mode === "keep" ? cgRows(doc).filter((r) => r.blank).map((r) => r.n) : [1];
      for (const row of toFill) {
        checkStop();
        const n = slots.shift() ?? await addRow(doc);
        await fillRow(doc, plan, row, n, mode === "replace" && n === 1, blank);
        filled++;
      }
      for (const n of slots.filter((x) => x > 1).sort((a, b) => b - a)) await removeRow(doc, n);
      checkStop();
      const cont = dialogButton(doc, /^continue\b/i);
      if (!cont) throw new PageChanged("no Continue button in the dialog");
      click(cont);
      try {
        await waitFor(() => !cgDialog(doc), { timeoutMs: TIMING.saveMs });
      } catch {
        return result("Common App did not close the dialog after Continue: read its messages, then press Continue yourself.");
      }
      return result();
    } catch (e) {
      return result(stopText(e, !!cgDialog(doc)));
    }
  }

  // src/commonapp/current-year.ts
  var MAX_COURSES = 15;
  var norm = (s) => (s ?? "").trim().replace(/\s+/g, " ").toLowerCase();
  function cyField(doc, n, kind) {
    const want = `course ${n} ${kind}`;
    const label = [...doc.querySelectorAll("label[for]")].find((l) => norm(l.textContent) === want);
    return label ? doc.getElementById(label.getAttribute("for")) : null;
  }
  function cyCountInput(doc) {
    const label = [...doc.querySelectorAll("label[for]")].find((l) => norm(l.textContent).includes("how many courses"));
    return label ? doc.getElementById(label.getAttribute("for")) : null;
  }
  function cyRadios(doc) {
    const group = [...doc.querySelectorAll("mat-radio-group")].find((g) => {
      const by = g.getAttribute("aria-labelledby");
      return by != null && norm(doc.getElementById(by)?.textContent).includes("scheduling system");
    });
    if (!group) return [];
    return [...group.querySelectorAll('input[type="radio"]')].map((input) => ({
      input,
      label: (doc.querySelector(`label[for="${input.id}"]`)?.textContent ?? "").trim(),
      checked: isChecked(input)
    }));
  }
  function readCurrentYear(doc) {
    const countInput = cyCountInput(doc);
    const count = countInput ? Number.parseInt(ngValues(countInput)[0] ?? "", 10) || 0 : 0;
    const courses = [];
    for (let n = 1; n <= count; n++) {
      const name = (cyField(doc, n, "name")?.value ?? "").trim();
      const has = (k) => {
        const el = cyField(doc, n, k);
        return el ? ngValues(el).length > 0 : false;
      };
      courses.push({ n, name, blank: !name && !has("subject") && !has("level") && !has("schedule") });
    }
    return { count, courses };
  }
  var Unreachable2 = class extends Error {
  };
  async function reachPage(doc) {
    let path = "";
    try {
      await waitFor(() => {
        path = currentPath();
        return path === CURRENT_YEAR_PATH && cyCountInput(doc) ? true : null;
      }, { timeoutMs: TIMING.pageMs });
    } catch {
      if (path === CURRENT_YEAR_PATH) throw new PageChanged('no "How many courses would you like to report?" question');
      throw new Unreachable2(`Not on the Current or Most Recent Year Courses page (Common App shows ${path || "another page"})`);
    }
  }
  async function fillCourse(doc, row, n, overwrite, blank) {
    const field = (k) => need(() => cyField(doc, n, k), `no "Course ${n} ${k}" field`);
    const pickSingle = async (el, value, k) => {
      if (value == null) {
        if (overwrite) await clearNg(el);
        return;
      }
      if (ngValues(el).some((v) => sameText(v, value))) return;
      if (await selectNgOption(el, value) === null) {
        blank(row.name, k, `'${value}' is not in Common App's list`);
        if (overwrite) await clearNg(el);
      }
    };
    await pickSingle(await field("subject"), row.subject, "subject");
    checkStop();
    const name = await field("name");
    const max = Number(name.getAttribute("maxlength")) || Infinity;
    if (row.name.length > max) {
      blank(row.name, "name", `the name is longer than the ${max} characters Common App allows`);
      if (overwrite) setText(name, "");
    } else setText(name, row.name);
    await pickSingle(await field("level"), row.level, "level");
    const schedule = await field("schedule");
    if (overwrite) await clearNg(schedule, row.schedule);
    if (row.schedule != null && !ngValues(schedule).some((v) => sameText(v, row.schedule)) && await selectNgOption(schedule, row.schedule) === null)
      blank(row.name, "schedule", `'${row.schedule}' is not in Common App's list`);
  }
  async function inspectCurrentYear(doc = document) {
    try {
      await reachPage(doc);
    } catch (e) {
      throw new Error(e instanceof Unreachable2 ? e.message : `Common App's page changed (${e.message}).`);
    }
    return { existing: readCurrentYear(doc).courses.filter((c) => !c.blank).map((c) => c.name) };
  }
  async function fillCurrentYear(plan, mode, doc = document) {
    resetStop();
    const blanks = [...plan.skipped];
    const blank = (course, field, reason) => blanks.push({ where: "current", course, field, reason });
    let filled = 0;
    let changed = false;
    if (!plan.rows.length) return { filled, blanks };
    try {
      await reachPage(doc);
      const state = readCurrentYear(doc);
      const existing = state.courses.filter((c) => !c.blank);
      const toFill = mode === "keep" ? rowsToAdd(plan.rows, existing.map((c) => c.name)) : plan.rows;
      const slots = mode === "keep" ? state.courses.filter((c) => c.blank).map((c) => c.n) : [];
      let next = mode === "keep" ? state.count + 1 : 1;
      const assigned = [];
      for (const row of toFill) {
        const n = slots.shift() ?? next++;
        if (n > MAX_COURSES) blank(row.name, "course", `Common App takes at most ${MAX_COURSES} courses here`);
        else assigned.push({ row, n });
      }
      if (!assigned.length) return { filled, blanks };
      const count = mode === "keep" ? Math.max(state.count, ...assigned.map((a) => a.n)) : assigned.length;
      const countInput = cyCountInput(doc);
      if (state.count !== count) {
        changed = true;
        if (await selectNgOption(countInput, String(count)) === null) throw new PageChanged(`the course count has no "${count}"`);
      }
      await need(() => cyField(doc, count, "subject"), `course ${count}'s fields did not appear`);
      const radios = cyRadios(doc);
      const target = radios.find((r) => matchStem([r.label], plan.scheduleStem) !== null);
      if (!target) throw new PageChanged(`no "${plan.scheduleStem}" course scheduling system`);
      const current = radios.find((r) => r.checked);
      if (current?.input !== target.input) {
        if (mode === "keep" && existing.length && current)
          blank("", "scheduling system", `Common App already has '${current.label}' and the tracker has '${target.label}'. Kept, because changing it clears every course's schedule; schedules that do not fit are left blank.`);
        else {
          changed = true;
          click(target.input);
          await need(() => isChecked(target.input), "the course scheduling system did not change");
        }
      }
      for (const { row, n } of assigned) {
        checkStop();
        changed = true;
        await fillCourse(doc, row, n, mode === "replace", blank);
        filled++;
      }
      checkStop();
      const cont = doc.getElementById("sectionContinue24") ?? [...doc.querySelectorAll("main button")].find((b) => /^continue\b/i.test((b.textContent ?? "").trim())) ?? null;
      if (!cont) throw new PageChanged("no Continue button");
      click(cont);
      try {
        await waitFor(() => currentPath() !== CURRENT_YEAR_PATH, { timeoutMs: TIMING.saveMs });
      } catch {
        return { filled, blanks, stoppedReason: "Common App did not move on after Continue (a required box may be empty). Nothing on this page is saved yet: fill the blanks listed here and press Continue yourself." };
      }
      return { filled, blanks };
    } catch (e) {
      const tail = changed ? " Nothing on this page is saved yet: press Continue yourself to keep what was filled, or reload the page to discard it." : "";
      if (e instanceof Unreachable2) return { filled, blanks, stoppedReason: e.message };
      if (e instanceof StopRequested) return { filled, blanks, stoppedReason: `Stopped.${tail}` };
      return { filled, blanks, stoppedReason: `Common App's page changed (${e instanceof Error ? e.message : String(e)}).${tail}` };
    }
  }

  // src/content.ts
  var busy = false;
  async function handle(msg) {
    if (msg.type === "inspect") {
      const { existing } = msg.target === "current" ? await inspectCurrentYear() : await inspectCgGrade(msg.target);
      return { type: "inspect", ok: true, existing };
    }
    const result = msg.target === "current" ? await fillCurrentYear(msg.plan, msg.mode) : await fillCgGrade(msg.plan, msg.mode);
    return { type: "fill", ok: true, result };
  }
  chrome.runtime.onMessage.addListener((raw, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id) return false;
    const msg = raw;
    switch (msg?.type) {
      case "ready":
        sendResponse({ type: "ready", path: currentPath() });
        return false;
      case "stop":
        requestStop();
        sendResponse({ type: "stop" });
        return false;
      case "inspect":
      case "fill": {
        const type = msg.type;
        if (busy) {
          sendResponse({ type, ok: false, error: "Already filling this page" });
          return false;
        }
        busy = true;
        handle(msg).then(sendResponse, (e) => sendResponse({ type, ok: false, error: e instanceof Error ? e.message : String(e) })).finally(() => busy = false);
        return true;
      }
      default:
        return false;
    }
  });
})();
