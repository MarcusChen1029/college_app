// ../web/lib/student-rows.ts
var PROFILE_BASE = "sat_total, act_composite, gpa_unweighted, is_international, target_regions, reminder_emails, plan, test_details, interested, activities, resume, essays";
var PROFILE_COLUMNS = `${PROFILE_BASE}, portals`;
var toTranscriptSchool = (r) => ({
  id: r.id,
  name: r.name,
  country: r.country ?? "",
  kind: r.kind,
  curriculum: r.curriculum,
  defaultScale: r.default_scale,
  defaultPeriod: r.default_period,
  firstYear: r.first_year,
  lastYear: r.last_year,
  printedGpa: r.printed_gpa ?? "",
  printedGpaScale: r.printed_gpa_scale ?? "",
  gpaWeighted: r.gpa_weighted,
  classRank: r.class_rank ?? "",
  schoolCode: r.school_code ?? "",
  notes: r.notes ?? "",
  createdAt: r.created_at
});
var num = (v) => v == null || v === "" ? null : Number(v);
var toTranscriptCourse = (r) => ({
  id: r.id,
  schoolId: r.school_id,
  academicYear: r.academic_year,
  gradeLevel: r.grade_level,
  name: r.name,
  period: r.period_type,
  terms: Array.isArray(r.terms) ? r.terms : [],
  finalGrade: r.final_grade || null,
  scale: r.grade_scale,
  scaleMax: num(r.scale_max),
  level: r.level,
  credit: num(r.credit),
  creditUnit: r.credit_unit,
  subject: r.subject,
  subSubject: r.sub_subject || null,
  languageName: r.language_name ?? "",
  isSummer: r.is_summer,
  isRepeat: r.is_repeat,
  isCollege: r.is_college,
  collegeName: r.college_name ?? "",
  isWithdrawn: r.is_withdrawn,
  notes: r.notes ?? "",
  source: r.source,
  overrides: r.overrides ?? {},
  sortOrder: r.sort_order,
  createdAt: r.created_at
});

// src/config.ts
var TRACKER_URL = "https://www.track-ur-college.com" ? "https://www.track-ur-college.com" : "http://localhost:3000";
var SUPABASE_URL = "https://eyvmtaggayqizllaseiu.supabase.co";
var SUPABASE_KEY = "sb_publishable_5B39sQnRwgy3LaFOZrDFZg_eeCoJaoS";

// src/auth.ts
var TOKEN_KEY = "token";
function parseTokenFromRedirect(url) {
  const hash = url.indexOf("#");
  if (hash < 0) return null;
  const params = new URLSearchParams(url.slice(hash + 1));
  if (params.has("error")) return null;
  return params.get("token") || null;
}
function parseTranscriptResponse(body) {
  const network = { ok: false, reason: "network" };
  if (typeof body !== "object" || body === null) return network;
  const b = body;
  if (b.ok === false) {
    if (b.error === "invalid_token") return { ok: false, reason: "signed_out" };
    if (b.error === "students_only") return { ok: false, reason: "students_only" };
    return network;
  }
  if (b.ok !== true || !Array.isArray(b.schools) || !Array.isArray(b.courses)) return network;
  try {
    return {
      ok: true,
      schools: b.schools.map(toTranscriptSchool),
      courses: b.courses.map(toTranscriptCourse)
    };
  } catch {
    return network;
  }
}
async function getToken() {
  const stored = await chrome.storage.local.get(TOKEN_KEY);
  const t = stored[TOKEN_KEY];
  return typeof t === "string" && t ? t : null;
}
async function signIn() {
  try {
    const redirect = chrome.identity.getRedirectURL();
    const url = `${TRACKER_URL}/extension/connect?redirect_uri=${encodeURIComponent(redirect)}`;
    const result = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
    const token = result ? parseTokenFromRedirect(result) : null;
    if (!token) return false;
    await chrome.storage.local.set({ [TOKEN_KEY]: token });
    return true;
  } catch {
    return false;
  }
}
async function signOut() {
  await chrome.storage.local.remove(TOKEN_KEY);
}
async function loadTranscript() {
  const token = await getToken();
  if (!token) return { ok: false, reason: "signed_out" };
  let body;
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/extension_transcript`, {
      method: "POST",
      headers: { apikey: SUPABASE_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ p_token: token })
    });
    if (!res.ok) return { ok: false, reason: "network" };
    body = await res.json();
  } catch {
    return { ok: false, reason: "network" };
  }
  const result = parseTranscriptResponse(body);
  if (!result.ok && result.reason === "signed_out") await signOut();
  return result;
}

// src/background.ts
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
});
async function handle(msg) {
  switch (msg.type) {
    case "signIn":
      return { type: "signIn", ok: await signIn() };
    case "signOut":
      await signOut();
      return { type: "signOut" };
    case "loadTranscript":
      return { type: "loadTranscript", result: await loadTranscript() };
  }
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const type = msg?.type;
  if (type !== "signIn" && type !== "signOut" && type !== "loadTranscript") return false;
  handle(msg).then(sendResponse, () => sendResponse(void 0));
  return true;
});
