// ../web/lib/activities.ts
var GRADES = ["9", "10", "11", "12", "PG"];
var HONOR_LEVELS = { school: "School", state_regional: "State/Regional", national: "National", international: "International" };
var UC_LIMITS = { entries: 20, name: 60, otherProgramName: 30, description: 350, extra: 250 };
var UC_CATEGORIES = {
  award: { label: "Award or honor", name: "What's the name of the award or honor?", extra: "What are the eligibility requirements for this award or honor?", description: "What did you do to achieve this award or honor?", hours: false },
  edprep: { label: "Educational preparation program", name: "What was the program name?", description: "Briefly describe the program.", hours: true },
  extracurricular: { label: "Extracurricular activity", name: "What's the name of the activity?", description: "What did you do?", hours: true },
  coursework: { label: "Other coursework", name: "What's the name of the course?", description: "Briefly describe the course.", hours: true },
  volunteer: { label: "Volunteering / community service", name: "What's the name of the organization?", extra: "Please describe the organization, program, school or group.", description: "What did you do?", hours: true },
  work: { label: "Work experience", name: "Where did you work?", jobTitle: "What was your job title?", extra: "Please describe the company or workplace.", description: "What were your job responsibilities?", hours: false }
};
var UC_CATEGORY_KEYS = Object.keys(UC_CATEGORIES);
var UC_AWARD_LEVELS = {
  school: "School",
  city: "City/Community",
  state: "State",
  regional: "Regional",
  national: "National",
  international: "International"
};
var UC_EDPREP_OTHER = "18";
var UC_EDPREP_PROGRAMS = [
  { value: "1", label: "ATDP (Academic Talent Development Program)" },
  { value: "181", label: "boost@BerkeleyHaas" },
  { value: "281", label: "California State Summer School for Mathematics and Science (COSMOS)" },
  { value: "2", label: "Cal-SOAP" },
  { value: "3", label: "CAMP (California Alliance for Minority Participation in Science)" },
  { value: "4", label: "CBOP (Career Based Outreach Program)" },
  { value: "201", label: "College Bound Academy Programs" },
  { value: "202", label: "Council of African American Parents (CAAP)" },
  { value: "63", label: "C-STEM" },
  { value: "6", label: "Early Academic Outreach Program (EAOP)" },
  { value: "7", label: "Educational Guidance Center (EGC)" },
  { value: "8", label: "Educational Talent Search" },
  { value: "10", label: "GEAR UP" },
  { value: "11", label: "MESA (Mathematics, Engineering, Science Achievement) including MESA Schools Programs, SUCCESS Through Collaboration and California Community College Program" },
  { value: "12", label: "PDP (Professional Development Program)" },
  { value: "13", label: "Puente Program" },
  { value: "241", label: "UC Links" },
  { value: "65", label: "UC Merced Transfer Initiative Programs" },
  { value: "64", label: "UC Scholars" },
  { value: "203", label: "UCD Sacramento Area Youth Speaks (SAYS)" },
  { value: "161", label: "UCLA Center for Community College Partnerships (CCCP)/SITE" },
  { value: "62", label: "UCLA VIP Scholars Program" },
  { value: "15", label: 'UCSC SAGE (Students Acquiring "A-G" Expectations)' },
  { value: "9", label: "UCSF Internships" },
  { value: "16", label: "Upward Bound" },
  { value: "261", label: "Wonderful Education" },
  { value: UC_EDPREP_OTHER, label: "Other" }
];
function ucTextLength(s) {
  return s.length + (s.match(/\n/g)?.length ?? 0);
}
var OLD_CA_TYPES = /* @__PURE__ */ new Map([
  ["Academic", "Academic"],
  ["Art", "Art"],
  ["Athletics: Club", "Athletics (other)"],
  ["Athletics: JV/Varsity", "Athletics (JV or varsity)"],
  ["Career Oriented", "Career readiness or practicums"],
  ["Community Service (Volunteer)", "Community service or volunteer work"],
  ["Computer/Technology", "Computer or technology"],
  ["Cultural", "Cultural"],
  ["Dance", "Dance"],
  ["Debate/Speech", "Debate or speech"],
  ["Environmental", "Environmental"],
  ["Family Responsibilities", "Family responsibilities"],
  ["Foreign Exchange", "Study abroad or foreign exchange"],
  ["Foreign Language", "Foreign language"],
  ["Internship", "Internship"],
  ["Journalism/Publication", "Journalism or publishing"],
  ["Junior R.O.T.C.", "R.O.T.C. or military"],
  ["LGBT", "LGBT+"],
  ["Music: Instrumental", "Music"],
  ["Music: Vocal", "Music"],
  ["Religious", "Religious"],
  ["Research", "Research"],
  ["Robotics", "Robotics"],
  ["School Spirit", "School spirit"],
  ["Science/Math", "Science or math"],
  ["Social Justice", "Social justice or organizing"],
  ["Student Govt./Politics", "Student government or politics"],
  ["Theater/Drama", "Theater or drama"],
  ["Work (Paid)", "Employment or work (paid)"],
  ["Other Club/Activity", "Other"]
]);
var LEGACY_PREFIX = "From your earlier version: ";
var isRecord = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
var text = (v) => typeof v === "string" ? v : "";
var numberOrNull = (v) => typeof v === "number" && Number.isFinite(v) ? v : null;
var boolOrNull = (v) => typeof v === "boolean" ? v : null;
var monthOrNull = (v) => typeof v === "string" && v !== "" ? v : null;
var listOf = (v) => Array.isArray(v) ? v : [];
var ownKey = (o, k) => typeof k === "string" && Object.prototype.hasOwnProperty.call(o, k);
var idOf = (v, list, i) => typeof v === "string" && v.trim() !== "" ? v : `legacy-${list}-${i}`;
var gradesOf = (v) => listOf(v).filter((g) => GRADES.includes(g));
var collapse = (s) => s.toLowerCase().replace(/\s+/g, " ").trim();
function caTiming(v) {
  if (Array.isArray(v)) {
    const school = v.includes("school");
    const brk = v.includes("break");
    return school && brk ? "all" : school ? "school" : brk ? "break" : null;
  }
  return v === "school" || v === "break" || v === "all" ? v : null;
}
function caContinue(v) {
  if (v === true) return "yes";
  if (v === false) return "no";
  return v === "yes" || v === "no" || v === "not_sure" ? v : null;
}
function upgradeCaActivity(r, i) {
  const type = text(r.type);
  const position = text(r.position);
  const a = {
    id: idOf(r.id, "ca", i),
    type: OLD_CA_TYPES.get(type) ?? type,
    // a current label is not an old key, so it passes through
    sport: text(r.sport),
    // The old form had no such question; a role was the only hint. Not answered is null, never false.
    leadership: r.leadership === void 0 ? position.trim() ? true : null : boolOrNull(r.leadership),
    position,
    organization: text(r.organization),
    description: text(r.description),
    grades: gradesOf(r.grades),
    timing: caTiming(r.timing),
    afterStart: monthOrNull(r.afterStart),
    stillParticipating: boolOrNull(r.stillParticipating),
    afterEnd: monthOrNull(r.afterEnd),
    hoursPerWeek: numberOrNull(r.hoursPerWeek),
    weeksPerYear: numberOrNull(r.weeksPerYear),
    continueInCollege: caContinue(r.continueInCollege)
  };
  if (text(r.legacy)) a.legacy = text(r.legacy);
  return a;
}
function upgradeCaHonor(r, i) {
  return {
    id: idOf(r.id, "honor", i),
    title: text(r.title),
    grades: gradesOf(r.grades),
    levels: listOf(r.levels).filter((l) => ownKey(HONOR_LEVELS, l))
  };
}
function ucProgramFor(name) {
  const key = collapse(name);
  if (!key) return null;
  for (const p of UC_EDPREP_PROGRAMS) {
    if (p.value === UC_EDPREP_OTHER) continue;
    const keys = [p.label, /\(([^()]*)\)[^()]*$/.exec(p.label)?.[1], p.label.split(" (")[0]];
    if (keys.some((k) => k && collapse(k) === key)) return p.value;
  }
  return null;
}
var UC_YEARS_LIST = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, "10+"];
function workHoursOf(v) {
  const out = {};
  if (!isRecord(v)) return out;
  for (const g of GRADES) {
    const h = v[g];
    if (isRecord(h)) out[g] = { schoolYear: numberOrNull(h.schoolYear), summer: numberOrNull(h.summer) };
  }
  return out;
}
function upgradeUcEntry(r, i, v1) {
  const category = UC_CATEGORY_KEYS.includes(r.category) ? r.category : "extracurricular";
  const level = r.awardLevel;
  const e = {
    id: idOf(r.id, "uc", i),
    category,
    name: text(r.name),
    jobTitle: text(r.jobTitle),
    extra: text(r.extra),
    description: text(r.description),
    grades: gradesOf(r.grades),
    hoursPerWeek: numberOrNull(r.hoursPerWeek),
    weeksPerYear: numberOrNull(r.weeksPerYear),
    afterYears: UC_YEARS_LIST.includes(r.afterYears) ? r.afterYears : null,
    afterMonths: numberOrNull(r.afterMonths),
    // Old entries held one level; current ones hold a list.
    awardLevels: Array.isArray(r.awardLevels) ? r.awardLevels.filter((l) => ownKey(UC_AWARD_LEVELS, l)) : ownKey(UC_AWARD_LEVELS, level) ? [level] : [],
    awardType: r.awardType === "academic" || r.awardType === "non_academic" ? r.awardType : null,
    program: typeof r.program === "string" && r.program !== "" ? r.program : null,
    workHours: workHoursOf(r.workHours),
    stillWorking: boolOrNull(r.stillWorking),
    start: monthOrNull(r.start),
    end: monthOrNull(r.end)
  };
  const notes = text(r.legacy) ? [text(r.legacy)] : [];
  if (v1 && category === "work") {
    e.jobTitle = text(r.name);
    e.name = text(r.organization);
    const hours = [e.hoursPerWeek !== null && `${e.hoursPerWeek} hours/week`, e.weeksPerYear !== null && `${e.weeksPerYear} weeks/year`].filter(Boolean);
    if (hours.length) notes.push(`${LEGACY_PREFIX}${hours.join(", ")}`);
    e.hoursPerWeek = null;
    e.weeksPerYear = null;
  } else if (v1) {
    if (category === "edprep") {
      const old = text(r.name).trim();
      const program = ucProgramFor(old);
      if (program) [e.program, e.name] = [program, ""];
      else if (!old) [e.program, e.name] = [null, ""];
      else if (ucTextLength(old) <= UC_LIMITS.otherProgramName) [e.program, e.name] = [UC_EDPREP_OTHER, old];
      else {
        [e.program, e.name] = [UC_EDPREP_OTHER, ""];
        notes.push(`${LEGACY_PREFIX}${old}`);
      }
    }
    if (text(r.organization).trim()) notes.push(`${LEGACY_PREFIX}organization ${text(r.organization)}`);
  }
  if (notes.length) e.legacy = notes.join("; ");
  if (text(r.fromId)) e.fromId = text(r.fromId);
  return e;
}
function upgradeActivities(raw) {
  const src = isRecord(raw) ? raw : {};
  const v1 = src.version !== 2;
  const commonApp = isRecord(src.commonApp) ? src.commonApp : {};
  return {
    version: 2,
    commonApp: {
      activities: listOf(commonApp.activities).flatMap((r, i) => isRecord(r) ? [upgradeCaActivity(r, i)] : []),
      honors: listOf(commonApp.honors).flatMap((r, i) => isRecord(r) ? [upgradeCaHonor(r, i)] : [])
    },
    uc: listOf(src.uc).flatMap((r, i) => isRecord(r) ? [upgradeUcEntry(r, i, v1)] : [])
  };
}

// ../web/lib/fields.ts
var FIELDS = [
  // STEM
  {
    key: "computer_science",
    area: "stem",
    cips: ["11", "30.70", "30.08"],
    tiers: [{ category: "computer_science", weight: 1 }],
    keywords: /computer science|computing|software|information technology|data science|informatics|\bBCS\b/i
  },
  {
    key: "data_science",
    area: "stem",
    cips: ["30.70", "27.05", "30.08"],
    tiers: [{ category: "computer_science", weight: 0.5 }, { category: "math_physics", weight: 0.5 }],
    keywords: /data science|statistic|analytics/i
  },
  { key: "engineering", area: "stem", cips: ["14"], tiers: [{ category: "engineering", weight: 1 }], keywords: /engineer/i },
  {
    key: "math_physical",
    area: "stem",
    cips: ["27", "40"],
    exclude: ["40.06"],
    tiers: [{ category: "math_physics", weight: 1 }],
    keywords: /mathemat|physics|statistic|chemistry|astronom/i
  },
  {
    key: "environment",
    area: "stem",
    cips: ["03", "40.06"],
    tiers: [],
    keywords: /environment|earth sciences?\b|geolog|geoscience|ecolog|sustainab|conservation/i
  },
  { key: "agriculture", area: "stem", cips: ["01"], tiers: [], keywords: /agricult|agronom|animal science|food science|horticult/i },
  // Business
  {
    key: "business",
    area: "business",
    cips: ["52"],
    tiers: [{ category: "business", weight: 1 }],
    // Not finance/accounting: "Economics, Finance and Data Science" is not a business degree; those have their own field.
    keywords: /business|management|commerce|marketing|\bBBA\b|\bBCom\b/i
  },
  {
    key: "finance_accounting",
    area: "business",
    cips: ["52.08", "52.03"],
    tiers: [{ category: "business", weight: 0.7 }, { category: "economics", weight: 0.3 }],
    keywords: /financ|accounting|actuar/i
  },
  { key: "economics", area: "business", cips: ["45.06"], tiers: [{ category: "economics", weight: 1 }], keywords: /econom/i },
  {
    key: "hospitality",
    area: "business",
    cips: ["52.09"],
    tiers: [{ category: "business", weight: 1, proxy: true }],
    keywords: /hospitality|hotel|tourism/i
  },
  // Health
  {
    key: "pre_med",
    area: "health",
    cips: ["26", "40.05", "51.11"],
    tiers: [{ category: "pre_med", weight: 0.7 }, { category: "biology_life_sci", weight: 0.3 }],
    keywords: /medicine|\bMBBS\b|\bMBChB\b|\bMBBCh\b|medical science|pre-?med/i
  },
  { key: "nursing", area: "health", cips: ["51.38"], tiers: [{ category: "nursing", weight: 1 }], keywords: /nursing/i },
  {
    key: "health_sciences",
    area: "health",
    cips: ["51"],
    exclude: ["51.38", "51.11"],
    tiers: [],
    keywords: /health|pharmac|physiotherap|nutrition|dietetic|dentist|optometr|occupational therapy|radiograph|paramedic/i
  },
  {
    key: "biology",
    area: "health",
    cips: ["26"],
    tiers: [{ category: "biology_life_sci", weight: 1 }],
    keywords: /biolog|life science|biomedical science|biochem|neuroscience/i
  },
  { key: "psychology", area: "health", cips: ["42"], tiers: [], keywords: /psycholog/i },
  { key: "kinesiology", area: "health", cips: ["31"], tiers: [], keywords: /kinesiolog|sports? science|exercise science|human movement/i },
  // Law & society
  {
    key: "pre_law",
    area: "law_society",
    cips: ["45.10", "22", "38.01"],
    tiers: [{ category: "humanities", weight: 1, proxy: true }],
    keywords: /\blaws?\b|\bLLB\b|legal/i
  },
  {
    key: "international_relations",
    area: "law_society",
    cips: ["45.09", "44.05"],
    tiers: [{ category: "humanities", weight: 1, proxy: true }, { category: "economics", weight: 1, proxy: true }],
    keywords: /international relations|international affairs|international studies|global affairs|public policy/i
  },
  {
    key: "social_sciences",
    area: "law_society",
    cips: ["45"],
    exclude: ["45.06", "45.09", "45.10"],
    tiers: [{ category: "humanities", weight: 1, proxy: true }],
    // "social science(s)" is left out on purpose: course names use it for admission groups ("Social Sciences admission category").
    keywords: /sociolog|anthropolog|political science|politics|geograph/i
  },
  { key: "criminal_justice", area: "law_society", cips: ["43"], tiers: [], keywords: /criminolog|criminal justice|policing/i },
  { key: "social_work", area: "law_society", cips: ["44"], exclude: ["44.05"], tiers: [], keywords: /social work|human services/i },
  { key: "education", area: "law_society", cips: ["13"], tiers: [], keywords: /\beducation\b|teaching|\bB\.?Ed\b/i },
  // Arts & humanities
  {
    key: "humanities",
    area: "arts_humanities",
    cips: ["23", "54", "38", "16"],
    tiers: [{ category: "humanities", weight: 1 }],
    keywords: /history|philosoph|literature|\benglish\b|classics|linguistic|languages|religio|theolog/i
  },
  { key: "communications", area: "arts_humanities", cips: ["09", "10"], tiers: [], keywords: /communication|journalism|\bmedia\b/i },
  {
    key: "visual_arts_design",
    area: "arts_humanities",
    cips: ["50"],
    exclude: ["50.03", "50.05", "50.09"],
    tiers: [{ category: "arts_design", weight: 1 }],
    keywords: /fine arts?\b|visual arts?\b|\bdesign\b|\bart\b|illustration|animation|photograph/i
  },
  {
    key: "performing_arts",
    area: "arts_humanities",
    cips: ["50.03", "50.05", "50.09"],
    tiers: [{ category: "arts_design", weight: 1, proxy: true }],
    keywords: /music|drama|theatre|theater|\bdance\b|performing/i
  },
  { key: "architecture", area: "arts_humanities", cips: ["04"], tiers: [], keywords: /architect/i },
  // No direction yet: ranked by the general tier only.
  { key: "undecided", area: "general", cips: [], tiers: [], keywords: null }
];
var BY_KEY = new Map(FIELDS.map((f) => [f.key, f]));

// ../web/lib/student-rows.ts
var toTranscriptSchool = (r) => ({
  id: r.id,
  name: r.name,
  country: r.country ?? "",
  kind: r.kind,
  curriculum: r.curriculum,
  defaultScale: r.default_scale,
  defaultPeriod: r.default_period,
  firstYear: r.first_year,
  lastYear: r.last_year,
  printedGpa: r.printed_gpa ?? "",
  printedGpaScale: r.printed_gpa_scale ?? "",
  gpaWeighted: r.gpa_weighted,
  classRank: r.class_rank ?? "",
  schoolCode: r.school_code ?? "",
  notes: r.notes ?? "",
  createdAt: r.created_at
});
var num = (v) => v == null || v === "" ? null : Number(v);
var toTranscriptCourse = (r) => ({
  id: r.id,
  schoolId: r.school_id,
  academicYear: r.academic_year,
  gradeLevel: r.grade_level,
  name: r.name,
  period: r.period_type,
  terms: Array.isArray(r.terms) ? r.terms : [],
  finalGrade: r.final_grade || null,
  scale: r.grade_scale,
  scaleMax: num(r.scale_max),
  level: r.level,
  credit: num(r.credit),
  creditUnit: r.credit_unit,
  subject: r.subject,
  subSubject: r.sub_subject || null,
  languageName: r.language_name ?? "",
  isSummer: r.is_summer,
  isRepeat: r.is_repeat,
  isCollege: r.is_college,
  collegeName: r.college_name ?? "",
  isWithdrawn: r.is_withdrawn,
  notes: r.notes ?? "",
  source: r.source,
  overrides: r.overrides ?? {},
  sortOrder: r.sort_order,
  createdAt: r.created_at
});

// src/config.ts
var TRACKER_URL = true ? "https://www.track-ur-college.com" : "";
var DEV_BUILD = TRACKER_URL !== "" && !TRACKER_URL.startsWith("https://");
var SUPABASE_URL = "https://eyvmtaggayqizllaseiu.supabase.co";
var SUPABASE_KEY = "sb_publishable_5B39sQnRwgy3LaFOZrDFZg_eeCoJaoS";

// src/auth.ts
var TOKEN_KEY = "token";
var SCHOOL_BLANK = {
  curriculum: "us",
  default_scale: "letter_plus_minus",
  first_year: null,
  last_year: null,
  printed_gpa: null,
  printed_gpa_scale: null,
  gpa_weighted: null,
  class_rank: null,
  notes: null,
  created_at: ""
};
var COURSE_BLANK = { is_withdrawn: false, notes: null, source: "manual", created_at: "" };
var rowOf = (r) => {
  if (typeof r !== "object" || r === null) throw new Error("bad row");
  return r;
};
function parseTokenFromRedirect(url) {
  const hash = url.indexOf("#");
  if (hash < 0) return null;
  const params = new URLSearchParams(url.slice(hash + 1));
  if (params.has("error")) return null;
  return params.get("token") || null;
}
function parseTranscriptResponse(body) {
  const network = { ok: false, reason: "network" };
  if (typeof body !== "object" || body === null) return network;
  const b = body;
  if (b.ok === false) {
    if (b.error === "invalid_token") return { ok: false, reason: "signed_out" };
    if (b.error === "students_only") return { ok: false, reason: "students_only" };
    return network;
  }
  if (b.ok !== true || !Array.isArray(b.schools) || !Array.isArray(b.courses)) return network;
  try {
    return {
      ok: true,
      schools: b.schools.map((r) => toTranscriptSchool({ ...SCHOOL_BLANK, ...rowOf(r) })),
      courses: b.courses.map((r) => toTranscriptCourse({ ...COURSE_BLANK, ...rowOf(r) }))
    };
  } catch {
    return network;
  }
}
function parseActivitiesResponse(body) {
  const network = { ok: false, reason: "network" };
  if (typeof body !== "object" || body === null || Array.isArray(body)) return network;
  const b = body;
  if (b.ok === false) {
    if (b.error === "invalid_token") return { ok: false, reason: "signed_out" };
    if (b.error === "students_only") return { ok: false, reason: "students_only" };
    if (b.error === "no_scope") return { ok: false, reason: "reconnect" };
    return network;
  }
  const a = b.activities;
  if (b.ok !== true || typeof a !== "object" || a === null || Array.isArray(a)) return network;
  return { ok: true, data: upgradeActivities(a) };
}
async function getToken() {
  const stored = await chrome.storage.local.get(TOKEN_KEY);
  const t = stored[TOKEN_KEY];
  return typeof t === "string" && t ? t : null;
}
async function signIn() {
  try {
    if (!TRACKER_URL) return false;
    const redirect = chrome.identity.getRedirectURL();
    const url = `${TRACKER_URL}/extension/connect?redirect_uri=${encodeURIComponent(redirect)}`;
    const result = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
    const token = result ? parseTokenFromRedirect(result) : null;
    if (!token) return false;
    await chrome.storage.local.set({ [TOKEN_KEY]: token });
    return true;
  } catch {
    return false;
  }
}
var REVOKE_TIMEOUT_MS = 5e3;
async function revokeToken(token) {
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/rpc/revoke_my_extension_token`, {
      method: "POST",
      headers: { apikey: SUPABASE_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ p_token: token }),
      signal: AbortSignal.timeout(REVOKE_TIMEOUT_MS)
    });
  } catch {
  }
}
async function signOut() {
  let token = null;
  try {
    token = await getToken();
  } catch {
  }
  if (token) await revokeToken(token);
  await clearToken();
}
async function clearToken() {
  await chrome.storage.local.remove(TOKEN_KEY);
}
async function callTokenRpc(fn, token) {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
      method: "POST",
      headers: { apikey: SUPABASE_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ p_token: token })
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}
async function loadTranscript() {
  const token = await getToken();
  if (!token) return { ok: false, reason: "signed_out" };
  const body = await callTokenRpc("extension_transcript", token);
  if (body === null) return { ok: false, reason: "network" };
  const result = parseTranscriptResponse(body);
  if (!result.ok && result.reason === "signed_out") await clearToken();
  return result;
}
async function loadActivities() {
  const token = await getToken();
  if (!token) return { ok: false, reason: "signed_out" };
  const body = await callTokenRpc("extension_activities", token);
  if (body === null) return { ok: false, reason: "network" };
  const result = parseActivitiesResponse(body);
  if (!result.ok && result.reason === "signed_out") await signOut();
  return result;
}

// src/background-guards.ts
function isOwnPageSender(sender, extensionId, extensionUrl) {
  return !!sender && sender.id === extensionId && !sender.tab && typeof sender.url === "string" && sender.url.startsWith(extensionUrl);
}
var PANEL_TYPES = ["signIn", "signOut", "loadTranscript", "loadActivities"];
function createPanelListener(deps) {
  return (msg, sender, sendResponse) => {
    const type = msg?.type;
    if (typeof type !== "string" || !PANEL_TYPES.includes(type)) return false;
    if (!isOwnPageSender(sender, deps.extensionId, deps.extensionUrl)) return false;
    deps.handle(msg).then(sendResponse, () => sendResponse(void 0));
    return true;
  };
}
function restrictStorageToTrustedContexts(area) {
  try {
    void Promise.resolve(area?.setAccessLevel?.({ accessLevel: "TRUSTED_CONTEXTS" })).catch(() => {
    });
  } catch {
  }
}

// src/background.ts
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
});
restrictStorageToTrustedContexts(chrome.storage.local);
async function handle(msg) {
  switch (msg.type) {
    case "signIn":
      return { type: "signIn", ok: await signIn() };
    case "signOut":
      await signOut();
      return { type: "signOut" };
    case "loadTranscript":
      return { type: "loadTranscript", result: await loadTranscript() };
    case "loadActivities":
      return { type: "loadActivities", result: await loadActivities() };
  }
}
chrome.runtime.onMessage.addListener(createPanelListener({ extensionId: chrome.runtime.id, extensionUrl: chrome.runtime.getURL(""), handle }));
