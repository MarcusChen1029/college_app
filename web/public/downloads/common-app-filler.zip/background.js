// ../web/lib/fields.ts
var FIELDS = [
  // STEM
  {
    key: "computer_science",
    area: "stem",
    cips: ["11", "30.70", "30.08"],
    tiers: [{ category: "computer_science", weight: 1 }],
    keywords: /computer science|computing|software|information technology|data science|informatics|\bBCS\b/i
  },
  {
    key: "data_science",
    area: "stem",
    cips: ["30.70", "27.05", "30.08"],
    tiers: [{ category: "computer_science", weight: 0.5 }, { category: "math_physics", weight: 0.5 }],
    keywords: /data science|statistic|analytics/i
  },
  { key: "engineering", area: "stem", cips: ["14"], tiers: [{ category: "engineering", weight: 1 }], keywords: /engineer/i },
  {
    key: "math_physical",
    area: "stem",
    cips: ["27", "40"],
    exclude: ["40.06"],
    tiers: [{ category: "math_physics", weight: 1 }],
    keywords: /mathemat|physics|statistic|chemistry|astronom/i
  },
  {
    key: "environment",
    area: "stem",
    cips: ["03", "40.06"],
    tiers: [],
    keywords: /environment|earth sciences?\b|geolog|geoscience|ecolog|sustainab|conservation/i
  },
  { key: "agriculture", area: "stem", cips: ["01"], tiers: [], keywords: /agricult|agronom|animal science|food science|horticult/i },
  // Business
  {
    key: "business",
    area: "business",
    cips: ["52"],
    tiers: [{ category: "business", weight: 1 }],
    // Not finance/accounting: "Economics, Finance and Data Science" is not a business degree; those have their own field.
    keywords: /business|management|commerce|marketing|\bBBA\b|\bBCom\b/i
  },
  {
    key: "finance_accounting",
    area: "business",
    cips: ["52.08", "52.03"],
    tiers: [{ category: "business", weight: 0.7 }, { category: "economics", weight: 0.3 }],
    keywords: /financ|accounting|actuar/i
  },
  { key: "economics", area: "business", cips: ["45.06"], tiers: [{ category: "economics", weight: 1 }], keywords: /econom/i },
  {
    key: "hospitality",
    area: "business",
    cips: ["52.09"],
    tiers: [{ category: "business", weight: 1, proxy: true }],
    keywords: /hospitality|hotel|tourism/i
  },
  // Health
  {
    key: "pre_med",
    area: "health",
    cips: ["26", "40.05", "51.11"],
    tiers: [{ category: "pre_med", weight: 0.7 }, { category: "biology_life_sci", weight: 0.3 }],
    keywords: /medicine|\bMBBS\b|\bMBChB\b|\bMBBCh\b|medical science|pre-?med/i
  },
  { key: "nursing", area: "health", cips: ["51.38"], tiers: [{ category: "nursing", weight: 1 }], keywords: /nursing/i },
  {
    key: "health_sciences",
    area: "health",
    cips: ["51"],
    exclude: ["51.38", "51.11"],
    tiers: [],
    keywords: /health|pharmac|physiotherap|nutrition|dietetic|dentist|optometr|occupational therapy|radiograph|paramedic/i
  },
  {
    key: "biology",
    area: "health",
    cips: ["26"],
    tiers: [{ category: "biology_life_sci", weight: 1 }],
    keywords: /biolog|life science|biomedical science|biochem|neuroscience/i
  },
  { key: "psychology", area: "health", cips: ["42"], tiers: [], keywords: /psycholog/i },
  { key: "kinesiology", area: "health", cips: ["31"], tiers: [], keywords: /kinesiolog|sports? science|exercise science|human movement/i },
  // Law & society
  {
    key: "pre_law",
    area: "law_society",
    cips: ["45.10", "22", "38.01"],
    tiers: [{ category: "humanities", weight: 1, proxy: true }],
    keywords: /\blaws?\b|\bLLB\b|legal/i
  },
  {
    key: "international_relations",
    area: "law_society",
    cips: ["45.09", "44.05"],
    tiers: [{ category: "humanities", weight: 1, proxy: true }, { category: "economics", weight: 1, proxy: true }],
    keywords: /international relations|international affairs|international studies|global affairs|public policy/i
  },
  {
    key: "social_sciences",
    area: "law_society",
    cips: ["45"],
    exclude: ["45.06", "45.09", "45.10"],
    tiers: [{ category: "humanities", weight: 1, proxy: true }],
    // "social science(s)" is left out on purpose: course names use it for admission groups ("Social Sciences admission category").
    keywords: /sociolog|anthropolog|political science|politics|geograph/i
  },
  { key: "criminal_justice", area: "law_society", cips: ["43"], tiers: [], keywords: /criminolog|criminal justice|policing/i },
  { key: "social_work", area: "law_society", cips: ["44"], exclude: ["44.05"], tiers: [], keywords: /social work|human services/i },
  { key: "education", area: "law_society", cips: ["13"], tiers: [], keywords: /\beducation\b|teaching|\bB\.?Ed\b/i },
  // Arts & humanities
  {
    key: "humanities",
    area: "arts_humanities",
    cips: ["23", "54", "38", "16"],
    tiers: [{ category: "humanities", weight: 1 }],
    keywords: /history|philosoph|literature|\benglish\b|classics|linguistic|languages|religio|theolog/i
  },
  { key: "communications", area: "arts_humanities", cips: ["09", "10"], tiers: [], keywords: /communication|journalism|\bmedia\b/i },
  {
    key: "visual_arts_design",
    area: "arts_humanities",
    cips: ["50"],
    exclude: ["50.03", "50.05", "50.09"],
    tiers: [{ category: "arts_design", weight: 1 }],
    keywords: /fine arts?\b|visual arts?\b|\bdesign\b|\bart\b|illustration|animation|photograph/i
  },
  {
    key: "performing_arts",
    area: "arts_humanities",
    cips: ["50.03", "50.05", "50.09"],
    tiers: [{ category: "arts_design", weight: 1, proxy: true }],
    keywords: /music|drama|theatre|theater|\bdance\b|performing/i
  },
  { key: "architecture", area: "arts_humanities", cips: ["04"], tiers: [], keywords: /architect/i },
  // No direction yet: ranked by the general tier only.
  { key: "undecided", area: "general", cips: [], tiers: [], keywords: null }
];
var BY_KEY = new Map(FIELDS.map((f) => [f.key, f]));

// ../web/lib/student-rows.ts
var PROFILE_BASE = "sat_total, act_composite, gpa_unweighted, gpa_weighted, is_international, target_regions, study_fields, reminder_emails, plan, test_details, interested, activities, resume, essays";
var PROFILE_COLUMNS = `${PROFILE_BASE}, portals`;
var toTranscriptSchool = (r) => ({
  id: r.id,
  name: r.name,
  country: r.country ?? "",
  kind: r.kind,
  curriculum: r.curriculum,
  defaultScale: r.default_scale,
  defaultPeriod: r.default_period,
  firstYear: r.first_year,
  lastYear: r.last_year,
  printedGpa: r.printed_gpa ?? "",
  printedGpaScale: r.printed_gpa_scale ?? "",
  gpaWeighted: r.gpa_weighted,
  classRank: r.class_rank ?? "",
  schoolCode: r.school_code ?? "",
  notes: r.notes ?? "",
  createdAt: r.created_at
});
var num = (v) => v == null || v === "" ? null : Number(v);
var toTranscriptCourse = (r) => ({
  id: r.id,
  schoolId: r.school_id,
  academicYear: r.academic_year,
  gradeLevel: r.grade_level,
  name: r.name,
  period: r.period_type,
  terms: Array.isArray(r.terms) ? r.terms : [],
  finalGrade: r.final_grade || null,
  scale: r.grade_scale,
  scaleMax: num(r.scale_max),
  level: r.level,
  credit: num(r.credit),
  creditUnit: r.credit_unit,
  subject: r.subject,
  subSubject: r.sub_subject || null,
  languageName: r.language_name ?? "",
  isSummer: r.is_summer,
  isRepeat: r.is_repeat,
  isCollege: r.is_college,
  collegeName: r.college_name ?? "",
  isWithdrawn: r.is_withdrawn,
  notes: r.notes ?? "",
  source: r.source,
  overrides: r.overrides ?? {},
  sortOrder: r.sort_order,
  createdAt: r.created_at
});

// src/config.ts
var TRACKER_URL = "https://www.track-ur-college.com" ? "https://www.track-ur-college.com" : "http://localhost:3000";
var SUPABASE_URL = "https://eyvmtaggayqizllaseiu.supabase.co";
var SUPABASE_KEY = "sb_publishable_5B39sQnRwgy3LaFOZrDFZg_eeCoJaoS";

// src/auth.ts
var TOKEN_KEY = "token";
function parseTokenFromRedirect(url) {
  const hash = url.indexOf("#");
  if (hash < 0) return null;
  const params = new URLSearchParams(url.slice(hash + 1));
  if (params.has("error")) return null;
  return params.get("token") || null;
}
function parseTranscriptResponse(body) {
  const network = { ok: false, reason: "network" };
  if (typeof body !== "object" || body === null) return network;
  const b = body;
  if (b.ok === false) {
    if (b.error === "invalid_token") return { ok: false, reason: "signed_out" };
    if (b.error === "students_only") return { ok: false, reason: "students_only" };
    return network;
  }
  if (b.ok !== true || !Array.isArray(b.schools) || !Array.isArray(b.courses)) return network;
  try {
    return {
      ok: true,
      schools: b.schools.map(toTranscriptSchool),
      courses: b.courses.map(toTranscriptCourse)
    };
  } catch {
    return network;
  }
}
async function getToken() {
  const stored = await chrome.storage.local.get(TOKEN_KEY);
  const t = stored[TOKEN_KEY];
  return typeof t === "string" && t ? t : null;
}
async function signIn() {
  try {
    const redirect = chrome.identity.getRedirectURL();
    const url = `${TRACKER_URL}/extension/connect?redirect_uri=${encodeURIComponent(redirect)}`;
    const result = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
    const token = result ? parseTokenFromRedirect(result) : null;
    if (!token) return false;
    await chrome.storage.local.set({ [TOKEN_KEY]: token });
    return true;
  } catch {
    return false;
  }
}
async function signOut() {
  await chrome.storage.local.remove(TOKEN_KEY);
}
async function loadTranscript() {
  const token = await getToken();
  if (!token) return { ok: false, reason: "signed_out" };
  let body;
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/extension_transcript`, {
      method: "POST",
      headers: { apikey: SUPABASE_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ p_token: token })
    });
    if (!res.ok) return { ok: false, reason: "network" };
    body = await res.json();
  } catch {
    return { ok: false, reason: "network" };
  }
  const result = parseTranscriptResponse(body);
  if (!result.ok && result.reason === "signed_out") await signOut();
  return result;
}

// src/background.ts
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
});
async function handle(msg) {
  switch (msg.type) {
    case "signIn":
      return { type: "signIn", ok: await signIn() };
    case "signOut":
      await signOut();
      return { type: "signOut" };
    case "loadTranscript":
      return { type: "loadTranscript", result: await loadTranscript() };
  }
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const type = msg?.type;
  if (type !== "signIn" && type !== "signOut" && type !== "loadTranscript") return false;
  handle(msg).then(sendResponse, () => sendResponse(void 0));
  return true;
});
