"use strict";
(() => {
  // src/assist/insert.ts
  var ASSIST_TIMING = { stepMs: 80, optionsMs: 2500 };
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var sameText = (a, b) => flat(a) === flat(b);
  var flat = (s) => s.normalize("NFKC").toLowerCase().replace(/[‐-―-]/g, "-").replace(/\s+/g, " ").trim();
  var text = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  function fire(el, type, init = {}) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = (type.startsWith("key") ? view.KeyboardEvent : type === "click" || type.startsWith("mouse") ? view.MouseEvent : view.Event) ?? view.Event ?? Event;
    el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, ...init }));
  }
  function setText(input, value, commit = false) {
    input.focus?.();
    fireFocus(input, "focus", "focusin");
    input.value = value;
    fire(input, "input");
    fire(input, "change");
    if (commit) fireFocus(input, "blur", "focusout");
  }
  function fireFocus(el, own, bubbling) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = view.FocusEvent ?? view.Event ?? Event;
    el.dispatchEvent(new Ctor(own, { bubbles: false }));
    el.dispatchEvent(new Ctor(bubbling, { bubbles: true }));
  }
  function labelOf(el) {
    const doc = el.ownerDocument;
    const id = el.getAttribute("id");
    const byFor = id ? doc.querySelector(`label[for="${id.replace(/"/g, '\\"')}"]`) : null;
    if (byFor) return text(byFor);
    const wrap = el.closest("label");
    if (wrap) return text(wrap);
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.trim();
    const ids = el.getAttribute("aria-labelledby");
    if (ids) return ids.split(/\s+/).map((i) => text(doc.getElementById(i))).join(" ").trim();
    return "";
  }
  var TRUE = ["yes", "true", "y", "1", "checked"];
  var FALSE = ["no", "false", "n", "0", "unchecked", ""];
  function visibleOptions(doc) {
    return [...doc.querySelectorAll('[role="option"], .ng-option, mat-option')].filter((o) => o.getAttribute("aria-disabled") !== "true");
  }
  async function pickOption(doc, value, selector) {
    const start = Date.now();
    for (; ; ) {
      const options2 = selector ? [...doc.querySelectorAll(selector)] : visibleOptions(doc);
      const hit = options2.find((o) => sameText(text(o), value));
      if (hit) return hit;
      if (Date.now() - start >= ASSIST_TIMING.optionsMs) return null;
      await sleep(ASSIST_TIMING.stepMs);
    }
  }
  function comboboxOf(el) {
    if (el.getAttribute("role") === "combobox" || el.hasAttribute("aria-autocomplete")) return el;
    return el.closest('[role="combobox"], mat-select, ng-select, .RadComboBox, .RadDropDownTree');
  }
  function treeLeaves(root) {
    return [...root.querySelectorAll(".RadTreeView .rtText")].filter((e) => !e.closest("li")?.querySelector("ul"));
  }
  function openList(combo) {
    const arrow = combo.matches(".RadComboBox") ? combo.querySelector(".rcbArrowCell a, .rcbActionButton, button") : null;
    fire(arrow ?? combo, "mousedown");
    fire(arrow ?? combo, "click");
  }
  async function insertValue(target, value) {
    if (!target || target === target.ownerDocument.body || target === target.ownerDocument.documentElement) {
      return { ok: false, reason: "Click the box on the page first, then press the value here." };
    }
    const doc = target.ownerDocument;
    const tag = target.tagName.toLowerCase();
    if (tag === "select") {
      const sel = target;
      const opts = [...sel.querySelectorAll("option")];
      const i = opts.findIndex((o) => sameText(text(o), value) || sameText(o.getAttribute("value") ?? "", value));
      if (i < 0) return { ok: false, reason: `"${value}" is not one of this list's options (${opts.slice(0, 6).map((o) => text(o)).filter(Boolean).join(", ")}${opts.length > 6 ? ", \u2026" : ""}).` };
      opts.forEach((o, j) => o.selected = j === i);
      sel.selectedIndex = i;
      fire(sel, "input");
      fire(sel, "change");
      return { ok: true, how: "picked" };
    }
    if (tag === "input" && ["checkbox", "radio"].includes((target.getAttribute("type") ?? "").toLowerCase())) {
      const input = target;
      const type = input.getAttribute("type").toLowerCase();
      if (type === "checkbox") {
        const want = TRUE.includes(flat(value)) ? true : FALSE.includes(flat(value)) ? false : null;
        if (want == null) return { ok: false, reason: `This is a tick box; "${value}" is not Yes or No.` };
        if (input.checked !== want) input.click();
        return { ok: true, how: want ? "ticked" : "unticked" };
      }
      const name = input.getAttribute("name");
      const group = name ? [...doc.querySelectorAll(`input[type="radio"][name="${name.replace(/"/g, '\\"')}"]`)] : [input];
      const hit = group.find((r) => sameText(labelOf(r), value) || sameText(r.getAttribute("value") ?? "", value));
      if (!hit) return { ok: false, reason: `No choice here reads "${value}" (${group.map(labelOf).filter(Boolean).join(", ")}).` };
      hit.click();
      return { ok: true, how: "chose" };
    }
    const combo = comboboxOf(target);
    if (combo?.matches(".RadDropDownTree")) {
      const scope = combo.ownerDocument.querySelector(`#${combo.id}_EmbeddedTree`) ?? combo;
      const leaf = treeLeaves(scope).find((e) => sameText(text(e), value));
      if (!leaf) return { ok: false, reason: `No choice in this list reads "${value}".` };
      fire(leaf, "mousedown");
      leaf.click();
      return { ok: true, how: "picked" };
    }
    const telerik = combo?.closest(".RadComboBox");
    if (telerik) {
      openList(telerik);
      const item = await pickOption(doc, value, `#${telerik.id}_DropDown li`);
      if (!item) return { ok: false, reason: `No option reads "${value}" in this list.` };
      fire(item, "mouseover");
      fire(item, "mousedown");
      item.click();
      return { ok: true, how: "picked" };
    }
    if (combo) {
      const input = combo.matches("input") ? combo : combo.querySelector("input:not([type=hidden])");
      let option = visibleOptions(doc).find((o) => sameText(text(o), value)) ?? null;
      if (!option) {
        if (input && !input.readOnly) setText(input, value);
        else openList(combo);
        option = await pickOption(doc, value);
      }
      if (option) {
        fire(option, "mousedown");
        option.click();
        return { ok: true, how: "picked" };
      }
      if (input && !input.readOnly) return { ok: true, how: "typed (no matching option appeared; check the box)" };
      return { ok: false, reason: `No option reads "${value}" in this list.` };
    }
    if (tag === "input" || tag === "textarea") {
      const input = target;
      if (input.readOnly || input.disabled) return { ok: false, reason: "That box is read-only." };
      setText(input, value, true);
      return { ok: true, how: "typed" };
    }
    if (target.isContentEditable || target.getAttribute("contenteditable") === "true") {
      target.textContent = value;
      fire(target, "input");
      return { ok: true, how: "typed" };
    }
    return { ok: false, reason: "That is not a box the assistant can type into. Click the box itself." };
  }

  // src/assist/next.ts
  var FOCUSABLE = 'input:not([type="hidden"]):not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="image"]), select, textarea, [role="combobox"], [contenteditable="true"]';
  function usable(el) {
    const e = el;
    if (e.disabled || e.readOnly || el.getAttribute("aria-hidden") === "true" || el.closest('[hidden], [aria-hidden="true"]')) return false;
    const r = el.getBoundingClientRect?.();
    return !r || r.width > 0 || r.height > 0 || !el.ownerDocument.defaultView?.innerWidth;
  }
  function fillableBoxes(doc) {
    const seenRadio = /* @__PURE__ */ new Set();
    const out = [];
    for (const el of doc.querySelectorAll(FOCUSABLE)) {
      if (!usable(el)) continue;
      if (el.matches("input") && el.parentElement?.closest('[role="combobox"]') && !el.matches('[role="combobox"]')) continue;
      if ((el.getAttribute("type") ?? "").toLowerCase() === "radio") {
        const name = el.getAttribute("name") ?? "";
        if (seenRadio.has(name)) continue;
        seenRadio.add(name);
      }
      out.push(el);
    }
    return out;
  }
  function nextBox(el) {
    const boxes = fillableBoxes(el.ownerDocument);
    const host = el.matches("input") ? el.closest('[role="combobox"]') ?? el : el;
    const radioName = (host.getAttribute("type") ?? "").toLowerCase() === "radio" ? host.getAttribute("name") : null;
    const i = boxes.findIndex((b) => b === host || radioName != null && b.getAttribute("name") === radioName);
    if (i >= 0) return boxes[i + 1] ?? null;
    return boxes.find(
      (b) => host.compareDocumentPosition(b) & 4
      /* DOCUMENT_POSITION_FOLLOWING */
    ) ?? null;
  }

  // src/save-guard.ts
  var FINAL_WORDING = /\bsubmit|i'?m done|\bdone\b|\bcertif|\bfinali[sz]e|\bsign\b|\battest|\bagree|\bpay\b/i;
  function controlLabel(el) {
    const attr = (n) => el.getAttribute?.(n) ?? "";
    return [el.value, el.textContent, attr("aria-label"), attr("title"), attr("alt")].filter((s) => typeof s === "string" && s.trim()).join(" ").replace(/\s+/g, " ").trim();
  }
  function saveButtonRefusal(el) {
    const label = controlLabel(el);
    if (!label) return "a button with no label";
    if (FINAL_WORDING.test(label)) return `"${label.slice(0, 60)}"`;
    if (!/save/i.test(label)) return `"${label.slice(0, 60)}", which is not a Save button`;
    return null;
  }
  function pressSaveLater(el, delayMs = 50) {
    setTimeout(() => {
      if (!saveButtonRefusal(el)) el.click();
    }, delayMs);
  }

  // src/stars/fill.ts
  var STARS_TIMING = { stepMs: 100, listMs: 4e3, postbackMs: 8e3, settleMs: 1500, quietMs: 700 };
  var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
  var text2 = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  var ID = (name) => `ctl00_mainContent_${name}`;
  var StarsStop = class extends Error {
  };
  function fire2(el, type) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = (type.startsWith("mouse") || type === "click" ? view.MouseEvent : type.startsWith("focus") || type === "blur" ? view.FocusEvent : view.Event) ?? view.Event ?? Event;
    el.dispatchEvent(new Ctor(type, { bubbles: type !== "focus" && type !== "blur", cancelable: true }));
  }
  async function until(probe, ms, what) {
    const start = Date.now();
    for (; ; ) {
      const v = probe();
      if (v) return v;
      if (Date.now() - start >= ms) throw new StarsStop(what);
      await sleep2(STARS_TIMING.stepMs);
    }
  }
  function starsPageKind(loc) {
    if (/\/srt\/EnterInternationalCoursework(?:-yr-\d{4})?\.aspx$/i.test(loc.pathname)) return "intl";
    if (/\/srt\/EnterCoursework(?:-yr-\d{4})?\.aspx$/i.test(loc.pathname)) return "us";
    return null;
  }
  function starsPageYear(loc) {
    if (!starsPageKind(loc)) return null;
    const yr = Number(new URLSearchParams(loc.search).get("yr"));
    return Number.isInteger(yr) && yr > 1990 ? yr : null;
  }
  function starsExistingNames(doc) {
    const headers = [...doc.querySelectorAll("th")].map((th) => text2(th));
    const col = headers.findIndex((h) => h === "Course/Exam Name" || h === "Course Name");
    if (col < 0) return [];
    const table2 = doc.querySelectorAll("th")[col].closest("table");
    return [...table2.querySelectorAll("tr")].flatMap((tr) => {
      const cells = tr.querySelectorAll("td");
      return cells.length > col && tr.querySelector('input[name$="delId"]') ? [text2(cells[col])] : [];
    });
  }
  function radValue(doc, name) {
    return doc.getElementById(`${ID(name)}_Input`)?.value ?? "";
  }
  async function quiet(doc) {
    const root = doc.getElementById("aspnetForm") ?? doc.body;
    const View = doc.defaultView ?? globalThis;
    if (!View.MutationObserver || !root) return sleep2(STARS_TIMING.quietMs);
    let last2 = Date.now();
    const obs = new View.MutationObserver(() => last2 = Date.now());
    obs.observe(root, { childList: true, subtree: true, attributes: true });
    const start = Date.now();
    try {
      while (Date.now() - last2 < STARS_TIMING.quietMs && Date.now() - start < STARS_TIMING.postbackMs) await sleep2(STARS_TIMING.stepMs);
    } finally {
      obs.disconnect();
    }
  }
  async function pickRad(doc, name, value, label) {
    const box = doc.getElementById(ID(name));
    if (!box) throw new StarsStop(`STARS's ${label} box is not on the page`);
    if (radValue(doc, name) === value) return;
    const arrow = box.querySelector(".rcbActionButton, .rcbArrowCell a");
    if (arrow) {
      fire2(arrow, "mousedown");
      arrow.click();
    }
    const li = await until(
      () => [...doc.querySelectorAll(`#${ID(name)}_DropDown li`)].find((l) => text2(l) === value),
      // A list that depends on an earlier pick (titles after the subject) can take a whole page update to arrive.
      STARS_TIMING.postbackMs,
      `"${value}" is not in STARS's ${label} list`
    ).catch((e) => {
      throw new StarsStop(e instanceof Error ? e.message : String(e));
    });
    fire2(li, "mouseover");
    fire2(li, "mousedown");
    li.click();
    await until(() => radValue(doc, name) === value, STARS_TIMING.postbackMs, `STARS did not take "${value}" for ${label}`);
    await quiet(doc);
  }
  function typeRad(doc, name, value) {
    const input = doc.getElementById(ID(name));
    if (!input) throw new StarsStop(`STARS's ${name} box is not on the page`);
    input.focus?.();
    fire2(input, "focus");
    input.value = value;
    fire2(input, "input");
    fire2(input, "change");
    fire2(input, "blur");
    fire2(input, "focusout");
  }
  async function fillStarsCourse(doc, row, scale, language = null) {
    const blanks = [];
    const yearGpa = doc.getElementById(ID("year_gpa"));
    const noGpa = doc.getElementById("no_annual_gpa");
    if (yearGpa && !yearGpa.value.trim() && !noGpa?.checked) {
      throw new StarsStop(`STARS needs this year's GPA first: type it at the top of the page (or tick "I have not received an annual GPA" if that is true), then run again`);
    }
    const picks = [];
    if (row.academicLevel) picks.push({ name: "academic_level", value: row.academicLevel, label: "Courses/Exams Were Taken in" });
    picks.push({ name: "subject_area", value: row.subject, label: "Subject Area" }, { name: "course_cd", value: row.title, label: "Course/Exam Content" });
    if (row.level) picks.push({ name: "course_level", value: row.level, label: "Proficiency Level" });
    else blanks.push("Proficiency Level");
    if (doc.getElementById(ID("course_language"))) {
      const shown = radValue(doc, "course_language");
      if (!shown || /^--/.test(shown)) {
        if (language) picks.push({ name: "course_language", value: language, label: "Language of Instruction" });
        else blanks.push("Language of Instruction");
      } else picks.push({ name: "course_language", value: shown, label: "Language of Instruction" });
    }
    picks.push({ name: "term", value: row.length, label: "Course Length" });
    for (const p of picks) await pickRad(doc, p.name, p.value, p.label);
    await until(() => doc.getElementById(`${ID("grade_1")}_Input`), STARS_TIMING.postbackMs, "STARS did not show the grade boxes");
    if (doc.getElementById(ID("grade_scale_id"))) {
      if (scale) {
        picks.push({ name: "grade_scale_id", value: scale, label: "Grading Scale" });
        await pickRad(doc, "grade_scale_id", scale, "Grading Scale");
      } else blanks.push("Grading Scale");
    }
    for (const [i, box] of row.boxes.entries()) {
      if (!doc.getElementById(`${ID(`grade_${i + 1}`)}_Input`)) throw new StarsStop(`STARS shows fewer grade boxes than this course has terms (${row.boxes.length})`);
      if (!box.grade) blanks.push(`Grade ${i + 1}`);
    }
    await fillTail(doc, row);
    if (blanks.some((b) => b === "Grading Scale" || b === "Proficiency Level" || b === "Language of Instruction" || b.startsWith("Grade "))) return { saved: false, blanks };
    for (let round = 0; ; round++) {
      await sleep2(STARS_TIMING.settleMs);
      await quiet(doc);
      const wrongPicks = picks.filter((p) => radValue(doc, p.name) !== p.value);
      const wrong = [...wrongPicks.map((p) => p.label), ...wrongTail(doc, row)];
      if (!wrong.length) break;
      if (round === 2) throw new StarsStop(`STARS kept resetting ${wrong.join(", ")}; nothing was saved for this course`);
      for (const p of wrongPicks) await pickRad(doc, p.name, p.value, p.label);
      await fillTail(doc, row);
    }
    pressStarsSave(doc);
    return { saved: true, blanks };
  }
  function pressStarsSave(doc) {
    const save = doc.getElementById(ID("btn_submit"));
    if (!save) throw new StarsStop("STARS's Save Course button is not on the page");
    const why = saveButtonRefusal(save);
    if (why) throw new StarsStop(`Refused to press ${why}: the extension only presses Save Course on STARS and never submits anything`);
    pressSaveLater(save);
  }
  async function fillTail(doc, row) {
    for (const [i, box] of row.boxes.entries()) if (box.grade) await pickRad(doc, `grade_${i + 1}`, box.grade, `Grade ${i + 1}`);
    for (const [i, box] of row.boxes.entries()) if (box.credit != null) typeRad(doc, `units_${i + 1}`, box.credit);
    typeRad(doc, "exact_course_title", row.name);
    await quiet(doc);
  }
  function wrongTail(doc, row) {
    const out = [];
    for (const [i, box] of row.boxes.entries()) {
      if (box.grade && radValue(doc, `grade_${i + 1}`) !== box.grade) out.push(`grade ${i + 1}`);
      const shown = doc.getElementById(ID(`units_${i + 1}`))?.value ?? "";
      if (box.credit != null && Number(shown) !== Number(box.credit)) out.push(`credit ${i + 1}`);
    }
    if (doc.getElementById(ID("exact_course_title"))?.value !== row.name) out.push("course name");
    return out;
  }
  function starsErrors(doc) {
    const out = [];
    for (const el of doc.querySelectorAll('[id^="ctl00_mainContent_v_"], .rwDialog')) {
      const t = text2(el);
      const r = el.getBoundingClientRect?.();
      if (t && (!r || r.height > 0)) out.push(el.id.startsWith("ctl00_mainContent_v_") ? `${el.id.slice("ctl00_mainContent_v_".length)}: ${t}` : t.slice(0, 200));
    }
    return out;
  }

  // src/sites.ts
  var SITE_ORIGINS = {
    common_app: ["https://apply.commonapp.org"],
    uc: ["https://apply.universityofcalifornia.edu"],
    stars: ["https://srar.selfreportedtranscript.com"],
    csu: ["https://calstate.cas.myliaison.com", "https://calstate.liaisoncas.com"],
    uiuc: ["https://myillini.illinois.edu"],
    ut: ["https://utdirect.utexas.edu", "https://mystatus.admissions.utexas.edu", "https://admissions.utexas.edu"]
  };

  // ../web/lib/csu-labels.ts
  var csuGradeLevelLabel = (n) => `${n}th Grade`;
  var csuGradeLevelOption = (r) => `${csuGradeLevelLabel(r.gradeLevel)} \u2022 ${r.year}`;

  // ../web/lib/school-match.ts
  var ABBR = {
    intl: "international",
    int: "international",
    sch: "school",
    schl: "school",
    hs: "high school",
    acad: "academy",
    acd: "academy",
    cmp: "campus",
    camp: "campus",
    cmps: "campus",
    st: "saint",
    ste: "sainte",
    mt: "mount",
    jr: "junior",
    sr: "senior",
    sci: "science",
    tech: "technology",
    inst: "institute",
    univ: "university",
    coll: "college",
    prep: "preparatory",
    ctr: "center",
    centre: "center",
    elem: "elementary",
    sec: "secondary",
    natl: "national",
    ms: "middle school",
    bil: "bilingual",
    amer: "american",
    ctry: "country",
    co: "county",
    cty: "county",
    dist: "district",
    isd: "independent school district"
  };
  var STOP = /* @__PURE__ */ new Set(["the", "of", "and", "at", "a", "an", "in", "for", "de", "la", "le"]);
  function schoolWords(name) {
    const out = [];
    const raw = name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/&/g, " and ").replace(/\bh\.\s?s\./g, " hs ").replace(/['\u2019]/g, "").replace(/[^a-z0-9\u3400-\u9fff]+/g, " ").split(" ").filter(Boolean);
    for (const w of raw) for (const x of (ABBR[w] ?? w).split(" ")) if (!STOP.has(x)) out.push(x);
    return out;
  }
  function sameWord(a, b) {
    if (a === b) return true;
    if (Math.min(a.length, b.length) < 5 || Math.abs(a.length - b.length) > 1) return false;
    let i = 0;
    let j = 0;
    let edits = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) {
        i++;
        j++;
        continue;
      }
      if (++edits > 1) return false;
      if (a.length > b.length) i++;
      else if (b.length > a.length) j++;
      else {
        i++;
        j++;
      }
    }
    return edits + (a.length - i) + (b.length - j) <= 1;
  }
  var shared = (a, b) => a.filter((w) => b.some((x) => sameWord(w, x))).length;
  function schoolNameScore(a, b) {
    const wa = [...new Set(schoolWords(a))];
    const wb = [...new Set(schoolWords(b))];
    if (!wa.length || !wb.length) return 0;
    if (wa.join("") === wb.join("")) return 1;
    const both = shared(wa, wb);
    const small = Math.min(wa.length, wb.length);
    const big = Math.max(wa.length, wb.length);
    const ca = wa.join("");
    const cb = wb.join("");
    if (both === small && (small >= 2 || big === 1)) return 0.9 + 0.1 * (small / big);
    if (Math.min(ca.length, cb.length) >= 8 && (ca.includes(cb) || cb.includes(ca))) return 0.88;
    return 0.85 * (2 * both / (wa.length + wb.length));
  }
  var SAME_SCHOOL = 0.75;
  var codeKey = (c) => (c ?? "").toUpperCase().replace(/[\s-]+/g, "");
  function sameSchoolCode(a, b) {
    const ka = codeKey(a);
    return ka !== "" && ka === codeKey(b);
  }
  function codeInText(code, text6) {
    const k = codeKey(code);
    if (!k) return false;
    return new RegExp(`(^|[^A-Za-z0-9])${k.replace(/[^A-Z0-9]/g, "")}($|[^A-Za-z0-9])`, "i").test(text6);
  }
  function bestSchoolMatch(options2, school, view) {
    const norm = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
    const exact = options2.filter((o) => norm(view(o).name) === norm(school.name));
    if (exact.length === 1) return exact[0];
    if (school.code) {
      const byCode = options2.filter((o) => sameSchoolCode(view(o).code, school.code));
      if (byCode.length === 1) return byCode[0];
    }
    const scored = options2.map((o) => ({ o, s: schoolNameScore(view(o).name, school.name) })).sort((x, y) => y.s - x.s);
    const top = scored[0];
    if (!top || top.s < SAME_SCHOOL) return null;
    if (scored[1] && scored[1].s >= top.s - 0.02) return null;
    return top.o;
  }
  function schoolOnPage(items, pageText, view) {
    const byCode = items.filter((o) => codeInText(view(o).code, pageText));
    if (byCode.length === 1) return byCode[0];
    const page = new Set(schoolWords(pageText));
    const words2 = [...page];
    const hits = items.map((o) => {
      const w = [...new Set(schoolWords(view(o).name))];
      return { o, n: w.length, all: w.length > 0 && w.every((x) => page.has(x) || words2.some((p) => sameWord(p, x))) };
    }).filter((h) => h.all).sort((a, b) => b.n - a.n);
    if (!hits.length) return null;
    if (hits[1] && hits[1].n === hits[0].n) return null;
    return hits[0].o;
  }

  // src/csu/fill.ts
  var CSU_TIMING = { stepMs: 100, listMs: 4e3, drawerMs: 8e3 };
  var sleep3 = (ms) => new Promise((r) => setTimeout(r, ms));
  var text3 = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  var same = (a, b) => a.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim() === b.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  var CsuStop = class extends Error {
  };
  function fire3(el, type, init = {}) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = (type.startsWith("mouse") || type === "click" ? view.MouseEvent : type.startsWith("key") ? view.KeyboardEvent : view.Event) ?? view.Event ?? Event;
    el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, ...init }));
  }
  async function until2(probe, ms, what) {
    const start = Date.now();
    for (; ; ) {
      const v = probe();
      if (v) return v;
      if (Date.now() - start >= ms) throw new CsuStop(what);
      await sleep3(CSU_TIMING.stepMs);
    }
  }
  function setReactValue(input, value) {
    const view = input.ownerDocument.defaultView ?? globalThis;
    const setter = Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, "value")?.set;
    if (setter) setter.call(input, value);
    else input.value = value;
    fire3(input, "input");
  }
  function topDrawer(doc) {
    const drawers = [...doc.querySelectorAll(".MuiDrawer-root")].filter((d) => !/cky/.test(d.className));
    return drawers[drawers.length - 1] ?? null;
  }
  function onCourseworkPage(doc) {
    return [...doc.querySelectorAll("main h1, main h2, h1, h2")].some((h) => text3(h) === "High School Coursework");
  }
  function schoolButton(doc, schoolName, schoolCode) {
    const buttons = [...doc.querySelectorAll("main button")].filter((b) => /^(add course|\d+ courses?)$/i.test(text3(b)));
    const cardText = (b) => {
      let el = b;
      for (let i = 0; i < 6 && el?.parentElement; i++) {
        const up = el.parentElement;
        if (buttons.some((o) => o !== b && up.contains(o))) break;
        el = up;
      }
      const parts = [];
      const walk = (n) => n.nodeType === 3 ? parts.push(n.textContent ?? "") : n.childNodes.forEach(walk);
      if (el) walk(el);
      return parts.join(" ").replace(/\s+/g, " ").trim();
    };
    const byCode = schoolCode ? buttons.filter((b) => codeInText(schoolCode, cardText(b))) : [];
    if (byCode.length === 1) return byCode[0];
    const named = bestSchoolMatch(buttons, { name: schoolName }, (b) => ({ name: cardText(b) }));
    if (named) return named;
    if (buttons.length === 1) return buttons[0];
    throw new CsuStop(`Could not tell which school on Cal State Apply is "${schoolName}". Add courses for that school by hand, or add its school code in the tracker.`);
  }
  async function existingTitles(doc, schoolName, schoolCode) {
    const btn = schoolButton(doc, schoolName, schoolCode);
    if (/^add course$/i.test(text3(btn))) return [];
    btn.click();
    const drawer = await until2(() => {
      const d = topDrawer(doc);
      return d && /High School Courses/.test(text3(d)) ? d : null;
    }, CSU_TIMING.drawerMs, "Cal State Apply did not open the school's course list");
    return [...drawer.querySelectorAll("tr")].flatMap((tr) => {
      const cells = tr.querySelectorAll("td");
      return cells.length ? [text3(cells[0])] : [];
    });
  }
  var options = (input) => {
    const doc = input.ownerDocument;
    const box = doc.getElementById(input.getAttribute("aria-controls") || `${input.id}-listbox`);
    return box ? [...box.querySelectorAll('[role="option"]')] : [];
  };
  async function openAuto(input, label) {
    const start = Date.now();
    for (let tries = 0; ; tries++) {
      if (tries % 6 === 0) {
        input.blur();
        input.focus();
        fire3(input, "mousedown");
      }
      const o = options(input);
      if (o.length) return o;
      if (Date.now() - start >= CSU_TIMING.listMs) throw new CsuStop(`Cal State Apply's ${label} list did not open`);
      await sleep3(CSU_TIMING.stepMs);
    }
  }
  async function pickAuto(input, value, label, action = false) {
    await openAuto(input, label);
    const option = await until2(() => options(input).find((o) => same(text3(o), value)), CSU_TIMING.listMs, `"${value}" is not in Cal State Apply's ${label} list`);
    option.click();
    if (action) return;
    await until2(() => same(input.value, value) || input.value.length > 0, CSU_TIMING.listMs, `Cal State Apply did not take "${value}" for ${label}`);
  }
  function field(drawer, id, label) {
    const el = drawer.querySelector(`[id="${id}"]`);
    if (!el) throw new CsuStop(`Cal State Apply's ${label} box is not in the form`);
    return el;
  }
  function drawerButton(drawer, label) {
    const b = [...drawer.querySelectorAll("button")].find((x) => same(text3(x), label));
    if (!b) throw new CsuStop(`Cal State Apply's ${label} button is not in the form`);
    return b;
  }
  async function addGradeLevel(doc, row) {
    const course = topDrawer(doc);
    await pickAuto(field(course, "gradeLevelId", "Grade Level"), "Add Grade Level", "Grade Level", true);
    const sub = await until2(() => {
      const d = topDrawer(doc);
      return d && d.querySelector('[id="yearId"]') ? d : null;
    }, CSU_TIMING.drawerMs, "Cal State Apply did not open the Add Grade Level form");
    await pickAuto(field(sub, "gradeLevelId", "Grade Level"), csuGradeLevelLabel(row.gradeLevel), "Grade Level");
    await pickAuto(field(sub, "yearId", "Year"), row.year, "Year");
    const summer = sub.querySelector('[id="includeSummer"]');
    if (row.summer && summer && !summer.checked) summer.click();
    drawerButton(sub, "Save").click();
    await until2(() => !topDrawer(doc)?.querySelector('[id="yearId"]'), CSU_TIMING.drawerMs, "Cal State Apply did not save the grade level");
  }
  async function fillCsuCourse(doc, row) {
    const drawer = await until2(() => {
      const d = topDrawer(doc);
      return d && d.querySelector('[id="gradeLevelId"]') && !d.querySelector('[id="yearId"]') ? d : null;
    }, CSU_TIMING.drawerMs, "Cal State Apply did not open the course form");
    if (row.summer) throw new CsuStop(`${row.name} is a summer course: Cal State Apply's summer grade levels were not seen yet, so add it by hand`);
    const levelOption = csuGradeLevelOption(row);
    const gl = field(drawer, "gradeLevelId", "Grade Level");
    const has = (await openAuto(gl, "Grade Level")).some((o) => same(text3(o), levelOption));
    fire3(gl, "keydown", { key: "Escape" });
    await sleep3(200);
    if (!has) await addGradeLevel(doc, row);
    const form = topDrawer(doc);
    await pickAuto(field(form, "gradeLevelId", "Grade Level"), levelOption, "Grade Level");
    const title = field(form, "courseName", "Course Title");
    title.focus();
    setReactValue(title, row.name);
    const echo = await until2(() => options(title).find((o) => same(text3(o), row.name)), CSU_TIMING.listMs, `Cal State Apply did not offer the title "${row.name}"`);
    echo.click();
    const boxes = [...form.querySelectorAll('input[id^="highSchoolCourseGrades."]')];
    if (boxes.length !== row.grades.length) throw new CsuStop(`Cal State Apply shows ${boxes.length} grade boxes; the tracker has ${row.grades.length} terms for ${row.name}. Check the school's Term Type`);
    const blanks = [];
    for (const [i, g] of row.grades.entries()) {
      const label = text3(form.querySelector(`label[for="${boxes[i].id}"]`)) || `term ${i + 1}`;
      if (g == null) blanks.push(`${label} grade`);
      else await pickAuto(boxes[i], g, `${label} grade`);
    }
    if (blanks.length) return { blanks };
    const radio = [...form.querySelectorAll('input[name="courseTypeLkupId"]')].find((r) => same(text3(r.closest("label")), row.courseType));
    if (!radio) throw new CsuStop(`Cal State Apply has no Course Type "${row.courseType}"`);
    radio.click();
    if (!radio.checked) radio.closest("label")?.click();
    await until2(() => radio.checked, CSU_TIMING.listMs, `Cal State Apply did not take Course Type "${row.courseType}"`);
    drawerButton(form, "Save").click();
    await until2(() => topDrawer(doc) !== form || !form.isConnected || !form.querySelector('[id="courseName"]'), CSU_TIMING.drawerMs, `Cal State Apply did not save ${row.name} (a required box may be empty)`);
    return { blanks };
  }
  async function openCourseForm(doc, schoolName, schoolCode) {
    const top = topDrawer(doc);
    if (top && /High School Courses/.test(text3(top))) {
      drawerButton(top, "Add Course").click();
    } else {
      schoolButton(doc, schoolName, schoolCode).click();
      await sleep3(500);
      const d = topDrawer(doc);
      if (d && /High School Courses/.test(text3(d))) drawerButton(d, "Add Course").click();
    }
    await until2(() => topDrawer(doc)?.querySelector('[id="courseName"], [id="gradeLevelId"]'), CSU_TIMING.drawerMs, "Cal State Apply did not open the course form");
  }

  // src/csu/run.ts
  var key = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  async function runCsuSchool(doc, plan, shouldStop) {
    const added = [];
    let have;
    try {
      have = await existingTitles(doc, plan.schoolName, plan.schoolCode);
    } catch (e) {
      return { added, skippedExisting: 0, stopped: e.message };
    }
    const left = /* @__PURE__ */ new Map();
    for (const n of have) left.set(key(n), (left.get(key(n)) ?? 0) + 1);
    const todo = plan.rows.filter((r) => {
      const n = left.get(key(r.name)) ?? 0;
      if (n > 0) left.set(key(r.name), n - 1);
      return n === 0;
    });
    for (const row of todo) {
      if (shouldStop()) return { added, skippedExisting: plan.rows.length - todo.length, stopped: "Stopped." };
      try {
        await openCourseForm(doc, plan.schoolName, plan.schoolCode);
        const { blanks } = await fillCsuCourse(doc, row);
        if (blanks.length) {
          return { added, skippedExisting: plan.rows.length - todo.length, stopped: `${row.name} is filled in but not saved: choose ${blanks.join(", ")} and press Save, then run again.` };
        }
        const now = await existingTitles(doc, plan.schoolName, plan.schoolCode);
        if (now.filter((n) => key(n) === key(row.name)).length <= have.filter((n) => key(n) === key(row.name)).length) {
          return { added, skippedExisting: plan.rows.length - todo.length, stopped: `Cal State Apply did not list ${row.name} after saving. Check the form for a message.` };
        }
        have = now;
        added.push(row.name);
      } catch (e) {
        const msg = e instanceof CsuStop || e instanceof Error ? e.message : String(e);
        return { added, skippedExisting: plan.rows.length - todo.length, stopped: `${row.name}: ${msg}. ${topDrawer(doc) ? "The form is left open: finish or cancel it." : ""}`.trim() };
      }
    }
    return { added, skippedExisting: plan.rows.length - todo.length, stopped: null };
  }

  // ../web/lib/course-names.ts
  var ROMAN = { i: "1", ii: "2", iii: "3", iv: "4", v: "5", vi: "6" };
  function words(name) {
    return name.normalize("NFKC").toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, " ").split(" ").filter(Boolean).map((w) => ROMAN[w] ?? w);
  }
  var dropGrade = (w) => w.length > 1 && /^(9|10|11|12)$/.test(w[w.length - 1]) ? w.slice(0, -1) : w;
  function oneEdit(a, b) {
    if (Math.abs(a.length - b.length) > 1) return false;
    let i = 0;
    let j = 0;
    let edits = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) {
        i++;
        j++;
        continue;
      }
      if (++edits > 1) return false;
      if (a.length > b.length) i++;
      else if (b.length > a.length) j++;
      else {
        i++;
        j++;
      }
    }
    return edits + (a.length - i) + (b.length - j) <= 1;
  }
  function sameCourseName(a, b) {
    const wa = words(a);
    const wb = words(b);
    if (!wa.length || !wb.length) return false;
    const ja = wa.join(" ");
    const jb = wb.join(" ");
    if (ja === jb) return true;
    if (dropGrade(wa).join(" ") === dropGrade(wb).join(" ")) return true;
    return Math.min(ja.length, jb.length) >= 8 && oneEdit(ja, jb) && !/\d/.test(diffChar(ja, jb));
  }
  function diffChar(a, b) {
    let i = 0;
    while (i < a.length && a[i] === b[i]) i++;
    return (a[i] ?? "") + (b[i] ?? "");
  }

  // src/uc/fill.ts
  var UC_TIMING = { stepMs: 100, rowMs: 5e3 };
  var sleep4 = (ms) => new Promise((r) => setTimeout(r, ms));
  var key2 = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  var P = (i, f) => `academics_hs_classes_add_${i}_${f}`;
  var UcStop = class extends Error {
  };
  function fire4(el, type) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = view.Event ?? Event;
    el.dispatchEvent(new Ctor(type, { bubbles: true }));
  }
  function ucPageGrade(loc) {
    const m = loc.pathname.match(/\/acadHistFrHighSchoolClasses\/editClasses\/(\d{2})\//);
    return m ? Number(m[1]) : null;
  }
  function ucRowIndexes(doc) {
    return [...doc.querySelectorAll('select[id^="academics_hs_classes_add_"][id$="_subject"]')].map((s) => Number(s.id.slice("academics_hs_classes_add_".length).split("_")[0])).filter((n) => Number.isInteger(n));
  }
  var titleOf = (doc, i) => (doc.getElementById(P(i, "class_title"))?.value ?? "").trim();
  var subjectOf = (doc, i) => doc.getElementById(P(i, "subject"))?.value ?? "";
  function ucExistingNames(doc) {
    return ucRowIndexes(doc).map((i) => titleOf(doc, i)).filter(Boolean);
  }
  function pick(doc, id, want, label) {
    const sel = doc.getElementById(id);
    if (!sel) throw new UcStop(`UC's ${label} box is not on the page`);
    const opts = [...sel.options];
    const i = want.value != null ? opts.findIndex((o) => o.value === want.value) : opts.findIndex((o) => key2(o.text) === key2(want.text));
    if (i < 0) throw new UcStop(`"${want.text}" is not in UC's ${label} list`);
    sel.selectedIndex = i;
    fire4(sel, "input");
    fire4(sel, "change");
  }
  async function emptyRow(doc) {
    const free = ucRowIndexes(doc).find((i) => !titleOf(doc, i) && !subjectOf(doc, i));
    if (free != null) return free;
    const before = ucRowIndexes(doc).length;
    const add = doc.getElementById("addManualHSClass");
    if (!add) throw new UcStop("UC's Add another course link is not on the page");
    add.click();
    const start = Date.now();
    while (ucRowIndexes(doc).length <= before) {
      if (Date.now() - start > UC_TIMING.rowMs) throw new UcStop("UC did not add a course row");
      await sleep4(UC_TIMING.stepMs);
    }
    return ucRowIndexes(doc).find((i) => !titleOf(doc, i) && !subjectOf(doc, i));
  }
  function fillRow(doc, i, row) {
    pick(doc, P(i, "subject"), row.discipline, "Subject Area/Course Category");
    const title = doc.getElementById(P(i, "class_title"));
    if (!title) throw new UcStop("UC's Course Name box is not on the page");
    title.focus?.();
    title.value = row.name;
    fire4(title, "input");
    fire4(title, "change");
    title.blur?.();
    pick(doc, P(i, "honors"), { text: row.honors }, "Honor Type");
    for (const [n, g] of row.grades.entries()) pick(doc, P(i, `grade${n + 1}`), { text: g }, `Grade ${n + 1}`);
    const extra = doc.getElementById(P(i, `grade${row.grades.length + 1}`));
    if (extra && extra.offsetParent !== null && extra.getClientRects().length > 0) throw new UcStop(`UC shows more grade boxes than the tracker has terms for ${row.name}: check the school's term system on UC`);
    if (row.language) pick(doc, P(i, "subject_language_code"), { text: row.language }, "Language");
  }
  async function fillUcPage(doc, plan) {
    const have = ucExistingNames(doc);
    const added = [];
    const left = [];
    let skippedExisting = 0;
    for (const row of plan.rows) {
      const at = have.findIndex((n) => sameCourseName(n, row.name));
      if (at >= 0) {
        have.splice(at, 1);
        skippedExisting++;
        continue;
      }
      if (!row.discipline || row.grades.some((g) => g == null) || row.language === null && row.discipline.area === "Language Other Than English") {
        left.push(row.name);
        continue;
      }
      const i = await emptyRow(doc);
      fillRow(doc, i, row);
      added.push(row.name);
    }
    if (!added.length) return { added, skippedExisting, left, saving: false };
    pressUcSave(doc);
    return { added, skippedExisting, left, saving: true };
  }
  function pressUcSave(doc) {
    const save = doc.getElementById("save");
    if (!save) throw new UcStop("UC's Save & continue button is not on the page");
    const why = saveButtonRefusal(save);
    if (why) throw new UcStop(`Refused to press ${why}: the extension only presses Save & continue on UC and never submits anything`);
    pressSaveLater(save);
  }
  function ucSummaryNames(doc) {
    const table2 = [...doc.querySelectorAll("table")].find((t) => [...t.querySelectorAll("th")].some((th) => key2(th.textContent ?? "") === "course name"));
    if (!table2) return [];
    const col = [...table2.querySelectorAll("th")].findIndex((th) => key2(th.textContent ?? "") === "course name");
    return [...table2.querySelectorAll("tr")].flatMap((tr) => {
      const td = tr.querySelectorAll("td");
      return td.length > col ? [(td[col].textContent ?? "").trim()] : [];
    });
  }

  // src/stars/nav.ts
  var decode = (s) => s.replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n))).replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  function starsSchools(html) {
    const out = [];
    for (const a of html.matchAll(/<a\b[^>]*>/g)) {
      const tag = a[0];
      const ceeb = tag.match(/goStep\(\s*'ceeb'\s*,\s*'([^']+)'\s*\)/)?.[1];
      const name = tag.match(/title="Enter Coursework taken at ([^"]*)"/)?.[1];
      if (ceeb && name && !out.some((s) => s.ceeb === ceeb)) out.push({ ceeb, name: decode(name).trim() });
    }
    return out;
  }
  function starsYears(html, ceeb) {
    const out = [];
    for (const m of html.matchAll(/openCourseEntry\(\s*'([^']+)'\s*,\s*'(\d{4})'\s*(?:,\s*'([^']*)')?\s*\)/g)) {
      if (m[1] !== ceeb || out.some((y) => y.year === Number(m[2]))) continue;
      out.push({ year: Number(m[2]), label: decode(m[3] ?? "") });
    }
    return out;
  }
  function starsYearPath(html, ceeb, year) {
    const y = starsYears(html, ceeb).find((x) => x.year === year);
    if (!y) return null;
    const start = html.search(/function\s+openCourseEntry\s*\(\s*ceeb\s*,\s*yr\s*,\s*ms\s*\)/);
    if (start < 0) return null;
    const end = html.indexOf("function ", start + 10);
    const body = html.slice(start, end < 0 ? void 0 : end);
    const urls = [...body.matchAll(/course_url\s*=\s*"([A-Za-z0-9_.-]+\.aspx)"/g)];
    const page = urls[urls.length - 1]?.[1];
    if (!page || !/noWin\s*=\s*true/.test(body)) return null;
    const ms = y.label.toUpperCase();
    const add = y.label === "Middle School" ? "&ms=Y" : ms.includes("9TH") ? "&gl=09" : ms.includes("10TH") ? "&gl=10" : ms.includes("11TH") ? "&gl=11" : ms.includes("12TH") ? "&gl=12" : "";
    const c = encodeURIComponent(ceeb);
    return `/srt/${page}?selCeeb=${c}&yr=${year}&sel_sender_ceeb=${c}${add}`;
  }
  var starsSummaryPath = (ceeb) => `/srt/SchoolSummary.aspx?sel_sender_ceeb=${encodeURIComponent(ceeb)}`;

  // src/uc/nav.ts
  var text4 = (el) => {
    const parts = [];
    const walk = (n) => n.nodeType === 3 ? parts.push(n.textContent ?? "") : n.childNodes.forEach(walk);
    if (el) walk(el);
    return parts.join(" ").replace(/\s+/g, " ").trim();
  };
  function ucCoursesButtons(doc, grade) {
    const nn = String(grade).padStart(2, "0");
    const opens = (el) => /^(enter courses|edit)\b/i.test(text4(el)) && !/acadHistFrInfo/i.test(el.getAttribute("href") ?? "");
    const byId = [...doc.querySelectorAll(`[id^="edit_${nn}"]`)].filter((el) => /^edit_\d+$/.test(el.id) && opens(el));
    if (byId.length) return byId;
    return [...doc.querySelectorAll("a, button")].filter((el) => {
      if (!opens(el)) return false;
      if (/^enter courses/i.test(text4(el))) return true;
      for (let up = el.parentElement, i = 0; up && i < 3; up = up.parentElement, i++) {
        const t = text4(up);
        if (/School code/i.test(t)) return false;
        if (/\d{4}\s*-\s*\d{4} academic year/i.test(t)) return true;
      }
      return false;
    });
  }
  function ucClassesLink(doc, grade, school) {
    const links = ucCoursesButtons(doc, grade);
    if (!links.length) return `UC shows no ${grade}th grade school year to enter courses for: check that ${grade}th grade is added to the school under Academic history (then run again)`;
    if (links.length === 1) return links[0];
    const card = (a) => {
      let el = a;
      while (el.parentElement && !links.some((o) => o !== a && el.parentElement.contains(o))) el = el.parentElement;
      return text4(el);
    };
    const hits = links.filter((a) => schoolOnPage([school], card(a), (s) => s) !== null);
    return hits.length === 1 ? hits[0] : `UC lists several schools for ${grade}th grade and the tracker's "${school.name}" matches ${hits.length ? "more than one" : "none"} of them: add the school code in the tracker`;
  }

  // ../web/lib/transcript.ts
  var PERIOD_TYPES = ["full_year", "semester", "trimester", "quarter"];
  var LEVELS = [
    "regular",
    "accelerated",
    "advanced",
    "honors",
    "high_honors",
    "ap",
    "ib_hl",
    "ib_sl",
    "ib",
    "pre_ib",
    "a_level",
    "gcse_igcse",
    "college_prep",
    "dual_enrollment",
    "enriched",
    "gifted",
    "intensive",
    "regents",
    "other",
    "none"
  ];
  var SUBJECTS = ["english", "mathematics", "science", "history_social", "world_language", "arts", "computer_science", "business", "pe_health", "career_technical", "other"];

  // ../web/lib/transcript-maps/types.ts
  var verified = (value, source, note) => ({ value, status: "verified", ...source ? { source } : {}, ...note ? { note } : {} });
  var unverified = (value, note, source) => ({ value, status: "unverified", ...note ? { note } : {}, ...source ? { source } : {} });
  var none = (note) => ({ value: null, status: "none", ...note ? { note } : {} });
  function table(keys, entries, fallback) {
    const out = {};
    for (const k of keys) out[k] = entries[k] ?? fallback;
    return out;
  }

  // ../web/lib/transcript-maps/uiuc.ts
  var HELP = "https://www.admissions.illinois.edu/international-baccalaureate-application-help/";
  var SRC = HELP;
  var LIVE = "https://myillini.illinois.edu/Apply/Application/FreshmanSRAR";
  var LIVE_NOTE = "seen on the live SRAR page 2026-10-28 (docs/superpowers/research/2026-10-27-portal-dom.md \xA75)";
  var OTHER_NOTE = "UIUC has no Fine Arts or PE subject; Religion, Art, Music, Dance, PE, Driver's Ed, Health and Consumer Education go under Other";
  var TECH_NOTE = "Technical = Drafting, Engineering, Information Processing, PLTW, Graphic Design, CAD, Web Design (UIUC's help on the page); other career courses are Other";
  var UIUC_SUBJECTS = ["English", "Mathematics", "Science", "Social Science", "Language Other Than English", "Other", "Technical"];
  var UIUC_MAP = {
    id: "uiuc",
    label: "UIUC SRAR",
    level: table(
      LEVELS,
      {
        regular: verified("Regular", LIVE, LIVE_NOTE),
        accelerated: verified("Accelerated", LIVE, LIVE_NOTE),
        advanced: verified("Advanced", LIVE, LIVE_NOTE),
        enriched: verified("Enriched", LIVE, LIVE_NOTE),
        gifted: verified("Gifted", LIVE, LIVE_NOTE),
        college_prep: verified("College Prep", LIVE, LIVE_NOTE),
        ap: verified("AP Course", LIVE, LIVE_NOTE),
        ib_hl: verified("IB HL", LIVE, LIVE_NOTE),
        ib_sl: verified("IB SL", LIVE, LIVE_NOTE),
        honors: verified("Honors", LIVE, LIVE_NOTE),
        high_honors: verified("High Honors", LIVE, LIVE_NOTE),
        none: none("Leave Type as Regular unless the transcript lists one")
      },
      unverified(null, "UIUC's Type list has no exact match for this level; Regular unless the transcript lists one of UIUC's Types", LIVE)
    ),
    subject: table(
      SUBJECTS,
      {
        english: verified("English", LIVE, "English includes Drama and Speech (UIUC's help on the page)"),
        mathematics: verified("Mathematics", LIVE),
        science: verified("Science", LIVE),
        history_social: verified("Social Science", LIVE),
        world_language: verified("Language Other Than English", LIVE),
        arts: verified("Other", LIVE, OTHER_NOTE),
        computer_science: unverified("Other", "AP Computer Science A / Principles go under Mathematics and Web Design under Technical (UIUC's help); pick the subject per course", LIVE),
        pe_health: verified("Other", LIVE, OTHER_NOTE),
        career_technical: unverified("Technical", TECH_NOTE, LIVE),
        business: unverified("Other", "Business may be Social Science or Other", SRC),
        other: verified("Other", LIVE)
      },
      unverified(null)
    ),
    subjectList: { options: UIUC_SUBJECTS, verified: true, note: `Read live 2026-10-28. ${TECH_NOTE}. Arts, PE, health and religion are "Other"; AP Computer Science is Mathematics.` },
    subSubject: () => none("UIUC has no sub-category"),
    period: table(
      PERIOD_TYPES,
      {
        full_year: verified("All Year", SRC),
        semester: verified("1st Semester / 2nd Semester", SRC, "Enter one row per semester"),
        trimester: unverified(null, "Trimester labels are not published; enter one row per trimester", SRC),
        quarter: unverified(null, "Quarter labels are not published; enter one row per quarter", SRC)
      },
      unverified(null)
    ),
    noCredit: "UIUC's SRAR has no credit field",
    rules: (_school, course) => {
      const out = [];
      if (course.terms.length > 0 && course.finalGrade) out.push("UIUC wants every semester, trimester or quarter grade listed separately; do not list a final grade.");
      if (course.terms.some((t) => t.status === "in_progress")) out.push("Enter In Progress (the Year 12 page's default) for senior-year courses without a grade.");
      if (course.isRepeat) out.push("Tick Repeated Course.");
      return out;
    }
  };

  // ../web/lib/uiuc-fill.ts
  var UIUC_TERM = {
    S1: { value: ".2.1", label: "1st Semester" },
    S2: { value: ".2.2", label: "2nd Semester" },
    T1: { value: ".3.1", label: "1st Trimester" },
    T2: { value: ".3.2", label: "2nd Trimester" },
    T3: { value: ".3.3", label: "3rd Trimester" },
    Q1: { value: ".4.1", label: "1st Quarter" },
    Q2: { value: ".4.2", label: "2nd Quarter" },
    Q3: { value: ".4.3", label: "3rd Quarter" },
    Q4: { value: ".4.4", label: "4th Quarter" },
    FY: { value: ".1.1", label: "All Year" },
    summer: { value: ".5.1", label: "Summer" }
  };
  var UIUC_IN_PROGRESS = "In Progress";

  // src/uiuc/fill.ts
  var NEVER_CLICK_ID = "btn_submit";
  var SUBMIT_WORDING = /submit (page|my record)|i'?m done/i;
  var UIUC_TIMING = { stepMs: 100, rowMs: 1e4, gapMs: 250, optionMs: 2e3, dialogMs: 800, settleMs: 1500 };
  var UIUC_DOM = {
    visible(el) {
      if (!el) return false;
      for (let e = el; e; e = e.parentElement) {
        const h = e;
        if (h.hidden || h.style?.display === "none" || e.getAttribute("aria-hidden") === "true") return false;
      }
      return typeof el.getClientRects !== "function" || el.getClientRects().length > 0;
    }
  };
  var sleep5 = (ms) => new Promise((r) => setTimeout(r, ms));
  var key3 = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  var UiucStop = class extends Error {
  };
  function uiucPageKind(loc) {
    const p = loc.pathname.toLowerCase().replace(/\/+$/, "");
    if (p.includes("preview") || p.includes("viewapplication")) return "preview";
    if (p.endsWith("/apply/application/education")) return "education";
    if (p.endsWith("/apply/application/otheracademic")) return "otherAcademic";
    if (p.endsWith("/apply/application/freshmansrar")) return /(^|[?&])islower=false(&|$)/i.test(loc.search.replace(/^\?/, "")) ? "upper" : "lower";
    return "other";
  }
  var uiucLocked = (doc) => /You must first complete and submit the Education section/i.test(doc.body?.textContent ?? "");
  function assertFillable(loc, doc) {
    const kind = uiucPageKind(loc);
    if (kind !== "lower" && kind !== "upper") throw new UiucStop("This is not a myIllini courses page (Courses Years 9-11 or Year 12); the extension acts only there");
    if (uiucLocked(doc)) throw new UiucStop("Submit the Education page on myIllini first (check its grading scale), then run again");
    return kind;
  }
  function safeClick(el, loc, doc) {
    assertFillable(loc, doc);
    const label = `${el.value ?? ""} ${el.textContent ?? ""}`;
    if (el.id === NEVER_CLICK_ID || el.closest?.(`#${NEVER_CLICK_ID}`) || SUBMIT_WORDING.test(label)) throw new UiucStop("Refused to press a Submit button: the extension never submits anything on myIllini");
    el.click();
  }
  function text5(el, skip) {
    const parts = [];
    const walk = (n) => {
      if (n.nodeType === 3) parts.push(n.textContent ?? "");
      else if (n.nodeType === 1 && !(skip && skip(n))) n.childNodes.forEach(walk);
    };
    if (el) walk(el);
    return parts.join(" ").replace(/\s+/g, " ").trim();
  }
  function fire5(el, type) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = view.Event ?? Event;
    el.dispatchEvent(new Ctor(type, { bubbles: true }));
  }
  function areaEls(doc) {
    const areas = [...doc.querySelectorAll(".SchoolArea")];
    if (areas.length) return areas;
    return doc.querySelector(".GradeEditor") ? [doc.body] : [];
  }
  function editorField(area, cls) {
    const editor = area.querySelector(".GradeEditor") ?? area;
    return [...editor.querySelectorAll(`.${cls}`)].find((e) => !e.closest(".gradeArea")) ?? null;
  }
  var gradeArea = (area) => area.querySelector(".gradeArea");
  var rowEls = (area) => [...gradeArea(area)?.children ?? []].filter((e) => /\bYear:/.test(text5(e)));
  function valueForLabel(sel, label, fallback) {
    const k = key3(label);
    if (!k) return null;
    const opts = sel ? [...sel.options].filter((o) => o.value !== "") : [];
    const hit = opts.find((o) => key3(o.textContent ?? "") === k) ?? opts.find((o) => key3(o.textContent ?? "") && (k.startsWith(key3(o.textContent ?? "")) || key3(o.textContent ?? "").startsWith(k)));
    return hit ? hit.value : fallback(k);
  }
  var YEAR_BY_GRADE = { "9": "1", "10": "2", "11": "3", "12": "4" };
  var yearFallback = (k) => /\bpre/.test(k) ? "0" : /\bpost/.test(k) ? "5" : YEAR_BY_GRADE[k.match(/(\d{1,2})(st|nd|rd|th)/)?.[1] ?? ""] ?? null;
  var TERM_BY_LABEL = {
    ...Object.fromEntries(Object.values(UIUC_TERM).map((t) => [key3(t.label), t.value])),
    yearly: ".1.1",
    "full year": ".1.1",
    year: ".1.1"
  };
  var termFallback = (k) => TERM_BY_LABEL[k] ?? null;
  function parseRow(t, yearSel, termSel) {
    const m = t.match(/^(.*?)\s*Year:\s*(.*?)\s*Term:\s*(.*?)\s*(?:Subject:|Type:|Repeated:|$)/i);
    if (!m) return null;
    const head = m[1].trim();
    const ip = head.match(/^(.*?)\s+In Progress$/i);
    const parts = head.split(" ");
    const [name, grade] = ip ? [ip[1], "In Progress"] : parts.length > 1 ? [parts.slice(0, -1).join(" "), parts[parts.length - 1]] : [head, ""];
    return { name, grade, year: valueForLabel(yearSel, m[2], yearFallback), term: valueForLabel(termSel, m[3], termFallback), text: t };
  }
  function uiucAreas(doc) {
    return areaEls(doc).map((area) => {
      const yearSel = editorField(area, "TermYear");
      const termSel = editorField(area, "Term");
      const skip = (e) => e.classList?.contains("gradeArea") || e.classList?.contains("GradeEditor") || e.tagName === "SCRIPT";
      const head = [...area.querySelectorAll("h1, h2, h3, h4, h5, h6, legend, .SchoolName, strong")].find((e) => !skip(e) && !e.closest(".gradeArea, .GradeEditor"));
      const all = text5(area, skip);
      const grading = area.querySelector(".GradingScaleTypeID");
      return {
        name: head ? text5(head) : all.slice(0, 120),
        text: all.slice(0, 1500),
        gradingType: grading?.value ?? null,
        rows: rowEls(area).flatMap((e) => parseRow(text5(e), yearSel, termSel) ?? [])
      };
    });
  }
  function uiucPageInfo(doc, loc) {
    return { kind: uiucPageKind(loc), locked: uiucLocked(doc), areas: uiucAreas(doc) };
  }
  function sameUiucRow(have, row) {
    if (have.year !== row.year || have.term !== row.term) return false;
    return sameCourseName(have.name, row.name) || row.grade != null && key3(`${have.name} ${have.grade}`) === key3(`${row.name} ${row.grade}`);
  }
  function choose(sel, value) {
    const i = [...sel.options].findIndex((o) => o.value === value);
    if (i < 0) return false;
    sel.selectedIndex = i;
    fire5(sel, "input");
    fire5(sel, "change");
    return sel.value === value;
  }
  async function chooseWait(sel, value) {
    const start = Date.now();
    while (![...sel.options].some((o) => o.value === value)) {
      if (Date.now() - start > UIUC_TIMING.optionMs) return false;
      await sleep5(UIUC_TIMING.stepMs);
    }
    return choose(sel, value);
  }
  var RowLeft = class extends Error {
  };
  function need(area, cls, label) {
    const el = editorField(area, cls);
    if (!el) throw new UiucStop(`UIUC's ${label} box is not on the page`);
    return el;
  }
  function gradeValue(box, grade, gradingType) {
    if (box.tagName !== "SELECT") return grade;
    const opts = [...box.options];
    const hit = opts.find((o) => o.value === grade || (o.textContent ?? "").trim() === grade) ?? opts.find((o) => o.value.toUpperCase() === grade.toUpperCase() && /^[a-z]{1,2}[+-]?$/i.test(grade));
    if (hit) return hit.value;
    if (gradingType === "2") throw new RowLeft(`UIUC lists this school's grades as A-F; your transcript prints ${grade}. Set the grading scale to Other (with the transcript's conversion) on the Education page, or add it yourself`);
    throw new RowLeft(`UIUC's Grade/Mark list has no "${grade}"; add it yourself`);
  }
  function answerTermDialog(doc, loc) {
    const dialog = doc.getElementById("termDialog");
    if (!UIUC_DOM.visible(dialog)) return false;
    const yearly = dialog.querySelector('input[name="topGradeTerm"][value="4"]') ?? doc.querySelector('input[name="topGradeTerm"][value="4"]');
    const ok = doc.getElementById("termDialogSubmit");
    if (!yearly || !ok) throw new RowTouched("UIUC asked how the school year is split and its Yearly choice is not there; add this course yourself");
    yearly.checked = true;
    fire5(yearly, "click");
    fire5(yearly, "change");
    safeClick(ok, loc, doc);
    return true;
  }
  async function rowAdded(doc, loc, area, before, dialogs, ms) {
    const said = [];
    const start = Date.now();
    while (Date.now() - start <= ms) {
      if (rowEls(area).length > before) return { ok: true, said: [...said, ...dialogs.take()] };
      said.push(...dialogs.take());
      if (said.length) return { ok: false, said };
      answerTermDialog(doc, loc);
      await sleep5(UIUC_TIMING.stepMs);
    }
    return { ok: rowEls(area).length > before, said };
  }
  var hasOption = (sel, value) => [...sel.options].some((o) => o.value === value);
  function checkRow(area, row, gradingType) {
    if (row.type === "A Level" || row.type === "AS Level") throw new RowLeft("A Level / AS Level type: pick it on myIllini yourself");
    if (!row.subject || row.grade == null) throw new RowLeft(row.blocked ?? "the row has no subject or grade");
    if (!hasOption(need(area, "TermYear", "Year"), row.year)) throw new RowLeft("UIUC's Year list on this page has no such year");
    if (!hasOption(need(area, "Term", "Term"), row.term)) throw new RowLeft(`UIUC's Term list for this school has no ${row.termLabel}; add it yourself`);
    if (!hasOption(need(area, "CourseTypeID", "Subject"), row.subject)) throw new RowLeft("UIUC's Subject list has no such subject");
    const name = need(area, "CourseName", "Course Name");
    const nameMax = Number(name.getAttribute("maxlength")) || 255;
    if (row.name.length > nameMax) throw new RowLeft(`the course name is longer than UIUC's ${nameMax}-character box; add it yourself`);
    const gradeBox = need(area, "CourseGrade", "Grade/Mark");
    const g = gradeValue(gradeBox, row.grade, gradingType);
    const gradeMax = Number(gradeBox.getAttribute("maxlength")) || 0;
    if (gradeBox.tagName !== "SELECT" && gradeMax && g.length > gradeMax && g !== UIUC_IN_PROGRESS) throw new RowLeft(`"${g}" is longer than UIUC's ${gradeMax}-character Grade/Mark box; add it yourself`);
    if (!hasOption(need(area, "AdvancedTypeID", "Type"), row.type)) throw new RowLeft(`UIUC's Type list has no "${row.type}"`);
    if (row.repeat && !editorField(area, "IsRepeat")) throw new RowLeft("UIUC's Repeated Course box is not on the page; add this repeat yourself");
    if (!editorField(area, "addGrade")) throw new UiucStop("UIUC's Add Course button is not on the page");
    return g;
  }
  var RowTouched = class extends Error {
  };
  async function addRow(doc, loc, area, row, g, dialogs) {
    if (!choose(need(area, "TermYear", "Year"), row.year)) throw new RowTouched("UIUC's Year box did not take the year");
    if (!await chooseWait(need(area, "Term", "Term"), row.term)) throw new RowTouched(`UIUC's Term list changed and has no ${row.termLabel}`);
    if (!choose(need(area, "CourseTypeID", "Subject"), row.subject)) throw new RowTouched("UIUC's Subject box did not take the subject");
    const name = need(area, "CourseName", "Course Name");
    name.focus?.();
    name.value = row.name;
    fire5(name, "input");
    fire5(name, "change");
    name.blur?.();
    const gradeBox = need(area, "CourseGrade", "Grade/Mark");
    if (gradeBox.tagName === "SELECT") {
      if (!choose(gradeBox, g)) throw new RowTouched(`UIUC's Grade/Mark box did not take "${row.grade}"`);
    } else {
      gradeBox.value = g;
      fire5(gradeBox, "input");
      fire5(gradeBox, "change");
      if (gradeBox.value !== g) throw new RowTouched(`UIUC's Grade/Mark box did not take "${row.grade}"`);
    }
    if (!choose(need(area, "AdvancedTypeID", "Type"), row.type)) throw new RowTouched(`UIUC's Type box did not take "${row.type}"`);
    const repeat = editorField(area, "IsRepeat");
    if (repeat && repeat.checked !== row.repeat) {
      repeat.checked = row.repeat;
      fire5(repeat, "change");
    }
    const before = rowEls(area).length;
    if (row.term === UIUC_TERM.FY.value) {
      const start = Date.now();
      while (Date.now() - start < UIUC_TIMING.dialogMs && !UIUC_DOM.visible(doc.getElementById("termDialog"))) await sleep5(UIUC_TIMING.stepMs);
      if (answerTermDialog(doc, loc)) {
        const settled = await rowAdded(doc, loc, area, before, dialogs, UIUC_TIMING.settleMs);
        if (settled.ok || settled.said.length) return settled;
      }
    }
    safeClick(editorField(area, "addGrade"), loc, doc);
    return rowAdded(doc, loc, area, before, dialogs, UIUC_TIMING.rowMs);
  }
  async function fillUiucArea(doc, loc, areaIndex, rows, dialogs) {
    const kind = assertFillable(loc, doc);
    const area = areaEls(doc)[areaIndex];
    if (!area) throw new UiucStop("The school is no longer on the myIllini page: reload it and run again");
    const info = uiucAreas(doc)[areaIndex];
    const have = [...info.rows];
    const result = { added: [], skippedExisting: 0, left: [], problems: [], editorDirty: false };
    const pageYears = kind === "upper" ? ["4"] : ["1", "2", "3"];
    dialogs.start();
    try {
      for (const row of rows) {
        const label = `${row.name} (${row.termLabel})`;
        const at = have.findIndex((x) => sameUiucRow(x, row));
        if (at >= 0) {
          have.splice(at, 1);
          result.skippedExisting++;
          continue;
        }
        if (row.blocked) {
          result.left.push({ course: label, why: row.blocked });
          continue;
        }
        if (!pageYears.includes(row.year)) {
          result.left.push({ course: label, why: "this grade belongs on the other courses page" });
          continue;
        }
        try {
          const g = checkRow(area, row, info.gradingType);
          dialogs.take();
          result.editorDirty = true;
          const r = await addRow(doc, loc, area, row, g, dialogs);
          result.editorDirty = !r.ok;
          if (r.ok) result.added.push({ name: row.name, year: row.year, term: row.term, label });
          const said = r.said.map((s) => `UIUC said "${s.trim()}"`).join("; ");
          if (!r.ok) result.problems.push(`${label}: not added. ${said || "UIUC did not add it within 10 seconds"}`);
          else if (said) result.problems.push(`${label}: added, but ${said}`);
        } catch (e) {
          if (e instanceof RowLeft) result.left.push({ course: label, why: e.message });
          else if (e instanceof RowTouched) result.problems.push(`${label}: not added. ${e.message}`);
          else throw e;
        }
        await sleep5(UIUC_TIMING.gapMs);
      }
    } finally {
      dialogs.stop();
    }
    return result;
  }
  function uiucSave(doc, loc) {
    assertFillable(loc, doc);
    const save = doc.getElementById("btn_save");
    if (!save) throw new UiucStop("UIUC's Save Progress button is not on the page");
    if (!/save/i.test(`${save.value ?? ""} ${save.textContent ?? ""}`)) throw new UiucStop("The Save Progress button says something else; nothing was pressed");
    setTimeout(() => {
      try {
        safeClick(save, loc, doc);
      } catch {
      }
    }, 50);
  }

  // src/uiuc/dialogs.ts
  var DIALOG_CONTROL = "college-filler:uiuc-dialogs";
  var DIALOG_REPORT = "college-filler:uiuc-dialog";
  var DIALOG_HOOK_MAX_MS = 15 * 60 * 1e3;
  function newNonce(c = globalThis.crypto) {
    return [...c.getRandomValues(new Uint8Array(16))].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  function pageDialogs(win, makeNonce = newNonce) {
    let got = [];
    let nonce = "";
    const control = (cmd) => win.dispatchEvent(new win.CustomEvent(DIALOG_CONTROL, { detail: JSON.stringify({ cmd, nonce }) }));
    const listen = (e) => {
      const d = e.detail;
      if (typeof d !== "string") return;
      try {
        const x = JSON.parse(d);
        if (!nonce || x.nonce !== nonce) return;
        got.push(`${x.kind === "confirm" ? "(asked) " : ""}${x.text ?? ""}`);
      } catch {
      }
    };
    return {
      start() {
        got = [];
        nonce = makeNonce();
        win.addEventListener(DIALOG_REPORT, listen);
        control("on");
      },
      take() {
        const out = got;
        got = [];
        return out;
      },
      stop() {
        control("off");
        win.removeEventListener(DIALOG_REPORT, listen);
        nonce = "";
      }
    };
  }

  // src/assist-content.ts
  var onMyIllini = () => SITE_ORIGINS.uiuc.includes(location.origin);
  var uiucBusy = false;
  async function starsHtml(path) {
    const r = await fetch(path, { credentials: "same-origin" });
    const html = await r.text();
    return !r.ok || /login\.aspx|logout/i.test(r.url) ? null : html;
  }
  var csuStop = false;
  var last = null;
  document.addEventListener("focusin", (e) => {
    if (e.target instanceof Element) last = e.target;
  }, true);
  function current() {
    if (last && last.isConnected) return last;
    const a = document.activeElement;
    return a && a !== document.body ? a : null;
  }
  function focus(el) {
    if (!el) return;
    el.focus?.();
    last = el;
  }
  chrome.runtime.onMessage.addListener((raw, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id) return false;
    const msg = raw;
    switch (msg?.type) {
      case "ready":
        sendResponse({ type: "ready", path: location.pathname });
        return false;
      case "assistTarget": {
        const el = current();
        sendResponse({ type: "assistTarget", label: el ? labelOf(el) || el.getAttribute("placeholder") || el.tagName.toLowerCase() : null });
        return false;
      }
      case "assistInsert": {
        const el = current();
        insertValue(el, msg.value).then(
          (result) => {
            const label = el ? labelOf(el) : "";
            if (result.ok && msg.advance && el) focus(nextBox(el));
            sendResponse({ type: "assistInsert", result, label });
          },
          (e) => sendResponse({ type: "assistInsert", result: { ok: false, reason: e instanceof Error ? e.message : String(e) }, label: "" })
        );
        return true;
      }
      case "starsPage":
        sendResponse({
          type: "starsPage",
          year: starsPageYear(location),
          kind: starsPageKind(location),
          existing: starsExistingNames(document),
          // The school's code is in the URL (selCeeb), not always on the page; put it first so a code match can find it.
          pageText: `${new URLSearchParams(location.search).get("selCeeb") ?? ""}
${document.body.innerText.slice(0, 4e3)}`,
          errors: starsErrors(document)
        });
        return false;
      case "starsFill":
        if (!SITE_ORIGINS.stars.includes(location.origin) || starsPageYear(location) == null) {
          sendResponse({ type: "starsFill", ok: false, error: "This is not a STARS coursework page" });
          return false;
        }
        fillStarsCourse(document, msg.row, msg.scale, msg.language).then(
          (r) => sendResponse({ type: "starsFill", ok: true, saved: r.saved, blanks: r.blanks }),
          (e) => sendResponse({ type: "starsFill", ok: false, error: e instanceof StarsStop || e instanceof Error ? e.message : String(e) })
        );
        return true;
      // async response
      case "ucPage": {
        const grade = SITE_ORIGINS.uc.includes(location.origin) ? ucPageGrade(location) : null;
        sendResponse({ type: "ucPage", grade, names: grade != null ? ucExistingNames(document) : ucSummaryNames(document), pageText: document.body.innerText.slice(0, 3e3) });
        return false;
      }
      case "ucFill":
        if (!SITE_ORIGINS.uc.includes(location.origin) || ucPageGrade(location) == null) {
          sendResponse({ type: "ucFill", ok: false, error: "Open a grade's Enter courses & grades page on UC first" });
          return false;
        }
        fillUcPage(document, msg.plan).then(
          (result) => sendResponse({ type: "ucFill", ok: true, result }),
          (e) => sendResponse({ type: "ucFill", ok: false, error: e instanceof Error ? e.message : String(e) })
        );
        return true;
      // async response
      case "starsSchools":
        starsHtml("/srt/EnterSchools.aspx").then(
          (html) => sendResponse(html == null ? { type: "starsSchools", ok: false, error: "STARS signed you out: sign in again, then run again" } : { type: "starsSchools", ok: true, schools: starsSchools(html) }),
          () => sendResponse({ type: "starsSchools", ok: false, error: "STARS did not answer: reload the page and try again" })
        );
        return true;
      // async response
      case "starsYearPath":
        starsHtml(starsSummaryPath(msg.ceeb)).then(
          (html) => sendResponse({ type: "starsYearPath", path: html == null ? null : starsYearPath(html, msg.ceeb, msg.year), years: html == null ? [] : starsYears(html, msg.ceeb).map((y) => y.year) }),
          () => sendResponse({ type: "starsYearPath", path: null, years: [] })
        );
        return true;
      // async response
      case "ucOpenClasses": {
        void (async () => {
          const start = Date.now();
          while (!ucCoursesButtons(document, msg.grade).length && Date.now() - start < 8e3) await new Promise((r) => setTimeout(r, 200));
          const link = ucClassesLink(document, msg.grade, { name: msg.schoolName, code: msg.schoolCode });
          if (typeof link === "string") return sendResponse({ type: "ucOpenClasses", ok: false, error: link });
          sendResponse({ type: "ucOpenClasses", ok: true });
          setTimeout(() => link.click(), 50);
        })();
        return true;
      }
      case "uiucPage":
        if (!onMyIllini()) return false;
        sendResponse({ type: "uiucPage", page: uiucPageInfo(document, location) });
        return false;
      case "uiucFill":
        if (!onMyIllini()) return false;
        if (uiucBusy) {
          sendResponse({ type: "uiucFill", ok: false, error: "Already adding courses on this page" });
          return false;
        }
        uiucBusy = true;
        fillUiucArea(document, location, msg.area, msg.rows, pageDialogs(window)).then(
          (result) => sendResponse({ type: "uiucFill", ok: true, result }),
          (e) => sendResponse({ type: "uiucFill", ok: false, error: e instanceof Error ? e.message : String(e) })
        ).finally(() => uiucBusy = false);
        return true;
      // async response
      case "uiucSave":
        if (!onMyIllini()) return false;
        try {
          uiucSave(document, location);
          sendResponse({ type: "uiucSave", ok: true });
        } catch (e) {
          sendResponse({ type: "uiucSave", ok: false, error: e instanceof Error ? e.message : String(e) });
        }
        return false;
      case "csuStop":
        csuStop = true;
        sendResponse({ type: "csuStop" });
        return false;
      case "csuFill":
        if (!SITE_ORIGINS.csu.includes(location.origin) || !onCourseworkPage(document)) {
          sendResponse({ type: "csuFill", result: { added: [], skippedExisting: 0, stopped: "Open Academic History > High School Coursework on Cal State Apply first." } });
          return false;
        }
        csuStop = false;
        runCsuSchool(document, msg.plan, () => csuStop).then(
          (result) => sendResponse({ type: "csuFill", result }),
          (e) => sendResponse({ type: "csuFill", result: { added: [], skippedExisting: 0, stopped: e instanceof Error ? e.message : String(e) } })
        );
        return true;
      // async response
      default:
        return false;
    }
  });
})();
