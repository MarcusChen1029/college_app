"use strict";
(() => {
  // src/assist/insert.ts
  var ASSIST_TIMING = { stepMs: 80, optionsMs: 2500 };
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var sameText = (a, b) => flat(a) === flat(b);
  var flat = (s) => s.normalize("NFKC").toLowerCase().replace(/[‐-―-]/g, "-").replace(/\s+/g, " ").trim();
  var text = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  function fire(el, type, init = {}) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = (type.startsWith("key") ? view.KeyboardEvent : type === "click" || type.startsWith("mouse") ? view.MouseEvent : view.Event) ?? view.Event ?? Event;
    el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, ...init }));
  }
  function setText(input, value, commit = false) {
    input.focus?.();
    fireFocus(input, "focus", "focusin");
    input.value = value;
    fire(input, "input");
    fire(input, "change");
    if (commit) fireFocus(input, "blur", "focusout");
  }
  function fireFocus(el, own, bubbling) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = view.FocusEvent ?? view.Event ?? Event;
    el.dispatchEvent(new Ctor(own, { bubbles: false }));
    el.dispatchEvent(new Ctor(bubbling, { bubbles: true }));
  }
  function labelOf(el) {
    const doc = el.ownerDocument;
    const id = el.getAttribute("id");
    const byFor = id ? doc.querySelector(`label[for="${id.replace(/"/g, '\\"')}"]`) : null;
    if (byFor) return text(byFor);
    const wrap = el.closest("label");
    if (wrap) return text(wrap);
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.trim();
    const ids = el.getAttribute("aria-labelledby");
    if (ids) return ids.split(/\s+/).map((i) => text(doc.getElementById(i))).join(" ").trim();
    return "";
  }
  var TRUE = ["yes", "true", "y", "1", "checked"];
  var FALSE = ["no", "false", "n", "0", "unchecked", ""];
  function visibleOptions(doc) {
    return [...doc.querySelectorAll('[role="option"], .ng-option, mat-option')].filter((o) => o.getAttribute("aria-disabled") !== "true");
  }
  async function pickOption(doc, value, selector) {
    const start = Date.now();
    for (; ; ) {
      const options2 = selector ? [...doc.querySelectorAll(selector)] : visibleOptions(doc);
      const hit = options2.find((o) => sameText(text(o), value));
      if (hit) return hit;
      if (Date.now() - start >= ASSIST_TIMING.optionsMs) return null;
      await sleep(ASSIST_TIMING.stepMs);
    }
  }
  function comboboxOf(el) {
    if (el.getAttribute("role") === "combobox" || el.hasAttribute("aria-autocomplete")) return el;
    return el.closest('[role="combobox"], mat-select, ng-select, .RadComboBox, .RadDropDownTree');
  }
  function treeLeaves(root) {
    return [...root.querySelectorAll(".RadTreeView .rtText")].filter((e) => !e.closest("li")?.querySelector("ul"));
  }
  function openList(combo) {
    const arrow = combo.matches(".RadComboBox") ? combo.querySelector(".rcbArrowCell a, .rcbActionButton, button") : null;
    fire(arrow ?? combo, "mousedown");
    fire(arrow ?? combo, "click");
  }
  async function insertValue(target, value) {
    if (!target || target === target.ownerDocument.body || target === target.ownerDocument.documentElement) {
      return { ok: false, reason: "Click the box on the page first, then press the value here." };
    }
    const doc = target.ownerDocument;
    const tag = target.tagName.toLowerCase();
    if (tag === "select") {
      const sel = target;
      const opts = [...sel.querySelectorAll("option")];
      const i = opts.findIndex((o) => sameText(text(o), value) || sameText(o.getAttribute("value") ?? "", value));
      if (i < 0) return { ok: false, reason: `"${value}" is not one of this list's options (${opts.slice(0, 6).map((o) => text(o)).filter(Boolean).join(", ")}${opts.length > 6 ? ", \u2026" : ""}).` };
      opts.forEach((o, j) => o.selected = j === i);
      sel.selectedIndex = i;
      fire(sel, "input");
      fire(sel, "change");
      return { ok: true, how: "picked" };
    }
    if (tag === "input" && ["checkbox", "radio"].includes((target.getAttribute("type") ?? "").toLowerCase())) {
      const input = target;
      const type = input.getAttribute("type").toLowerCase();
      if (type === "checkbox") {
        const want = TRUE.includes(flat(value)) ? true : FALSE.includes(flat(value)) ? false : null;
        if (want == null) return { ok: false, reason: `This is a tick box; "${value}" is not Yes or No.` };
        if (input.checked !== want) input.click();
        return { ok: true, how: want ? "ticked" : "unticked" };
      }
      const name = input.getAttribute("name");
      const group = name ? [...doc.querySelectorAll(`input[type="radio"][name="${name.replace(/"/g, '\\"')}"]`)] : [input];
      const hit = group.find((r) => sameText(labelOf(r), value) || sameText(r.getAttribute("value") ?? "", value));
      if (!hit) return { ok: false, reason: `No choice here reads "${value}" (${group.map(labelOf).filter(Boolean).join(", ")}).` };
      hit.click();
      return { ok: true, how: "chose" };
    }
    const combo = comboboxOf(target);
    if (combo?.matches(".RadDropDownTree")) {
      const scope = combo.ownerDocument.querySelector(`#${combo.id}_EmbeddedTree`) ?? combo;
      const leaf = treeLeaves(scope).find((e) => sameText(text(e), value));
      if (!leaf) return { ok: false, reason: `No choice in this list reads "${value}".` };
      fire(leaf, "mousedown");
      leaf.click();
      return { ok: true, how: "picked" };
    }
    const telerik = combo?.closest(".RadComboBox");
    if (telerik) {
      openList(telerik);
      const item = await pickOption(doc, value, `#${telerik.id}_DropDown li`);
      if (!item) return { ok: false, reason: `No option reads "${value}" in this list.` };
      fire(item, "mouseover");
      fire(item, "mousedown");
      item.click();
      return { ok: true, how: "picked" };
    }
    if (combo) {
      const input = combo.matches("input") ? combo : combo.querySelector("input:not([type=hidden])");
      let option = visibleOptions(doc).find((o) => sameText(text(o), value)) ?? null;
      if (!option) {
        if (input && !input.readOnly) setText(input, value);
        else openList(combo);
        option = await pickOption(doc, value);
      }
      if (option) {
        fire(option, "mousedown");
        option.click();
        return { ok: true, how: "picked" };
      }
      if (input && !input.readOnly) return { ok: true, how: "typed (no matching option appeared; check the box)" };
      return { ok: false, reason: `No option reads "${value}" in this list.` };
    }
    if (tag === "input" || tag === "textarea") {
      const input = target;
      if (input.readOnly || input.disabled) return { ok: false, reason: "That box is read-only." };
      setText(input, value, true);
      return { ok: true, how: "typed" };
    }
    if (target.isContentEditable || target.getAttribute("contenteditable") === "true") {
      target.textContent = value;
      fire(target, "input");
      return { ok: true, how: "typed" };
    }
    return { ok: false, reason: "That is not a box the assistant can type into. Click the box itself." };
  }

  // src/assist/next.ts
  var FOCUSABLE = 'input:not([type="hidden"]):not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="image"]), select, textarea, [role="combobox"], [contenteditable="true"]';
  function usable(el) {
    const e = el;
    if (e.disabled || e.readOnly || el.getAttribute("aria-hidden") === "true" || el.closest('[hidden], [aria-hidden="true"]')) return false;
    const r = el.getBoundingClientRect?.();
    return !r || r.width > 0 || r.height > 0 || !el.ownerDocument.defaultView?.innerWidth;
  }
  function fillableBoxes(doc) {
    const seenRadio = /* @__PURE__ */ new Set();
    const out = [];
    for (const el of doc.querySelectorAll(FOCUSABLE)) {
      if (!usable(el)) continue;
      if (el.matches("input") && el.parentElement?.closest('[role="combobox"]') && !el.matches('[role="combobox"]')) continue;
      if ((el.getAttribute("type") ?? "").toLowerCase() === "radio") {
        const name = el.getAttribute("name") ?? "";
        if (seenRadio.has(name)) continue;
        seenRadio.add(name);
      }
      out.push(el);
    }
    return out;
  }
  function nextBox(el) {
    const boxes = fillableBoxes(el.ownerDocument);
    const host = el.matches("input") ? el.closest('[role="combobox"]') ?? el : el;
    const radioName = (host.getAttribute("type") ?? "").toLowerCase() === "radio" ? host.getAttribute("name") : null;
    const i = boxes.findIndex((b) => b === host || radioName != null && b.getAttribute("name") === radioName);
    if (i >= 0) return boxes[i + 1] ?? null;
    return boxes.find(
      (b) => host.compareDocumentPosition(b) & 4
      /* DOCUMENT_POSITION_FOLLOWING */
    ) ?? null;
  }

  // src/stars/fill.ts
  var STARS_TIMING = { stepMs: 100, listMs: 4e3, postbackMs: 8e3, settleMs: 1500, quietMs: 700 };
  var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
  var text2 = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  var ID = (name) => `ctl00_mainContent_${name}`;
  var StarsStop = class extends Error {
  };
  function fire2(el, type) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = (type.startsWith("mouse") || type === "click" ? view.MouseEvent : type.startsWith("focus") || type === "blur" ? view.FocusEvent : view.Event) ?? view.Event ?? Event;
    el.dispatchEvent(new Ctor(type, { bubbles: type !== "focus" && type !== "blur", cancelable: true }));
  }
  async function until(probe, ms, what) {
    const start = Date.now();
    for (; ; ) {
      const v = probe();
      if (v) return v;
      if (Date.now() - start >= ms) throw new StarsStop(what);
      await sleep2(STARS_TIMING.stepMs);
    }
  }
  function starsPageKind(loc) {
    if (/\/srt\/EnterInternationalCoursework/i.test(loc.pathname)) return "intl";
    if (/\/srt\/EnterCoursework/i.test(loc.pathname)) return "us";
    return null;
  }
  function starsPageYear(loc) {
    if (!starsPageKind(loc)) return null;
    const yr = Number(new URLSearchParams(loc.search).get("yr"));
    return Number.isInteger(yr) && yr > 1990 ? yr : null;
  }
  function starsExistingNames(doc) {
    const headers = [...doc.querySelectorAll("th")].map((th) => text2(th));
    const col = headers.findIndex((h) => h === "Course/Exam Name" || h === "Course Name");
    if (col < 0) return [];
    const table = doc.querySelectorAll("th")[col].closest("table");
    return [...table.querySelectorAll("tr")].flatMap((tr) => {
      const cells = tr.querySelectorAll("td");
      return cells.length > col && tr.querySelector('input[name$="delId"]') ? [text2(cells[col])] : [];
    });
  }
  function radValue(doc, name) {
    return doc.getElementById(`${ID(name)}_Input`)?.value ?? "";
  }
  async function quiet(doc) {
    const root = doc.getElementById("aspnetForm") ?? doc.body;
    const View = doc.defaultView ?? globalThis;
    if (!View.MutationObserver || !root) return sleep2(STARS_TIMING.quietMs);
    let last2 = Date.now();
    const obs = new View.MutationObserver(() => last2 = Date.now());
    obs.observe(root, { childList: true, subtree: true, attributes: true });
    const start = Date.now();
    try {
      while (Date.now() - last2 < STARS_TIMING.quietMs && Date.now() - start < STARS_TIMING.postbackMs) await sleep2(STARS_TIMING.stepMs);
    } finally {
      obs.disconnect();
    }
  }
  async function pickRad(doc, name, value, label) {
    const box = doc.getElementById(ID(name));
    if (!box) throw new StarsStop(`STARS's ${label} box is not on the page`);
    if (radValue(doc, name) === value) return;
    const arrow = box.querySelector(".rcbActionButton, .rcbArrowCell a");
    if (arrow) {
      fire2(arrow, "mousedown");
      arrow.click();
    }
    const li = await until(
      () => [...doc.querySelectorAll(`#${ID(name)}_DropDown li`)].find((l) => text2(l) === value),
      // A list that depends on an earlier pick (titles after the subject) can take a whole page update to arrive.
      STARS_TIMING.postbackMs,
      `"${value}" is not in STARS's ${label} list`
    ).catch((e) => {
      throw new StarsStop(e instanceof Error ? e.message : String(e));
    });
    fire2(li, "mouseover");
    fire2(li, "mousedown");
    li.click();
    await until(() => radValue(doc, name) === value, STARS_TIMING.postbackMs, `STARS did not take "${value}" for ${label}`);
    await quiet(doc);
  }
  function typeRad(doc, name, value) {
    const input = doc.getElementById(ID(name));
    if (!input) throw new StarsStop(`STARS's ${name} box is not on the page`);
    input.focus?.();
    fire2(input, "focus");
    input.value = value;
    fire2(input, "input");
    fire2(input, "change");
    fire2(input, "blur");
    fire2(input, "focusout");
  }
  async function fillStarsCourse(doc, row, scale, language = null) {
    const blanks = [];
    const yearGpa = doc.getElementById(ID("year_gpa"));
    const noGpa = doc.getElementById("no_annual_gpa");
    if (yearGpa && !yearGpa.value.trim() && !noGpa?.checked) {
      throw new StarsStop(`STARS needs this year's GPA first: type it at the top of the page (or tick "I have not received an annual GPA" if that is true), then run again`);
    }
    const picks = [];
    if (row.academicLevel) picks.push({ name: "academic_level", value: row.academicLevel, label: "Courses/Exams Were Taken in" });
    picks.push({ name: "subject_area", value: row.subject, label: "Subject Area" }, { name: "course_cd", value: row.title, label: "Course/Exam Content" });
    if (row.level) picks.push({ name: "course_level", value: row.level, label: "Proficiency Level" });
    else blanks.push("Proficiency Level");
    if (doc.getElementById(ID("course_language"))) {
      const shown = radValue(doc, "course_language");
      if (!shown || /^--/.test(shown)) {
        if (language) picks.push({ name: "course_language", value: language, label: "Language of Instruction" });
        else blanks.push("Language of Instruction");
      } else picks.push({ name: "course_language", value: shown, label: "Language of Instruction" });
    }
    picks.push({ name: "term", value: row.length, label: "Course Length" });
    for (const p of picks) await pickRad(doc, p.name, p.value, p.label);
    await until(() => doc.getElementById(`${ID("grade_1")}_Input`), STARS_TIMING.postbackMs, "STARS did not show the grade boxes");
    if (doc.getElementById(ID("grade_scale_id"))) {
      if (scale) {
        picks.push({ name: "grade_scale_id", value: scale, label: "Grading Scale" });
        await pickRad(doc, "grade_scale_id", scale, "Grading Scale");
      } else blanks.push("Grading Scale");
    }
    for (const [i, box] of row.boxes.entries()) {
      if (!doc.getElementById(`${ID(`grade_${i + 1}`)}_Input`)) throw new StarsStop(`STARS shows fewer grade boxes than this course has terms (${row.boxes.length})`);
      if (!box.grade) blanks.push(`Grade ${i + 1}`);
    }
    await fillTail(doc, row);
    if (blanks.some((b) => b === "Grading Scale" || b === "Proficiency Level" || b === "Language of Instruction" || b.startsWith("Grade "))) return { saved: false, blanks };
    for (let round = 0; ; round++) {
      await sleep2(STARS_TIMING.settleMs);
      await quiet(doc);
      const wrongPicks = picks.filter((p) => radValue(doc, p.name) !== p.value);
      const wrong = [...wrongPicks.map((p) => p.label), ...wrongTail(doc, row)];
      if (!wrong.length) break;
      if (round === 2) throw new StarsStop(`STARS kept resetting ${wrong.join(", ")}; nothing was saved for this course`);
      for (const p of wrongPicks) await pickRad(doc, p.name, p.value, p.label);
      await fillTail(doc, row);
    }
    const save = doc.getElementById(ID("btn_submit"));
    if (!save) throw new StarsStop("STARS's Save Course button is not on the page");
    setTimeout(() => save.click(), 50);
    return { saved: true, blanks };
  }
  async function fillTail(doc, row) {
    for (const [i, box] of row.boxes.entries()) if (box.grade) await pickRad(doc, `grade_${i + 1}`, box.grade, `Grade ${i + 1}`);
    for (const [i, box] of row.boxes.entries()) if (box.credit != null) typeRad(doc, `units_${i + 1}`, box.credit);
    typeRad(doc, "exact_course_title", row.name);
    await quiet(doc);
  }
  function wrongTail(doc, row) {
    const out = [];
    for (const [i, box] of row.boxes.entries()) {
      if (box.grade && radValue(doc, `grade_${i + 1}`) !== box.grade) out.push(`grade ${i + 1}`);
      const shown = doc.getElementById(ID(`units_${i + 1}`))?.value ?? "";
      if (box.credit != null && Number(shown) !== Number(box.credit)) out.push(`credit ${i + 1}`);
    }
    if (doc.getElementById(ID("exact_course_title"))?.value !== row.name) out.push("course name");
    return out;
  }
  function starsErrors(doc) {
    const out = [];
    for (const el of doc.querySelectorAll('[id^="ctl00_mainContent_v_"], .rwDialog')) {
      const t = text2(el);
      const r = el.getBoundingClientRect?.();
      if (t && (!r || r.height > 0)) out.push(el.id.startsWith("ctl00_mainContent_v_") ? `${el.id.slice("ctl00_mainContent_v_".length)}: ${t}` : t.slice(0, 200));
    }
    return out;
  }

  // src/sites.ts
  var SITE_ORIGINS = {
    common_app: ["https://apply.commonapp.org"],
    uc: ["https://apply.universityofcalifornia.edu"],
    stars: ["https://srar.selfreportedtranscript.com"],
    csu: ["https://calstate.cas.myliaison.com", "https://calstate.liaisoncas.com"],
    uiuc: ["https://myillini.illinois.edu"],
    ut: ["https://utdirect.utexas.edu", "https://mystatus.admissions.utexas.edu", "https://admissions.utexas.edu"]
  };

  // ../web/lib/csu-labels.ts
  var csuGradeLevelLabel = (n) => `${n}th Grade`;
  var csuGradeLevelOption = (r) => `${csuGradeLevelLabel(r.gradeLevel)} \u2022 ${r.year}`;

  // ../web/lib/school-match.ts
  var ABBR = {
    intl: "international",
    int: "international",
    sch: "school",
    schl: "school",
    hs: "high school",
    acad: "academy",
    acd: "academy",
    cmp: "campus",
    camp: "campus",
    cmps: "campus",
    st: "saint",
    ste: "sainte",
    mt: "mount",
    jr: "junior",
    sr: "senior",
    sci: "science",
    tech: "technology",
    inst: "institute",
    univ: "university",
    coll: "college",
    prep: "preparatory",
    ctr: "center",
    centre: "center",
    elem: "elementary",
    sec: "secondary",
    natl: "national",
    ms: "middle school",
    bil: "bilingual",
    amer: "american",
    ctry: "country",
    co: "county",
    cty: "county",
    dist: "district",
    isd: "independent school district"
  };
  var STOP = /* @__PURE__ */ new Set(["the", "of", "and", "at", "a", "an", "in", "for", "de", "la", "le"]);
  function schoolWords(name) {
    const out = [];
    const raw = name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/&/g, " and ").replace(/\bh\.\s?s\./g, " hs ").replace(/['\u2019]/g, "").replace(/[^a-z0-9\u3400-\u9fff]+/g, " ").split(" ").filter(Boolean);
    for (const w of raw) for (const x of (ABBR[w] ?? w).split(" ")) if (!STOP.has(x)) out.push(x);
    return out;
  }
  function sameWord(a, b) {
    if (a === b) return true;
    if (Math.min(a.length, b.length) < 5 || Math.abs(a.length - b.length) > 1) return false;
    let i = 0;
    let j = 0;
    let edits = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) {
        i++;
        j++;
        continue;
      }
      if (++edits > 1) return false;
      if (a.length > b.length) i++;
      else if (b.length > a.length) j++;
      else {
        i++;
        j++;
      }
    }
    return edits + (a.length - i) + (b.length - j) <= 1;
  }
  var shared = (a, b) => a.filter((w) => b.some((x) => sameWord(w, x))).length;
  function schoolNameScore(a, b) {
    const wa = [...new Set(schoolWords(a))];
    const wb = [...new Set(schoolWords(b))];
    if (!wa.length || !wb.length) return 0;
    if (wa.join("") === wb.join("")) return 1;
    const both = shared(wa, wb);
    const small = Math.min(wa.length, wb.length);
    const big = Math.max(wa.length, wb.length);
    const ca = wa.join("");
    const cb = wb.join("");
    if (both === small && (small >= 2 || big === 1)) return 0.9 + 0.1 * (small / big);
    if (Math.min(ca.length, cb.length) >= 8 && (ca.includes(cb) || cb.includes(ca))) return 0.88;
    return 0.85 * (2 * both / (wa.length + wb.length));
  }
  var SAME_SCHOOL = 0.75;
  var codeKey = (c) => (c ?? "").toUpperCase().replace(/[\s-]+/g, "");
  function sameSchoolCode(a, b) {
    const ka = codeKey(a);
    return ka !== "" && ka === codeKey(b);
  }
  function codeInText(code, text5) {
    const k = codeKey(code);
    if (!k) return false;
    return new RegExp(`(^|[^A-Za-z0-9])${k.replace(/[^A-Z0-9]/g, "")}($|[^A-Za-z0-9])`, "i").test(text5);
  }
  function bestSchoolMatch(options2, school, view) {
    const norm = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
    const exact = options2.filter((o) => norm(view(o).name) === norm(school.name));
    if (exact.length === 1) return exact[0];
    if (school.code) {
      const byCode = options2.filter((o) => sameSchoolCode(view(o).code, school.code));
      if (byCode.length === 1) return byCode[0];
    }
    const scored = options2.map((o) => ({ o, s: schoolNameScore(view(o).name, school.name) })).sort((x, y) => y.s - x.s);
    const top = scored[0];
    if (!top || top.s < SAME_SCHOOL) return null;
    if (scored[1] && scored[1].s >= top.s - 0.02) return null;
    return top.o;
  }
  function schoolOnPage(items, pageText, view) {
    const byCode = items.filter((o) => codeInText(view(o).code, pageText));
    if (byCode.length === 1) return byCode[0];
    const page = new Set(schoolWords(pageText));
    const words2 = [...page];
    const hits = items.map((o) => {
      const w = [...new Set(schoolWords(view(o).name))];
      return { o, n: w.length, all: w.length > 0 && w.every((x) => page.has(x) || words2.some((p) => sameWord(p, x))) };
    }).filter((h) => h.all).sort((a, b) => b.n - a.n);
    if (!hits.length) return null;
    if (hits[1] && hits[1].n === hits[0].n) return null;
    return hits[0].o;
  }

  // src/csu/fill.ts
  var CSU_TIMING = { stepMs: 100, listMs: 4e3, drawerMs: 8e3 };
  var sleep3 = (ms) => new Promise((r) => setTimeout(r, ms));
  var text3 = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  var same = (a, b) => a.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim() === b.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  var CsuStop = class extends Error {
  };
  function fire3(el, type, init = {}) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = (type.startsWith("mouse") || type === "click" ? view.MouseEvent : type.startsWith("key") ? view.KeyboardEvent : view.Event) ?? view.Event ?? Event;
    el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, ...init }));
  }
  async function until2(probe, ms, what) {
    const start = Date.now();
    for (; ; ) {
      const v = probe();
      if (v) return v;
      if (Date.now() - start >= ms) throw new CsuStop(what);
      await sleep3(CSU_TIMING.stepMs);
    }
  }
  function setReactValue(input, value) {
    const view = input.ownerDocument.defaultView ?? globalThis;
    const setter = Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, "value")?.set;
    if (setter) setter.call(input, value);
    else input.value = value;
    fire3(input, "input");
  }
  function topDrawer(doc) {
    const drawers = [...doc.querySelectorAll(".MuiDrawer-root")].filter((d) => !/cky/.test(d.className));
    return drawers[drawers.length - 1] ?? null;
  }
  function onCourseworkPage(doc) {
    return [...doc.querySelectorAll("main h1, main h2, h1, h2")].some((h) => text3(h) === "High School Coursework");
  }
  function schoolButton(doc, schoolName, schoolCode) {
    const buttons = [...doc.querySelectorAll("main button")].filter((b) => /^(add course|\d+ courses?)$/i.test(text3(b)));
    const cardText = (b) => {
      let el = b;
      for (let i = 0; i < 6 && el?.parentElement; i++) {
        const up = el.parentElement;
        if (buttons.some((o) => o !== b && up.contains(o))) break;
        el = up;
      }
      const parts = [];
      const walk = (n) => n.nodeType === 3 ? parts.push(n.textContent ?? "") : n.childNodes.forEach(walk);
      if (el) walk(el);
      return parts.join(" ").replace(/\s+/g, " ").trim();
    };
    const byCode = schoolCode ? buttons.filter((b) => codeInText(schoolCode, cardText(b))) : [];
    if (byCode.length === 1) return byCode[0];
    const named = bestSchoolMatch(buttons, { name: schoolName }, (b) => ({ name: cardText(b) }));
    if (named) return named;
    if (buttons.length === 1) return buttons[0];
    throw new CsuStop(`Could not tell which school on Cal State Apply is "${schoolName}". Add courses for that school by hand, or add its school code in the tracker.`);
  }
  async function existingTitles(doc, schoolName, schoolCode) {
    const btn = schoolButton(doc, schoolName, schoolCode);
    if (/^add course$/i.test(text3(btn))) return [];
    btn.click();
    const drawer = await until2(() => {
      const d = topDrawer(doc);
      return d && /High School Courses/.test(text3(d)) ? d : null;
    }, CSU_TIMING.drawerMs, "Cal State Apply did not open the school's course list");
    return [...drawer.querySelectorAll("tr")].flatMap((tr) => {
      const cells = tr.querySelectorAll("td");
      return cells.length ? [text3(cells[0])] : [];
    });
  }
  var options = (input) => {
    const doc = input.ownerDocument;
    const box = doc.getElementById(input.getAttribute("aria-controls") || `${input.id}-listbox`);
    return box ? [...box.querySelectorAll('[role="option"]')] : [];
  };
  async function openAuto(input, label) {
    const start = Date.now();
    for (let tries = 0; ; tries++) {
      if (tries % 6 === 0) {
        input.blur();
        input.focus();
        fire3(input, "mousedown");
      }
      const o = options(input);
      if (o.length) return o;
      if (Date.now() - start >= CSU_TIMING.listMs) throw new CsuStop(`Cal State Apply's ${label} list did not open`);
      await sleep3(CSU_TIMING.stepMs);
    }
  }
  async function pickAuto(input, value, label, action = false) {
    await openAuto(input, label);
    const option = await until2(() => options(input).find((o) => same(text3(o), value)), CSU_TIMING.listMs, `"${value}" is not in Cal State Apply's ${label} list`);
    option.click();
    if (action) return;
    await until2(() => same(input.value, value) || input.value.length > 0, CSU_TIMING.listMs, `Cal State Apply did not take "${value}" for ${label}`);
  }
  function field(drawer, id, label) {
    const el = drawer.querySelector(`[id="${id}"]`);
    if (!el) throw new CsuStop(`Cal State Apply's ${label} box is not in the form`);
    return el;
  }
  function drawerButton(drawer, label) {
    const b = [...drawer.querySelectorAll("button")].find((x) => same(text3(x), label));
    if (!b) throw new CsuStop(`Cal State Apply's ${label} button is not in the form`);
    return b;
  }
  async function addGradeLevel(doc, row) {
    const course = topDrawer(doc);
    await pickAuto(field(course, "gradeLevelId", "Grade Level"), "Add Grade Level", "Grade Level", true);
    const sub = await until2(() => {
      const d = topDrawer(doc);
      return d && d.querySelector('[id="yearId"]') ? d : null;
    }, CSU_TIMING.drawerMs, "Cal State Apply did not open the Add Grade Level form");
    await pickAuto(field(sub, "gradeLevelId", "Grade Level"), csuGradeLevelLabel(row.gradeLevel), "Grade Level");
    await pickAuto(field(sub, "yearId", "Year"), row.year, "Year");
    const summer = sub.querySelector('[id="includeSummer"]');
    if (row.summer && summer && !summer.checked) summer.click();
    drawerButton(sub, "Save").click();
    await until2(() => !topDrawer(doc)?.querySelector('[id="yearId"]'), CSU_TIMING.drawerMs, "Cal State Apply did not save the grade level");
  }
  async function fillCsuCourse(doc, row) {
    const drawer = await until2(() => {
      const d = topDrawer(doc);
      return d && d.querySelector('[id="gradeLevelId"]') && !d.querySelector('[id="yearId"]') ? d : null;
    }, CSU_TIMING.drawerMs, "Cal State Apply did not open the course form");
    if (row.summer) throw new CsuStop(`${row.name} is a summer course: Cal State Apply's summer grade levels were not seen yet, so add it by hand`);
    const levelOption = csuGradeLevelOption(row);
    const gl = field(drawer, "gradeLevelId", "Grade Level");
    const has = (await openAuto(gl, "Grade Level")).some((o) => same(text3(o), levelOption));
    fire3(gl, "keydown", { key: "Escape" });
    await sleep3(200);
    if (!has) await addGradeLevel(doc, row);
    const form = topDrawer(doc);
    await pickAuto(field(form, "gradeLevelId", "Grade Level"), levelOption, "Grade Level");
    const title = field(form, "courseName", "Course Title");
    title.focus();
    setReactValue(title, row.name);
    const echo = await until2(() => options(title).find((o) => same(text3(o), row.name)), CSU_TIMING.listMs, `Cal State Apply did not offer the title "${row.name}"`);
    echo.click();
    const boxes = [...form.querySelectorAll('input[id^="highSchoolCourseGrades."]')];
    if (boxes.length !== row.grades.length) throw new CsuStop(`Cal State Apply shows ${boxes.length} grade boxes; the tracker has ${row.grades.length} terms for ${row.name}. Check the school's Term Type`);
    const blanks = [];
    for (const [i, g] of row.grades.entries()) {
      const label = text3(form.querySelector(`label[for="${boxes[i].id}"]`)) || `term ${i + 1}`;
      if (g == null) blanks.push(`${label} grade`);
      else await pickAuto(boxes[i], g, `${label} grade`);
    }
    if (blanks.length) return { blanks };
    const radio = [...form.querySelectorAll('input[name="courseTypeLkupId"]')].find((r) => same(text3(r.closest("label")), row.courseType));
    if (!radio) throw new CsuStop(`Cal State Apply has no Course Type "${row.courseType}"`);
    radio.click();
    if (!radio.checked) radio.closest("label")?.click();
    await until2(() => radio.checked, CSU_TIMING.listMs, `Cal State Apply did not take Course Type "${row.courseType}"`);
    drawerButton(form, "Save").click();
    await until2(() => topDrawer(doc) !== form || !form.isConnected || !form.querySelector('[id="courseName"]'), CSU_TIMING.drawerMs, `Cal State Apply did not save ${row.name} (a required box may be empty)`);
    return { blanks };
  }
  async function openCourseForm(doc, schoolName, schoolCode) {
    const top = topDrawer(doc);
    if (top && /High School Courses/.test(text3(top))) {
      drawerButton(top, "Add Course").click();
    } else {
      schoolButton(doc, schoolName, schoolCode).click();
      await sleep3(500);
      const d = topDrawer(doc);
      if (d && /High School Courses/.test(text3(d))) drawerButton(d, "Add Course").click();
    }
    await until2(() => topDrawer(doc)?.querySelector('[id="courseName"], [id="gradeLevelId"]'), CSU_TIMING.drawerMs, "Cal State Apply did not open the course form");
  }

  // src/csu/run.ts
  var key = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  async function runCsuSchool(doc, plan, shouldStop) {
    const added = [];
    let have;
    try {
      have = await existingTitles(doc, plan.schoolName, plan.schoolCode);
    } catch (e) {
      return { added, skippedExisting: 0, stopped: e.message };
    }
    const left = /* @__PURE__ */ new Map();
    for (const n of have) left.set(key(n), (left.get(key(n)) ?? 0) + 1);
    const todo = plan.rows.filter((r) => {
      const n = left.get(key(r.name)) ?? 0;
      if (n > 0) left.set(key(r.name), n - 1);
      return n === 0;
    });
    for (const row of todo) {
      if (shouldStop()) return { added, skippedExisting: plan.rows.length - todo.length, stopped: "Stopped." };
      try {
        await openCourseForm(doc, plan.schoolName, plan.schoolCode);
        const { blanks } = await fillCsuCourse(doc, row);
        if (blanks.length) {
          return { added, skippedExisting: plan.rows.length - todo.length, stopped: `${row.name} is filled in but not saved: choose ${blanks.join(", ")} and press Save, then run again.` };
        }
        const now = await existingTitles(doc, plan.schoolName, plan.schoolCode);
        if (now.filter((n) => key(n) === key(row.name)).length <= have.filter((n) => key(n) === key(row.name)).length) {
          return { added, skippedExisting: plan.rows.length - todo.length, stopped: `Cal State Apply did not list ${row.name} after saving. Check the form for a message.` };
        }
        have = now;
        added.push(row.name);
      } catch (e) {
        const msg = e instanceof CsuStop || e instanceof Error ? e.message : String(e);
        return { added, skippedExisting: plan.rows.length - todo.length, stopped: `${row.name}: ${msg}. ${topDrawer(doc) ? "The form is left open: finish or cancel it." : ""}`.trim() };
      }
    }
    return { added, skippedExisting: plan.rows.length - todo.length, stopped: null };
  }

  // ../web/lib/course-names.ts
  var ROMAN = { i: "1", ii: "2", iii: "3", iv: "4", v: "5", vi: "6" };
  function words(name) {
    return name.normalize("NFKC").toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, " ").split(" ").filter(Boolean).map((w) => ROMAN[w] ?? w);
  }
  var dropGrade = (w) => w.length > 1 && /^(9|10|11|12)$/.test(w[w.length - 1]) ? w.slice(0, -1) : w;
  function oneEdit(a, b) {
    if (Math.abs(a.length - b.length) > 1) return false;
    let i = 0;
    let j = 0;
    let edits = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) {
        i++;
        j++;
        continue;
      }
      if (++edits > 1) return false;
      if (a.length > b.length) i++;
      else if (b.length > a.length) j++;
      else {
        i++;
        j++;
      }
    }
    return edits + (a.length - i) + (b.length - j) <= 1;
  }
  function sameCourseName(a, b) {
    const wa = words(a);
    const wb = words(b);
    if (!wa.length || !wb.length) return false;
    const ja = wa.join(" ");
    const jb = wb.join(" ");
    if (ja === jb) return true;
    if (dropGrade(wa).join(" ") === dropGrade(wb).join(" ")) return true;
    return Math.min(ja.length, jb.length) >= 8 && oneEdit(ja, jb) && !/\d/.test(diffChar(ja, jb));
  }
  function diffChar(a, b) {
    let i = 0;
    while (i < a.length && a[i] === b[i]) i++;
    return (a[i] ?? "") + (b[i] ?? "");
  }

  // src/uc/fill.ts
  var UC_TIMING = { stepMs: 100, rowMs: 5e3 };
  var sleep4 = (ms) => new Promise((r) => setTimeout(r, ms));
  var key2 = (s) => s.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  var P = (i, f) => `academics_hs_classes_add_${i}_${f}`;
  var UcStop = class extends Error {
  };
  function fire4(el, type) {
    const view = el.ownerDocument?.defaultView ?? globalThis;
    const Ctor = view.Event ?? Event;
    el.dispatchEvent(new Ctor(type, { bubbles: true }));
  }
  function ucPageGrade(loc) {
    const m = loc.pathname.match(/\/acadHistFrHighSchoolClasses\/editClasses\/(\d{2})\//);
    return m ? Number(m[1]) : null;
  }
  function ucRowIndexes(doc) {
    return [...doc.querySelectorAll('select[id^="academics_hs_classes_add_"][id$="_subject"]')].map((s) => Number(s.id.slice("academics_hs_classes_add_".length).split("_")[0])).filter((n) => Number.isInteger(n));
  }
  var titleOf = (doc, i) => (doc.getElementById(P(i, "class_title"))?.value ?? "").trim();
  var subjectOf = (doc, i) => doc.getElementById(P(i, "subject"))?.value ?? "";
  function ucExistingNames(doc) {
    return ucRowIndexes(doc).map((i) => titleOf(doc, i)).filter(Boolean);
  }
  function pick(doc, id, want, label) {
    const sel = doc.getElementById(id);
    if (!sel) throw new UcStop(`UC's ${label} box is not on the page`);
    const opts = [...sel.options];
    const i = want.value != null ? opts.findIndex((o) => o.value === want.value) : opts.findIndex((o) => key2(o.text) === key2(want.text));
    if (i < 0) throw new UcStop(`"${want.text}" is not in UC's ${label} list`);
    sel.selectedIndex = i;
    fire4(sel, "input");
    fire4(sel, "change");
  }
  async function emptyRow(doc) {
    const free = ucRowIndexes(doc).find((i) => !titleOf(doc, i) && !subjectOf(doc, i));
    if (free != null) return free;
    const before = ucRowIndexes(doc).length;
    const add = doc.getElementById("addManualHSClass");
    if (!add) throw new UcStop("UC's Add another course link is not on the page");
    add.click();
    const start = Date.now();
    while (ucRowIndexes(doc).length <= before) {
      if (Date.now() - start > UC_TIMING.rowMs) throw new UcStop("UC did not add a course row");
      await sleep4(UC_TIMING.stepMs);
    }
    return ucRowIndexes(doc).find((i) => !titleOf(doc, i) && !subjectOf(doc, i));
  }
  function fillRow(doc, i, row) {
    pick(doc, P(i, "subject"), row.discipline, "Subject Area/Course Category");
    const title = doc.getElementById(P(i, "class_title"));
    if (!title) throw new UcStop("UC's Course Name box is not on the page");
    title.focus?.();
    title.value = row.name;
    fire4(title, "input");
    fire4(title, "change");
    title.blur?.();
    pick(doc, P(i, "honors"), { text: row.honors }, "Honor Type");
    for (const [n, g] of row.grades.entries()) pick(doc, P(i, `grade${n + 1}`), { text: g }, `Grade ${n + 1}`);
    const extra = doc.getElementById(P(i, `grade${row.grades.length + 1}`));
    if (extra && extra.offsetParent !== null && extra.getClientRects().length > 0) throw new UcStop(`UC shows more grade boxes than the tracker has terms for ${row.name}: check the school's term system on UC`);
    if (row.language) pick(doc, P(i, "subject_language_code"), { text: row.language }, "Language");
  }
  async function fillUcPage(doc, plan) {
    const have = ucExistingNames(doc);
    const added = [];
    const left = [];
    let skippedExisting = 0;
    for (const row of plan.rows) {
      const at = have.findIndex((n) => sameCourseName(n, row.name));
      if (at >= 0) {
        have.splice(at, 1);
        skippedExisting++;
        continue;
      }
      if (!row.discipline || row.grades.some((g) => g == null) || row.language === null && row.discipline.area === "Language Other Than English") {
        left.push(row.name);
        continue;
      }
      const i = await emptyRow(doc);
      fillRow(doc, i, row);
      added.push(row.name);
    }
    if (!added.length) return { added, skippedExisting, left, saving: false };
    const save = doc.getElementById("save");
    if (!save) throw new UcStop("UC's Save & continue button is not on the page");
    setTimeout(() => save.click(), 50);
    return { added, skippedExisting, left, saving: true };
  }
  function ucSummaryNames(doc) {
    const table = [...doc.querySelectorAll("table")].find((t) => [...t.querySelectorAll("th")].some((th) => key2(th.textContent ?? "") === "course name"));
    if (!table) return [];
    const col = [...table.querySelectorAll("th")].findIndex((th) => key2(th.textContent ?? "") === "course name");
    return [...table.querySelectorAll("tr")].flatMap((tr) => {
      const td = tr.querySelectorAll("td");
      return td.length > col ? [(td[col].textContent ?? "").trim()] : [];
    });
  }

  // src/stars/nav.ts
  var decode = (s) => s.replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n))).replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  function starsSchools(html) {
    const out = [];
    for (const a of html.matchAll(/<a\b[^>]*>/g)) {
      const tag = a[0];
      const ceeb = tag.match(/goStep\(\s*'ceeb'\s*,\s*'([^']+)'\s*\)/)?.[1];
      const name = tag.match(/title="Enter Coursework taken at ([^"]*)"/)?.[1];
      if (ceeb && name && !out.some((s) => s.ceeb === ceeb)) out.push({ ceeb, name: decode(name).trim() });
    }
    return out;
  }
  function starsYears(html, ceeb) {
    const out = [];
    for (const m of html.matchAll(/openCourseEntry\(\s*'([^']+)'\s*,\s*'(\d{4})'\s*(?:,\s*'([^']*)')?\s*\)/g)) {
      if (m[1] !== ceeb || out.some((y) => y.year === Number(m[2]))) continue;
      out.push({ year: Number(m[2]), label: decode(m[3] ?? "") });
    }
    return out;
  }
  function starsYearPath(html, ceeb, year) {
    const y = starsYears(html, ceeb).find((x) => x.year === year);
    if (!y) return null;
    const start = html.search(/function\s+openCourseEntry\s*\(\s*ceeb\s*,\s*yr\s*,\s*ms\s*\)/);
    if (start < 0) return null;
    const end = html.indexOf("function ", start + 10);
    const body = html.slice(start, end < 0 ? void 0 : end);
    const urls = [...body.matchAll(/course_url\s*=\s*"([A-Za-z0-9_.-]+\.aspx)"/g)];
    const page = urls[urls.length - 1]?.[1];
    if (!page || !/noWin\s*=\s*true/.test(body)) return null;
    const ms = y.label.toUpperCase();
    const add = y.label === "Middle School" ? "&ms=Y" : ms.includes("9TH") ? "&gl=09" : ms.includes("10TH") ? "&gl=10" : ms.includes("11TH") ? "&gl=11" : ms.includes("12TH") ? "&gl=12" : "";
    const c = encodeURIComponent(ceeb);
    return `/srt/${page}?selCeeb=${c}&yr=${year}&sel_sender_ceeb=${c}${add}`;
  }
  var starsSummaryPath = (ceeb) => `/srt/SchoolSummary.aspx?sel_sender_ceeb=${encodeURIComponent(ceeb)}`;

  // src/uc/nav.ts
  var text4 = (el) => {
    const parts = [];
    const walk = (n) => n.nodeType === 3 ? parts.push(n.textContent ?? "") : n.childNodes.forEach(walk);
    if (el) walk(el);
    return parts.join(" ").replace(/\s+/g, " ").trim();
  };
  function ucCoursesButtons(doc, grade) {
    const nn = String(grade).padStart(2, "0");
    const opens = (el) => /^(enter courses|edit)\b/i.test(text4(el)) && !/acadHistFrInfo/i.test(el.getAttribute("href") ?? "");
    const byId = [...doc.querySelectorAll(`[id^="edit_${nn}"]`)].filter((el) => /^edit_\d+$/.test(el.id) && opens(el));
    if (byId.length) return byId;
    return [...doc.querySelectorAll("a, button")].filter((el) => {
      if (!opens(el)) return false;
      if (/^enter courses/i.test(text4(el))) return true;
      for (let up = el.parentElement, i = 0; up && i < 3; up = up.parentElement, i++) {
        const t = text4(up);
        if (/School code/i.test(t)) return false;
        if (/\d{4}\s*-\s*\d{4} academic year/i.test(t)) return true;
      }
      return false;
    });
  }
  function ucClassesLink(doc, grade, school) {
    const links = ucCoursesButtons(doc, grade);
    if (!links.length) return `UC shows no ${grade}th grade school year to enter courses for: check that ${grade}th grade is added to the school under Academic history (then run again)`;
    if (links.length === 1) return links[0];
    const card = (a) => {
      let el = a;
      while (el.parentElement && !links.some((o) => o !== a && el.parentElement.contains(o))) el = el.parentElement;
      return text4(el);
    };
    const hits = links.filter((a) => schoolOnPage([school], card(a), (s) => s) !== null);
    return hits.length === 1 ? hits[0] : `UC lists several schools for ${grade}th grade and the tracker's "${school.name}" matches ${hits.length ? "more than one" : "none"} of them: add the school code in the tracker`;
  }

  // src/assist-content.ts
  async function starsHtml(path) {
    const r = await fetch(path, { credentials: "same-origin" });
    const html = await r.text();
    return !r.ok || /login\.aspx|logout/i.test(r.url) ? null : html;
  }
  var csuStop = false;
  var last = null;
  document.addEventListener("focusin", (e) => {
    if (e.target instanceof Element) last = e.target;
  }, true);
  function current() {
    if (last && last.isConnected) return last;
    const a = document.activeElement;
    return a && a !== document.body ? a : null;
  }
  function focus(el) {
    if (!el) return;
    el.focus?.();
    last = el;
  }
  chrome.runtime.onMessage.addListener((raw, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id) return false;
    const msg = raw;
    switch (msg?.type) {
      case "ready":
        sendResponse({ type: "ready", path: location.pathname });
        return false;
      case "assistTarget": {
        const el = current();
        sendResponse({ type: "assistTarget", label: el ? labelOf(el) || el.getAttribute("placeholder") || el.tagName.toLowerCase() : null });
        return false;
      }
      case "assistInsert": {
        const el = current();
        insertValue(el, msg.value).then(
          (result) => {
            const label = el ? labelOf(el) : "";
            if (result.ok && msg.advance && el) focus(nextBox(el));
            sendResponse({ type: "assistInsert", result, label });
          },
          (e) => sendResponse({ type: "assistInsert", result: { ok: false, reason: e instanceof Error ? e.message : String(e) }, label: "" })
        );
        return true;
      }
      case "starsPage":
        sendResponse({
          type: "starsPage",
          year: starsPageYear(location),
          kind: starsPageKind(location),
          existing: starsExistingNames(document),
          // The school's code is in the URL (selCeeb), not always on the page; put it first so a code match can find it.
          pageText: `${new URLSearchParams(location.search).get("selCeeb") ?? ""}
${document.body.innerText.slice(0, 4e3)}`,
          errors: starsErrors(document)
        });
        return false;
      case "starsFill":
        if (!SITE_ORIGINS.stars.includes(location.origin) || starsPageYear(location) == null) {
          sendResponse({ type: "starsFill", ok: false, error: "This is not a STARS coursework page" });
          return false;
        }
        fillStarsCourse(document, msg.row, msg.scale, msg.language).then(
          (r) => sendResponse({ type: "starsFill", ok: true, saved: r.saved, blanks: r.blanks }),
          (e) => sendResponse({ type: "starsFill", ok: false, error: e instanceof StarsStop || e instanceof Error ? e.message : String(e) })
        );
        return true;
      // async response
      case "ucPage": {
        const grade = SITE_ORIGINS.uc.includes(location.origin) ? ucPageGrade(location) : null;
        sendResponse({ type: "ucPage", grade, names: grade != null ? ucExistingNames(document) : ucSummaryNames(document), pageText: document.body.innerText.slice(0, 3e3) });
        return false;
      }
      case "ucFill":
        if (!SITE_ORIGINS.uc.includes(location.origin) || ucPageGrade(location) == null) {
          sendResponse({ type: "ucFill", ok: false, error: "Open a grade's Enter courses & grades page on UC first" });
          return false;
        }
        fillUcPage(document, msg.plan).then(
          (result) => sendResponse({ type: "ucFill", ok: true, result }),
          (e) => sendResponse({ type: "ucFill", ok: false, error: e instanceof Error ? e.message : String(e) })
        );
        return true;
      // async response
      case "starsSchools":
        starsHtml("/srt/EnterSchools.aspx").then(
          (html) => sendResponse(html == null ? { type: "starsSchools", ok: false, error: "STARS signed you out: sign in again, then run again" } : { type: "starsSchools", ok: true, schools: starsSchools(html) }),
          () => sendResponse({ type: "starsSchools", ok: false, error: "STARS did not answer: reload the page and try again" })
        );
        return true;
      // async response
      case "starsYearPath":
        starsHtml(starsSummaryPath(msg.ceeb)).then(
          (html) => sendResponse({ type: "starsYearPath", path: html == null ? null : starsYearPath(html, msg.ceeb, msg.year), years: html == null ? [] : starsYears(html, msg.ceeb).map((y) => y.year) }),
          () => sendResponse({ type: "starsYearPath", path: null, years: [] })
        );
        return true;
      // async response
      case "ucOpenClasses": {
        void (async () => {
          const start = Date.now();
          while (!ucCoursesButtons(document, msg.grade).length && Date.now() - start < 8e3) await new Promise((r) => setTimeout(r, 200));
          const link = ucClassesLink(document, msg.grade, { name: msg.schoolName, code: msg.schoolCode });
          if (typeof link === "string") return sendResponse({ type: "ucOpenClasses", ok: false, error: link });
          sendResponse({ type: "ucOpenClasses", ok: true });
          setTimeout(() => link.click(), 50);
        })();
        return true;
      }
      case "csuStop":
        csuStop = true;
        sendResponse({ type: "csuStop" });
        return false;
      case "csuFill":
        if (!SITE_ORIGINS.csu.includes(location.origin) || !onCourseworkPage(document)) {
          sendResponse({ type: "csuFill", result: { added: [], skippedExisting: 0, stopped: "Open Academic History > High School Coursework on Cal State Apply first." } });
          return false;
        }
        csuStop = false;
        runCsuSchool(document, msg.plan, () => csuStop).then(
          (result) => sendResponse({ type: "csuFill", result }),
          (e) => sendResponse({ type: "csuFill", result: { added: [], skippedExisting: 0, stopped: e instanceof Error ? e.message : String(e) } })
        );
        return true;
      // async response
      default:
        return false;
    }
  });
})();
